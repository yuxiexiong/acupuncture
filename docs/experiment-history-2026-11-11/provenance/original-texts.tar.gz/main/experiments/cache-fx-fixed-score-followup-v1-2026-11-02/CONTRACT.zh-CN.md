# FXS-01（固定名单恢复的首步固定候选连续分数补测）合同 r01

日期：2026-11-02。设计：[计划 v1](../../docs/cache-fx-fixed-score-followup-plan-v1-2026-11-02.zh-CN.md)（评审撰写，5b6127c）+ [修订 v2](../../docs/cache-v-followup-amendments-v2-2026-11-02.zh-CN.md)（032a17c；FXS 部分：不扩到四份随机子集）+ [共同自查](../../docs/cache-v-followup-self-check-v1-2026-11-02.zh-CN.md)。授权：用户 2026-11-02「开始」。P 面板与 FX-01 的离散结果已见；本轮新测的是首步数值 logits 与新臂 T_Ubar。与 SVQ-01 独立立项、记账，互不设科学门槛。

## 1. 操作

模型、revision、BF16、内核、L0 剂量 −1、形成窗口、四方向、12 条 P 输入、worker/GPU 分配、进程内校准（须等于 B3）全部沿用 FX-01。每输入形成 C，每方向形成 T，从以下起点各做**一次**末 prompt token 的评分前向（独立 clone，评分期无注入，不生成）：

| 臂 | 起点（14 个深层 G 层卷积 V 通道；q/k 卷积、S、KV、浅层保持 T） |
|---|---|
| C | 干净缓存 |
| T_nat | T |
| T_V | 全部 448 头 V 取 C |
| T_FIXV | 固定 45 头 V 取 C（fixed-heads-r01.json，SHA256 dbc7f130…） |
| T_RESTV | 其余 403 头 V 取 C |
| T_U | 冻结随机 45 头（fix-random-r01.json，SHA256 5a2ddbcb…，subsets[input][0]）V 取 C |
| T_Ubar（新） | U 在 448 头中的补集 V 取 C（与 REST 逐层配平） |

一份 U/Ubar 只是配对参照，**不是零分布**，不给 p 值、不作随机特异性推断。

## 2. 读数与冻结判读（计划 §3）

- 固定候选：q0 = FX-01 C_nat 的首 token（每输入冻结），s0 = 248046；不随臂的赢家改变。m_G = z_G(q0) − z_G(s0)，δ_G = m_G − m_nat。
- J_FIX = δ_V − δ_FIX − δ_REST；J_U = δ_V − δ_U − δ_Ubar；另报 J_FIX − J_U（不称显著）。
- τ = max(0.5, 0.1|δ_V|)。|δ_V| < 1 记“总效应不足”，不算份额；否则 |J| ≤ τ 近似可加、J > τ 超加、J < −τ 次加。
- 情景标签：f0/f1 同标签才给，否则混合。方向标签：≥5/6 情景同一标签，否则混合。固定报告各标签 k/4，不凑总体阳性。**无方向性预测**（计划：没有可靠先验）。
- 精度：logits 以原 dtype 保存；每个原始 logit 取相邻可表示数间距的一半为误差，按项相加传播到 J 与 δ_V；任一角点 (J ± e_J, δ_V ± e_V) 改变标签记“精度敏感”。分别报告原标签与最不利汇总（精度敏感输入记为未定，不能计入任何标签）。不改阈值、不换高精度。
- “与首步阈值解释相容”仅当：该输入 J_FIX 近似可加，且 T_V 的首步 argmax = q0、T_FIXV 与 T_RESTV 的首步 argmax ≠ q0。不能写“完整交付主要由阈值造成”；超加也不定位内部计算、不证明 FIX 特殊。
- 描述性同报：q0 − 全词表其他最大值、实际 argmax、停止赢家、q0 名次、各臂恢复 V 差异范数（协变量，不是承载比例）。

## 3. 预算

| 阶段 | 形成 | 评分 | 校准 |
|---|---:|---:|---:|
| 预检（P01-f0/f1，1 worker；首输入另做 C/T4146 重建评分） | 12 | 52 | 1 |
| 正式（12 输入，2 worker） | 60 | 300 | 6 |
| 合计 | 72 | 352 | 7 |

形成 token 前向与 prefill 次数另记在回执。GPU ≤0.5 设备小时，产物 ≤2 GiB；预检工程失败可记账后重试一次；正式不重试。全词表 logits 张量（约 12 MB/输入）留在服务器 `runs/*/worker-*/tensors/`，Git 只提交记录与哈希清单。

## 4. 工程闸门（任一不过即停止）

名单哈希；FIX+REST = U+Ubar = 448、U 与 FIX 逐层配平、Ubar 与 REST 逐层配平；校准与 GPU 分配等于 B3；L0 写入 ≤1%；**旧哈希重放**：C 与 T_nat、T_V、T_FIXV、T_RESTV、T_U 的首步 logits 哈希、更新后缓存哈希与 argmax 都等于 FX-01 正式记录（C 另等于 NR C_native，T_nat 另等于 NR T_native）；C 的 argmax = q0；V 臂组装逐通道核对（q/k = T、列出头 V = C、其余 V = T），S/KV/浅层哈希 = T；供体不变；评分前无 hook；预检重建一致。

## 5. 出口

无论可加、超加、次加或混合，本补测都到此关闭；不重筛名单、不扩层、不加随机子集。结果只修正 FX-01 的解释，不影响 SVQ-01。

## 6. 交付

`runs/{preflight,formal}-r01/`（记录与回执入 Git，张量在服务器）、`analysis/fxs-readouts-r01.json`、`REPORT.zh-CN.md`。
