# 机制拓宽方向评估：既有读数审计

本目录只有旧文件的 CPU 核对，没有新模型实验结果。当前研究推进见[机制拓宽 Roadmap](../../docs/cache-mechanism-broadening-roadmap-2026-11-04.zh-CN.md)，未形成新的完整实验计划。用户已明确以拓宽为中心，本轮没有把同一 L0 面板的两个读数细化草案作为下一步方案交付。

- [audit_existing.py](audit_existing.py)：标准库读取历史收据、SHA、形成身份、token 与输出；不导入模型、不连接服务器。
- [existing-readouts-audit.json](existing-readouts-audit.json)：240 份原始 JSON 校验、432 行 L0 条件读数库存、144 行可复用条件 M、288 行缺失 M、逐输入 CSK→CVSK 类型对照及来源 SHA。

九格读数库存和其重建计数来自本轮较早的局部诊断备选，保留为可复用资产；它们不是拓宽实验的矩阵、预算或待执行队列。审计也复算四轮两根针的旧结果。正式新实验范围尚未冻结。

在仓库根目录复核：

```bash
python3 experiments/cache-mechanism-broadening-audit-v1-2026-11-04/audit_existing.py
```

脚本只重写本目录派生 JSON；不修改任何旧记录。核对的是记录与历史回执的一致性，没有重新计算模型输出，也未远程复核 `.pt` 文件本体。自然 t2 的 hash 不等于可以从中恢复 logits 或缓存。

准备过程保留说明：首次脚本把 NQK 的 `_nsr_CJ_sha` 来源字段当成条件而触发 TypeError，显式排除该元数据后核对通过；未影响任何原始文件。新实验 runner 尚未实现，无 GPU 授权或消耗。
