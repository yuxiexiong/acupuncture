# CFM-FORM-AB v2 实现说明与决策日志

| 文件 | 作用 |
|---|---|
| `form_ab.py` | 五个形成条件（共用 0…b 整段前缀，L 内逐 token 推进）、A 钩子、B 替换、统一评分、全部闸门、冻结/授权/worker/控制器/核验 |
| `form_analysis.py` | 合同 §5 读数与 §6 判读；`selftest` 演示每一行判读都能成立、也能不成立，Δ ≤ 0 不贴标签 |
| `test_form_ab.py` | 小号随机 Qwen3.5（8 层；针在第 0 层，B 覆盖第 1–4 层含一层全注意力，A 在第 5 层入口）上的 CPU 测试 |
| `readiness/path_probe.py` | 冻结前工程探针：只跑 C、T，比较 E2 整段路径与逐步路径（无任何 X 条件） |
| `readiness/real_smoke.py` | 冻结前真实模型闸门演示：VAR03-f0 完整 `run_item`，只输出闸门结果与 E2 已知端点，不输出 X 格读数 |

## 决策日志

1. **路线修订（偏离方案 §4.2-2，影响"与 E2 是同一个数值实验"这一表述）。** B 必须逐位置执行；Qwen3.5 线性层多 token 时调用 `torch_chunk_gated_delta_rule`、单 token 时调用 `torch_recurrent_gated_delta_rule`，两者算法不同，全注意力的矩阵形状也不同。探针 `readiness/probe-r01.json`（2026-10-31 11:49 UTC，GPU0，只跑 C、T）：E2 整段路径的 C、T 逐位重现 E2；逐步路径的缓存清单与 logits 哈希都不同，D 差 C 0.0、T 0.0625（Δ_E2 = 17.2）。方案对这种情况的规定是"预检停止……数值路线修订另行记录后才重审"。本合同在冻结前登记修订：R0（整段路径逐位溯源，预检）+ R（逐步路径对 E2 三端点的 0.05 × Δ_E2 容差，每个输入）。0.05 写在 `form_ab.PATH_TOL`，在探针之前确定：`probe-r01.json` 的 `tolerance_preset`（0.8609 = 0.05 × 17.22）是探针运行时从该常量算出的。所有可以逐位做到的闸门（时序、B 来源、结构、评分隔离、惰性钩子）仍为逐位。**重审由同一助手完成，不是独立审查**；用户可以否决这一修订，届时本轮数据只能作为修订路线下的结果。
2. 五个条件共用 0…b 的一次整段前缀：这段在所有条件中都无针（E2 的 L0·01 掩码在这段为 0），因此共享不改变任何条件的定义。
3. 评分只做首步，不调用 `S3.run_once`（它会做候选强制，方案 §4.1 不增加）。`form_ab.score` 与 `run_once` 首步逐位一致，由 CPU 测试 `test_score_matches_run_once`、`test_x0_equals_e2_style_cell_a` 检查。
4. 评分时"无钩子"按"每个模块的钩子数等于裸模型基线"判（真实模型基线为 0 个带钩模块，见 `readiness/smoke-r01.json`），避免把框架自带钩子误判为失败。
5. B 的独立验证：CPU 测试 `test_b_definition_independent` 不经过 B 的替换代码，直接按定义构造"C 在 τ−1 的缓存 + 带针单步 τ"，其浅层清单须等于 XB 的浅层清单。
6. 合同 §6 "联合进一步削弱"需要一个数：方案未给，取 R_AB − max(R_A|B0, R_B|A0) > 0.3（与弱档宽度相同），冻结前写定。
7. 2 个 worker（每卡 1 个）：真实模型每输入约 17 s（含预检的惰性重跑），12 输入单卡也只需约 3 分钟，多 worker 无收益。
8. 冻结前真实模型闸门演示（`readiness/smoke-r01.json`）：VAR03-f0 全部闸门通过，16.6 s，峰值显存 9.5 GB，张量 0.69 GB/输入。脚本不打印、不保存 XA/XB/XAB 读数；正式运行从头重算，不复用这次演示的任何结果。

## 运行记录

- preflight-r01：2026-10-31 11:58 UTC，1 worker，40 s，通过（R0 整段路径对 E2 逐位；惰性钩子逐位；9 前缀/10 评分）。
- formal-r01：2026-10-31 11:59–12:01 UTC，2 worker（每卡 1 个），119 s，12/12 输入全部闸门通过，60 前缀/72 评分。
- 判读：`analysis/form-ab-readouts-r01.json`（冻结的 `form_analysis.py run`）。
- 张量文件（逐位置供体、δ0、深层缓存、全词表 logits，共约 8.9 GB）不进 git，留在服务器 `/workspace/acupuncture/experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/runs/*/worker-*/tensors/`，哈希在各 worker 的 `receipt.json`。

## 测试

见 `readiness/cpu-receipt-r01.json`。

