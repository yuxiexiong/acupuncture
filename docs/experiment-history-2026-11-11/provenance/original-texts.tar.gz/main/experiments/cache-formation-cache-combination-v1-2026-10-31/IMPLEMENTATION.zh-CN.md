# CFM-CACHE-COMBINATION v1 实现说明与决策日志

| 文件 | 作用 |
|---|---|
| `combo.py` | 阶段 B 形成（C、CR0、CR1，预检加 CT）、阶段 A 的 22 个组合格评分、全部闸门、冻结/授权/worker/控制器/核验；在 bridge 冻结代码上构建 |
| `combo_analysis.py` | 合同 §5 的读数、完整代数分解、CT 与 T 图样比较、阶段 B 比较；`selftest` 演示分解恒等式、加性/纯三阶情形、展示规则两侧、图样相同/不同 |
| `stage0_offline.py` | 阶段 0：CPU 读 bridge 评分期内部量，描述 J 与接收者的逐层差 |
| `test_combo.py` | 小号随机 Qwen3.5 上的 CPU 测试：小号 bridge 运行作为旧资产（经 torch.save/load 往返），含卷积槽位消费检查 |
| `readiness/real_smoke.py` | 冻结前真实模型闸门演示，不输出读数 |

## 决策日志

1. 方案 r2 按用户批准执行：新增 (C,T)、TC/T 名称更正、槽位说明、完整代数分解、随机方向说法、预算 22/264。用户本次同时授权阶段 B，与阶段 A 合在同一合同里运行。
2. **阶段 A 的缓存容器**：用同一输入阶段 B 新形成的 C 缓存做模板，深拷贝后把每个持久张量都覆盖成 bridge 保存的值，不另做模型前向。端点逐位重放与逐字段清单核对共同证明重建正确。
3. 阶段 B 的 ξ 用独立实现的 `xi_band` 重算，并核对两件事：重算出的 TR 带逐位等于 bridge 保存的 TR 带；CR 的 ξ 与 TR 的 ξ 逐元素相等。这是方案 r2 §4.2 要求的工程检查。
4. 卷积槽位：方案只说"按实现核对"。实现上加了 CPU 测试，在同版本 transformers 上验证"改最老槽位逐位无影响、改次老槽位有影响"。真实模型用的是同一份代码路径。
5. 判读模块的停止 token 做成参数，默认 (248044, 248046)。小模型只有一个停止 token，测试里传 (5, 5)。
6. CPU 测试初稿有两处是测试写错：停止 token 写死；小模型 Δ < 1 时图样比较按展示规则返回"Δ 太小"，测试却要求有排序字段。都已改正，代码逻辑没有变。
7. 冻结前真实模型演示 `readiness/smoke-r01.json`（VAR03-f0）全部闸门通过：14 s，峰值显存 9.6 GB，张量 0.29 GB/输入，η ≤ 0.058。不输出读数，正式运行从头重算。
8. 2 个 worker（每卡 1 个）。

## 运行记录

- preflight-r01：2026-10-31 15:02 UTC，1 worker，37 s，通过（4 前缀/34 评分）。
- formal-r01：2 worker（每卡 1 个），113 s，12/12 输入全部闸门通过，36 前缀/300 评分，共 2.72 GB。
- 判读：`analysis/combo-readouts-r01.json`（代数分解恒等式最大残差 7e−15）；阶段 0：`analysis/stage0-offline-r01.json`。
- 张量不进 git，留在服务器 `/workspace/acupuncture/experiments/cache-formation-cache-combination-v1-2026-10-31/runs/*/worker-*/tensors/`，哈希在各 worker 的 `receipt.json`。

## 测试

见 `readiness/cpu-receipt-r01.json`。
