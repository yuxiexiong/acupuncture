# 官网依据

2026-11-08北京时间直接下载以下官网页面，三位模拟审稿人读取同一份本地文本。原文页面全文不转载入Git；下载时间、HTML及抽取文本SHA256保留在[sources.json](sources.json)。本地原文受本目录.gitignore排除。

- [ICML 2026 Reviewer Instructions](https://icml.cc/Conferences/2026/ReviewerInstructions)：采用Main Track表单。分别判断技术可靠性、表达、意义和原创性（各1–4）；总推荐1–6，最高为Strong Accept；信心1–5。独创性可以来自理解的进步，无须新方法；技术可靠性与影响分开判断。具体评分锚点以官网为准。
- [ICML 2027 Reviewer Instructions](https://icml.cc/Conferences/2027/ReviewerInstructions)：本次获取时仍为待发布占位，因此不冒称按2027正式规则评分。
- [ICML 2026 Call for Papers](https://icml.cc/Conferences/2026/CallForPapers)：用于区分主会研究论文和其他轨道；本次科学工作稿审阅不等于格式合规验收。
- [ICML 2026 LLM Policy](https://icml.cc/Conferences/2026/LLM-Policy)：正式审稿判断不能委托给LLM。本次是作者请求的AI模拟反馈，不是实际获配审稿，相关履职确认标为不适用。
