# 复用审计与论文修订回执

2026-11-08；本目录为文档/CPU审计资产，不是模型实验运行目录。基线Git为`58aa3d6b3ff78a92011878dc7322e75d62722de8`。

- [来源与设计计数](inventory-and-design-check.json)：来源SHA、四模型数量、八个既有9B/N978/−1原始记录、匹配旧收据的固定版本9B配置、24正式与6工程情境ID及矩阵计数。只是这些文件的本地复核，不是远端权重/所有历史原始文件的全量新验收。
- [论文基线block清单](paper-base-block-manifest.json)、[定点修订补丁](paper-revision-patch.json)、[应用回执](paper-apply-report.json)：以ARS工具对基线稿临时副本锚定后应用14个操作，131个原块中的122个字节不变，保留比例93.13%。新增表A/B放入既有§4正文，未重排原机制结果。新块不计入原块保留率。
- [最终文档/CPU核对](delivery-check.json)：八项能力表与机器汇总逐项匹配；原§4.1–4.10机制结果字节不变；八条9B锚点连同源记录hash一致；24情境选择、轨迹计数和104个本地链接核对通过。此回执不是新模型数值验收。

可复现论文修订：从上述Git提交取`docs/mechanism-paper-skeleton-2026-11-05.zh-CN.md`到临时文件，以Academic Research Suite的`ars_anchorize_draft.py`锚定；base hash应为`9e73a7303fbd`；再用`ars_apply_revision_patch.py`应用本目录patch到新文件。工作副本中的`<!--block:B…-->`标记在最后Markdown输出时去除，现行论文保留无标记的项目格式。回执中的临时绝对路径仅描述本次工具运行，不是读者依赖路径。

设计自查、历史错误及反方反例完整写在[最小方案§7](../cache-write-read-cross-model-minimal-plan-v1-2026-11-08.zh-CN.md)。没有独立评审、没有新模型结果；原始实验、冻结与失败收据未修改。

本轮未连接Serena，源码理解使用`rg`及局部静态读取；CPU检查沿用Ponytail full的最小实现原则，以标准库核对既有JSON和文件hash，没有搭建新运行基础设施。
