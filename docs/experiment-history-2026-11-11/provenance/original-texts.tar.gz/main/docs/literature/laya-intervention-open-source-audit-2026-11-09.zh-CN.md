# Laya 插针可行性与开源实现核查（2026-11-09）

## 结论与术语

用户约定：今后本项目讨论中的“JEV”默认指 **Laya**；外部资料仍按真实模型名称引用，不能把 TypeSafe Jev、AutoJev/Qwen 的证据归到 Laya。

**Laya 具备实施内部激活干预的条件，且找到了直接针对 Laya 的开源实现：Hantlowt/laya-studio。** 旧名 laya-steering-lab 已迁移至此；GitHub repository ID 均为 1386961676。其 PyTorch 后端在编码层输出加向量，再使用原决策头，属于真正的内部激活干预。它不是少数 MLP 通道插针，也不是已经证实有效的通用修复方法。

本次交付是源码与已有实现核查，不是新实验设计。没有下载权重、安装依赖、加载 Laya、调用付费 API、运行真实模型或 GPU；不把本文当作运行合同或科学实验通过记录。

## 已固定的来源

| 对象 | 固定版本与入口 |
|---|---|
| 官方 Laya runtime | [NandhaKishorM/laya，3c346a2f8b542838eed6a1d210aa378c79e71c4c](https://github.com/NandhaKishorM/laya/tree/3c346a2f8b542838eed6a1d210aa378c79e71c4c) |
| 模型说明与权重入口 | [convaiinnovations/laya](https://huggingface.co/convaiinnovations/laya)；英文模型卡描述 ModernBERT-large 主体加两层 Transformer 决策头，约 421M 参数。多语言版另用 mmBERT，不混用。 |
| 直接干预实现 | [Hantlowt/laya-studio，beef4e28445d591561ffd17c8b9f5d6a744532ca](https://github.com/Hantlowt/laya-studio/tree/beef4e28445d591561ffd17c8b9f5d6a744532ca) |
| Studio 当时核对的依赖 | [design.md](https://github.com/Hantlowt/laya-studio/blob/beef4e28445d591561ffd17c8b9f5d6a744532ca/docs/design.md)记录 Laya 0.3.20 / upstream 970dc8c5f63d7b886a68409493f37d569424f933；[constraints.txt](https://github.com/Hantlowt/laya-studio/blob/beef4e28445d591561ffd17c8b9f5d6a744532ca/requirements/constraints.txt)固定 laya==0.3.20。不能把它当作已验收适配最新 Laya。 |
| 官方可选 checkpoint pin | 当前 [revisions.py](https://github.com/NandhaKishorM/laya/blob/3c346a2f8b542838eed6a1d210aa378c79e71c4c/laya/revisions.py)列出英文 checkpoint 55cf4c4ebb4ebe31b2550e8bdf3bd21b99753851；这是上游可选 reviewed pin，本次没有下载或核对其权重。 |

## 实际改动了什么

[backends.py](https://github.com/Hantlowt/laya-studio/blob/beef4e28445d591561ffd17c8b9f5d6a744532ca/src/laya_studio/backends.py) 的 PyTorchLayaBackend：

1. 加载官方 Laya，设 eval，并将所有参数 requires_grad 设为 False。
2. 从 encoder.layers 等候选容器中找到编码层。
3. predict_steered_batch 在指定层 register_forward_hook。
4. 当输出为三维张量、最后一维与向量长度相符时，返回 h + alpha * v[None, None, :]；tuple 输出只改首项。
5. 继续原 predict_batch 和原决策头，finally 移除 hook。

因此它是**单层、全 token、通常全隐藏维度的稠密向量干预**。没有 token 子集或少通道选择，冻结权重也不代表无任务数据适配。

[strategies.py](https://github.com/Hantlowt/laya-studio/blob/beef4e28445d591561ffd17c8b9f5d6a744532ca/src/laya_studio/strategies.py) 的 ActivationSteeringStrategy：

- 目前只支持二分类任务，默认 layer=-1。
- 用正负样本的 encoder 平均池化 embedding 均值差，归一化后作方向。
- 在验证集选择强度；默认候选为 -1、-0.5、0.5、1，**没有零剂量候选**。
- 向量来自池化的最终编码表示，并非逐个候选层同位置的配对激活；维度相同不能证明语义方向在不同层对齐。
- 没有验证样本时会保留默认第一个强度；也没有显式检查两类样本都存在。这些配置不能直接当作有效校准。

README 中 multi_vector_steering、contrastive_vector 等方法使用外部 embedding classifier，**只有 activation_steering 才是这里确认的内部激活干预**。MLX 后端明确 reports unsupported；不能为图方便换成 MLX 后把嵌入分类结果当内部针。

## Laya 原生的干预空间

固定版 [common.py](https://github.com/NandhaKishorM/laya/blob/3c346a2f8b542838eed6a1d210aa378c79e71c4c/laya/common.py) 的 DecisionModel 路径：

encoder → 加 question-type embedding → Transformer 决策头 → gather 各选项 marker → scorer → 选项 logits。

scorer 为 LayerNorm → Linear → GELU → Linear(d, 1)。因此源码层面可以访问：

- 编码层输出：Studio 已实现的针位；
- 编码器/决策头中的 MLP 中间通道：可做稀疏针，但本次未交付或验收该适配；
- scorer 的中间特征：更接近最终读出，影响选项分数不等于修复上游信息使用。

官方 on_predict_start/end 是请求生命周期钩子，不是隐藏状态针。最新源码的 CPU 优化路径会检查 module hooks，并在发现 hook 后回退普通路径；这是有利的实现事实，但不能代替选定 runtime/backend 的实测验收。编译、TileLang、ONNX、MLX 与不同 attention 后端也不能默认等价。

Laya 是双向编码决策模型；本次没有发现可直接承接我们自回归生成期缓存写入—撤针—后续读取链的同构实现，不能搬用 Qwen 缓存结论。

## 本次工程检查与证据边界

从固定版 backends.py 用 Python AST 提取原 predict_steered_batch 方法，使用现有 PyTorch、合成 CPU 张量与一个仅保存回调的假模块做检查，不调用 Laya 或真实模型前向：

- 三维输出按指定 alpha 加向量：通过。
- 原输入张量没有被原地修改：通过。
- tuple 其余元素保持：通过。
- 成功和故意抛异常后均移除 hook：通过。
- 二维输出和末维不匹配时**原样返回、没有报错**：确认存在静默跳过分支。

这只是抽出的 hook 方法验收，不是官方真实模型/backend 兼容验收。当前本机 Python 可找到 torch、numpy，未安装 laya。没有安装或扩环境。

检视 Studio 当前完整文件树、README、设计与测试：存在 smoke fixtures；README 明确它们用于工程检查而非科学证据，快速测试用 FakeBackend。**本次未找到公开可核验的真实 Laya activation_steering 前后收益表、逐题输出与相应运行收据**；这不等于证明作者从未运行。

## 检索中的易混淆结果

- [GopiKWork/jev-experiments](https://github.com/GopiKWork/jev-experiments/tree/3fae1a87cb96c5067c42446a8d3d29faa73f1b92) 的 steering_demo.py：Laya 判断后由 Python 引导 Strands agent；没有改 Laya 内部激活。
- [YashDThapliyal/laya-whitebox-attack](https://github.com/YashDThapliyal/laya-whitebox-attack/tree/eccda6ca37889abed8ea0fd33f1b224d68bfae7d)：公开的微调与 HotFlip 输入 token 替换，不是稀疏内部激活针。
- [System-One-Control-Bench](https://github.com/Exemocaro/System-One-Control-Bench/tree/6e2efa8ab91e5a70ac13f538e28634c5cff6edcb)：模型选择游戏动作，steering 指外部控制；不作为内部针证据。
- 先前 Jev/Qwen 权重编辑材料不属于 Laya 直接证据。

检索使用 Laya + activation steering / activation patching / activation addition / register_forward_hook / neuron intervention / weight editing，以及 GitHub 仓库搜索。该范围不覆盖所有未索引代码、私有仓库或已删除内容，不声称领域内只有这一份实现。

## 试用判断

**优先复用 Laya Studio 的 PyTorch activation_steering 实现，而非重写整套搜索框架。** 现成入口是该仓库 CLI 的 activation_steering@层号；完整使用方法见固定版 README 的 Research suites。

目前可以确认“有实现，计算路径可干预”；不能确认“有有效稀疏配方，或能改善目标任务”。开始真实试用前仍需固定 checkpoint/runtime/backend、验证 hook 调用和实际非零扰动，并保留原版/零剂量/移除 hook 的一致性检查。它们是工程验收条件，不是本轮已完成的模型试验；后续若制定科学实验，需另按项目 C01–C14 自查，不以此文替代。

本轮未安排搜索层数、剂量、任务或算力预算，也没有启动模型实验。
