# Neuron Lens 与 Acupuncture 缓存机制：证据对照及发现过程核查

2026-10-31。仅查阅公开源码、提交历史、研究自述及本项目既有合同、收据、报告；无模型加载、前向、生成、张量复算或GPU使用。采用 academic-research-suite 的事实核查流程，同一助手综合，不是独立实验复现。不提出新实验设计或运行授权。

## 1. 核心判断

Neuron Lens §9提供两条相关但必须分开的机制线索：巨大激活与注意力汇聚点的形成；接近输出不可见方向的写入通过最终归一化尺度改变输出熵。它们为本项目提供候选计算解释与排除边界，但尚未解释本项目的原生作用链。

必须收紧上一轮口头解读：公开代码明确承认，熵神经元检验复用了Stolfo等2024年的方法，L6三个sink神经元也来自Muyu He的先前工作。新项目把这些已有认识与自己的测量、定位连起来，不宜叙述为从零、短时间发现了一套全新机制。R/S-lens主要读方向；§9这类尺度效应反而需要额外的权重、激活及切除检验，不能说是可视化工具自动读出来的。

外部核查固定版本：stdlogits/neuron-lens `44867947fa69316eae035e4c7dbb3bb3431affb1`；findings最初发布于 `07fdf454c3479b57d0919f54ddc81837130a02cd`。下文外部数字均为作者报告，本轮只核对资料。

## 2. 对照我们的既有结果

| 本项目证据 | 与Neuron Lens的关系 | 当前解释边界 |
|---|---|---|
| 单通道−1的校准输出向量范数约为参考残差尺度，且作用于多个token | 都提醒我们：坐标少不代表有效扰动小 | 已澄清“小针必然经异常放大”这个错误前提；尚不能据此证明一般损伤或sink机制 |
| 提示阶段插针，末位撤针仍影响回答；干净重建可改变结果 | 与跨位置持久状态参与相容 | 他们没有研究我们混合架构中卷积、递推、KV的不同作用，不能借其结论定位我们的承载者 |
| 10-29高停止条件中，单洗卷积或递推均可解除首步EOS，单洗KV仍保留18–24/24停止 | 不支持把首步停止全部归为普通全注意力KV中的sink | 这是指定混合状态下的条件性效果；没有排除形成期全注意力或下游归一化参与 |
| 10-29的粗注意力读数：受针末位对首token的注意力有时更高；前半段污染最重时接近原版 | 不支持简单“早层扎针削弱首token sink，所以失效” | 只检查了有限位置/条件的注意力副读数；不能排除其他头、其他位置或不同形式的sink改变 |
| S3中恢复卷积前V能明显削弱停止优势；只保留V变化可保留停止 | V改变可能最终经尺度和/或词语方向作用 | 未记录同一替换格的完整传播链，无法认定V只改变输出温度或直接携带EOS含义 |
| E2深层缓存保留75–94%停止分数移动但EOS为0/12；A5固定浅层过去状态削弱混合深层效应约32–52% | 已有“浅层历史参与深层形成、深层承载条件性输出效应”的证据 | Neuron Lens未给出这些缓存形成关系的解释；比例不是自然路径贡献，也不是完整回答修复 |
| A5旧logits审计：X0→XB非停止赢家10/12改变 | 纯最终共同正缩放不足以解释这些竞争变化 | 不说明最终尺度作用为零；近并列BF16差异另需数值限定，尺度份额仍未知 |
| 早段针显著降低候选事实响应，但不一定首步停止 | 不能把所有变化压成一个温度或停止指标 | 候选分数可能受尺度影响，仍未证明事实信息被删除、不可读或仅被其他答案压过 |

来源：[当前稳定结论](../cache-mechanism-stable-conclusions-2026-10-31.zh-CN.md)、[剂量与S2/S3连接](../../experiments/cache-intervention-chain-analysis-v1-2026-10-31/REPORT.zh-CN.md)、[10-29原报告](https://github.com/yuxiexiong/acupuncture/blob/main/experiments/early-state-localization-v1-2026-10-29/REPORT.zh-CN.md)、[E2原报告](https://github.com/yuxiexiong/acupuncture/blob/main/experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/REPORT.zh-CN.md)、[最新资产盘点](../cache-formation-mechanism-asset-inventory-v1-2026-10-31.zh-CN.md)、[A5离线核对](../../experiments/cache-formation-asset-audit-v1-2026-10-31/REPORT.zh-CN.md)。旧报告中“事实丢失”“单一通路”等较强措辞以当前稳定结论的限定为准。

## 3. 不需要新模型运行就能确定的边界

指定Qwen3.5实现的末端读出为：

`z = W_U diag(1 + weight) h / r(h)`，其中`r(h)>0`，head无bias。

若仅最终共同分母变化，而分子不变，则`z' = c z`、`c>0`。理想算术下，概率和熵可以改变，但词语排名、argmax及`D=max(z_stop)-max(z_nonstop)`的符号都不变。例如[3,2,1]变成[1.5,1,0.5]，第一名仍相同。

因此，纯末端温度机制不能单独解释本项目贪心首步从回答变EOS或不同非停止赢家。早层归一化、注意力及状态更新可改变分子与排名，不受此排除。A5旧资产缺最终h/r，不能把拟合输出缩放冒充测得的RMS变化。当前资产盘点r4已经记录了同样边界及未运行方案；本次不把它重新登记为新实测发现，也不启动该方案。

实现核对：[Transformers v5.20.2 Qwen3.5](https://github.com/huggingface/transformers/blob/v5.20.2/src/transformers/models/qwen3_5/modeling_qwen3_5.py)。不能把Qwen3的gamma数值定义直接套到Qwen3.5的原始norm.weight上。

## 4. 从公开材料能够重建的研究路径

以下是由代码依赖、方法及记录重建的逻辑路径，不是作者逐日发现顺序或私人思考过程。

1. **已有理论和点位作起点。** `entropy_neurons.py`开头明写复用2024年的切除＋固定最终尺度检验。`known.py`与`sinks.py`将L6的5723/8518/422归于Muyu He。2024年的Massive Activations已研究巨大激活与注意力集中。
2. **先建立可批量查询的观测。** 激活语料提供每个通道的强激活、位置和上下文；输出矩阵与norm权重提供近零空间筛选。`external_crosscheck`记录首token在L6的激活能量异常，以及三个神经元的集中贡献。
3. **用已知机制的数学结构选候选。** 熵神经元候选按“典型高激活×写入向量在有效近零空间中的范数”排序；末四层每层取8个候选及8个随机对照。不是仅凭人格回复或可视化颜色筛选。
4. **固定中间量切断特定作用方式。** 逐个切除候选，比较正常重算最终RMS与固定为干净RMS两种输出。该比较直接检查通过尺度的路径，避免只报告“切了输出变了”。
5. **追踪sink形成的上游条件。** 清零L0–L5的首位置MLP输出，用位置5作对照；用同token位于位置1时的L0输出替换首位置输出；梯度×激活排序后切除前30/100/300个神经元，并与随机切除比较。L0前300个切除后sink仍在97%文档出现，保留了“不由少数L0触发神经元独占”的负结果。
6. **写清限度。** 第二类sink消减只依赖11个位置；逐个切除不能完全分解共同激活的四个神经元。文中未解释全部自由生成异常或混合缓存机制。

核心原始来源：
- [熵神经元代码与方法声明](https://github.com/stdlogits/neuron-lens/blob/44867947fa69316eae035e4c7dbb3bb3431affb1/scripts/checks/entropy_neurons.py)
- [sink形成与归因代码](https://github.com/stdlogits/neuron-lens/blob/44867947fa69316eae035e4c7dbb3bb3431affb1/scripts/checks/sinks.py)
- [点位来源声明](https://github.com/stdlogits/neuron-lens/blob/44867947fa69316eae035e4c7dbb3bb3431affb1/neuron_lens/known.py)
- [sink实测日志](https://github.com/stdlogits/neuron-lens/blob/44867947fa69316eae035e4c7dbb3bb3431affb1/data/summary/sinks_qwen3-8b.log)
- [熵神经元实测日志](https://github.com/stdlogits/neuron-lens/blob/44867947fa69316eae035e4c7dbb3bb3431affb1/data/summary/entropy_neurons_qwen3-8b.log)
- [2024 Confidence Regulation Neurons](https://arxiv.org/abs/2406.16254)
- [2024 Massive Activations](https://arxiv.org/abs/2402.17762)

## 5. 能否从Git还原“他们怎么想出来的、用了多久”

本次查到Neuron Lens默认分支共4次提交：完整项目一次性初始导入，随后3次Drowse API兼容调整；issues和pulls（含关闭）均为空。初始提交的UTC作者时间为2026-10-30 20:02，对应北京时间10-31 04:02。发布日期不等于研究开始时间。代码还标明早期人格实验未公开，部分后被流水线吸收的分析脚本已退休。因此没有依据宣称已还原完整试错、全部失败或作者实际研究工时。

却找到一份直接相关的**前序研究者自述**：Muyu He的attention_sink/readme在2026-01-24提交中已写明，自己围绕attention sink探索约三个月，回看约两个月没有推进到有效的因果因素或相应几何关系。其总结是先找到有因果作用的因素，再刻画目标对象与该因素的几何联系。这个经历属于被Neuron Lens引用的前序研究者，不冒充a9lim/treetown本人的日记。

[固定版本自述](https://github.com/RiddleHe/llm-interp/blob/8cb9020aff9532642eb1b6d64ba8436ec954ec02/attention_sink/readme.md)；[Neuron Lens提交历史](https://github.com/stdlogits/neuron-lens/commits/main/)；[前序研究提交历史](https://github.com/RiddleHe/llm-interp/commits/main/attention_sink)。

## 6. 我们为什么推进得慢：可以支持的判断

不能仅凭双方公开结果计算谁更快。以下是依据本项目记录的研究组织诊断，不是用时因果测量。

- **问题距离不同。** 对方熵神经元分支从末层写入到最终归一化和熵，路径短且有现成机制。本项目追早层反复干预，经混合缓存形成、旧状态处理、当前读取到答案竞争，跨层跨时刻；复杂性真实存在。
- **我们把既有原理前置得不够。** 某些后续计划仍将“状态会延续”“模块会互动”等作为主要认识增量。项目先验审计已承认这类问题；是我此前设计与综合需要承担的不足，不能全归咎算力或课题难。
- **定位积累快于计算解释。** 洗缓存、换层组、换V得到了真实受控效应，但“哪里能恢复”不自动回答“原生计算为何坏”。有些轮次继续细分位置，没有形成可对接输出的明确计算解释。
- **证据链的条件和记录不够一致。** S2细轨迹只含L16–18，S3替换覆盖全部相关下游线性层；A5换了面板与供体背景。A5保存8.107GiB张量仍缺匹配的逐步深层驱动/实际读取/最终h/r。文件多、哈希完整不能代替缺失的中介量。
- **部分解释事后返工。** 曾混淆坐标稀疏与小扰动、候选敏感度与信息存量、分数恢复与行为恢复；收紧这些解释是必要修正，也暴露了早期判别设计不足。阴性结果本身不是浪费。

已有实质增量仍应保留：停止和交付可分离；历史改变后续更新；指定V替换对停止有条件性作用；浅层历史操作影响后来形成的深层输出效应。当前缺口是这些原生变化如何经实际读取和下游计算改变具体答案竞争。Neuron Lens让这一缺口更清楚，也排除了把“最终温度”直接当完整答案的捷径；没有替本项目完成该连接。

本报告未变更实验设置、研究主旨、原始记录或任何执行状态。未启动已有草案、配方复现或新GPU作业。
