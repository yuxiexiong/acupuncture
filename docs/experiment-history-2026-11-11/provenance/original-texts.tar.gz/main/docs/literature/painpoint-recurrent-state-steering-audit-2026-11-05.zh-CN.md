# 痛点候选七步查重：转向／稀疏干预把损伤写进混合模型的递推状态

2026-11-05。检索由本会话的子代理执行（WebSearch + WebFetch），主会话整理。**不是穷尽综述；候选痛点仍是推测档，查重结果只回答"先例给到哪里、提纯空在哪里"，不回答"值不值"。** 对应论文工作稿 §8（三件分开的事之一）与 §9。

## 候选主张（查重对象）

在含 Gated DeltaNet 递推层的混合模型（Qwen3.5／Qwen3-Next 一类）上，激活转向或稀疏激活干预会把损伤写进固定大小的递推状态 S；S 不像 KV 可以逐 token 丢弃或重算，所以针对 KV 污染的修复（按 token 门控/裁剪注意力贡献、驱逐被转向的 KV 条目）在这类架构上不适用；要修，得知道损伤经哪个写入／读取操作进入状态。痛的人：在混合架构上做 persona／安全／能力转向的人，以及做缓存级防御的人。

## 更正（2026-11-05 同日，按青蒿素判据重排）

第一版把先例按"已占／削弱／最近邻"三值归类，先例被当成坏消息报。按本项目的判据（青蒿入药几千年，提取出青蒿素是贡献；先例引来当现象普遍性的支持，不当否证；只禁具体过度声明，不缩小课题），下面改成三列表。另一处事实错误：第一版写 2603.16335 "作者自认是推断、未测量"。核原文：§5.3 写的是 "This provides causal evidence that the model computes its behavioral commitments … propagates them through the GatedDeltaNet recurrent state"，§6 写 "GatedDeltaNet recurrent layers 'compile' behavioral decisions during prefill into the recurrent state"，**没有 hedging**；但其"因果证据"是 prefill-only 有效、decode-only 为零的时序对比，没有对递推状态做任何干预或测量，没有持久性读数，没有定位到写入／读取。代码公开（github.com/zactheaipm/qwenscope，SAE 在 HF）。

## 三列表

### 先例支持（青蒿入药：现象有人见过，没人提纯）

| 先例 | 给了什么 | 没给什么（我们的落点） |
|---|---|---|
| 2603.16335 Behavioral Steering in a 35B MoE（正文；代码公开） | 生产级混合模型 Qwen3.5-35B-A3B 上，prefill 期转向有效、decode 期为零，作者归因递推状态承诺；α 超 5 全崩，副作用按方向不按幅度 | 对递推状态零干预、零测量；无持久性；无写入／读取定位。**可直接复用其代码与方向做转向型对照** |
| 2609.04434 Attention Recalls / Recurrence Controls（摘要） | persona／语言 70–80% 经递推通道；检索经 KV | 干净交换，无干预后的损伤与修复 |
| 2601.01972 HiSPA（摘要，EMNLP'26 Findings） | 短触发串不可逆覆写 Mamba 状态，Jamba／Nemotron-3 混合同样崩 | 无修复；非转向；非 GDN。证明"状态可被持久污染"且"没人会修" |
| 2609.32942 The Key Handoff（摘要） | 末注意力层之后的递推层仍可写入事实并改答案 | 干净写入，无损伤 |
| 2609.33093 How Linear Attention Remembers（正文） | 干扰由后续写入与目标方向重叠决定；future work 列了"选择性门控／刷新／分区递推写入"三种修法，未做 | 近邻自己点名的开口；写入重叠机制可借用作我们的解释工具 |
| 2609.32102 Residual Streams Read, Recurrent States Remember（摘要） | 明说"恢复／持久／因果使用需分别测量" | 同上，开口由近邻点名 |
| 2609.30950、2609.38169、2610.15139（摘要） | 混合／delta-rule 状态中的误差按通道衰减率持久、长解码累积 | 量化误差不是转向损伤，但同一承载机制 |
| clehaxze RWKV-7 gemlog（正文，非同行评审） | 直接编辑递推状态改事实，200 token 后仍有效，同实体属性串扰 | 非 GDN、非混合、非转向向量 |
| 实务抱怨：persona-lab（Qwen3.5-4B）、llama.cpp 分支 PR、atlas PR#1132、2604.11120 | 转向后敌意／切语言／循环；KV 跨请求泄漏；"SSM 状态是否需分键未处理"；Qwen3.5 对转向 ASR 反常低且无解释 | 没人归因到递推状态。这是"痛在、没人知道痛在哪"的直接证据 |
| 2404.05971、2609.04721（Zamba2 写入点转向，无公开代码）、WriteSAE 2605.12770 | SSM／混合上转向与写入编辑可做 | 都没测持久性与损伤 |

### 事实约束与竞争解释（必打基线，不是否证）

| 约束 | 内容 | 我们必须做什么 |
|---|---|---|
| 2605.07755 Error Control Dynamics（正文前 100k，NeurIPS'26） | 仿射 SSM（Mamba 系）注入的状态误差经全局对角衰减自然收缩；**未测 DeltaNet** | 持久性必须在 GDN 上实测；本项目 CFM-S1 的"L0 撤针后不衰减、L12 衰减"是现成对表数据，尚未对表 |
| 2609.33093、2510.19861 | 检索类行为经 KV，递推不补偿 | 痛点只写 persona／安全／风格转向，不写检索 |
| HELIX 2602.17691 | 只改约 10% 注意力层即可绕开 Mamba-2 层漂移 | 回避式解法是必比基线：若 S 损伤是问题，注意力层转向以什么代价绕开 |
| CLASP、SpectralGuard | 状态污染可检测 | 我们的位置在检测之后：修复经哪个操作 |
| 2605.10664 GCAD | KV 级修复在注意力模型有效 | "在混合架构失效"必须演示，不能假定 |

### 谁会因此改做法

- 在 Qwen3.5／Qwen3-Next 一类模型上做转向的人（含 2603.16335 代码的使用者）：知道损伤写进 S 且不随 KV 驱逐消失后，转向窗口与层类型的选择会变。
- 推理引擎：vLLM 已给混合模型状态块清零（PR #56524）；atlas PR#1132 明问"SSM 状态是否需按转向向量分键"。答案决定缓存分键策略。
- 防御作者（CLASP／SpectralGuard 一线）：从检测走到修复需要知道损伤落在写入项、擦除项还是读取。

### 结论（改写）

现象层先例充分：生产级混合模型上 prefill 转向经递推状态承诺已被观察（2603.16335），persona 落在递推通道（2609.04434），状态可被持久污染且无人修（HiSPA）。**提纯空着**：转向损伤在 GDN 状态中的持久性读数、KV 级修复在混合架构上失效的演示、损伤落在哪个写入／读取操作——三件近邻自己点名未做（2609.33093 future work、2609.32102）。两条必打基线：Mamba 系自然衰减（2605.07755）与注意力层回避（HELIX）。

**对论文的含义（主会话判断）：** 痛点从推测档升到可写，缺的是本项目自己的两条证据：转向型（非单坐标）干预在 S 中的持久性，与 KV 级修复在同一受针运行上失效的直接演示；2603.16335 的公开代码可作转向型对照的起点。单坐标 down_proj 干预到转向向量的迁移是**类比档**。不在 NWR-01 范围内，是否立项另议。禁的只有一句："首次发现递推状态可被污染"。

## 命中表（按步）

### 步 1 抽象阶梯
查询：`activation steering Mamba state space steering vector persistent effect recurrent state`；`steering vectors RWKV OR Mamba OR "linear attention" "representation engineering" hybrid`；`activation patching Mamba causal intervention SSM state`；arXiv API `steering AND (DeltaNet|linear attention|state space|Mamba|RWKV) AND (activation|intervention)`。

| 命中 | 说了什么 | 对主张 |
|---|---|---|
| 2404.05971 Does Transformer Interpretability Transfer to RNNs（正文） | Mamba-2.8B/RWKV-v5 上 CAA 有效略弱；状态转向与残差转向不可加，解释为"残差转向已经影响状态"；未测持久 | 支持前提，未量化 |
| 2602.22719 Activation Subspace Bottlenecks（摘要） | Mamba 系 7 模型 Δ 敏感子空间缩放转向；无持久／副作用分析 | 无关 |
| 2609.32102 Residual Streams Read, Recurrent States Remember（摘要） | Mamba-1/2/3 状态 Jacobian lens + 状态转向；"恢复／持久／因果使用需分别测量" | 支持"空着" |
| 2609.04721 Locating and Steering Refusal Beyond Attention（正文前 100k） | Falcon-Mamba-7B、RWKV-6、Zamba2-7B；拒绝方向加在 SSM 块写入点；开环误拒 86% | 部分削弱：写入点转向已有；无持久分析 |
| 2603.16335 Behavioral Steering in a 35B MoE（正文） | Qwen3.5-35B-A3B；decode-only 无效、prefill-only 有效，§5.3 写成"causal evidence … propagates through the GatedDeltaNet recurrent state"，无 hedging，但证据只是时序对比，未干预或测量状态；α>5 崩；代码公开 | 先例支持（第一版误写"作者自认推断"，已更正） |
| 2602.17691 HELIX（摘要） | Granite 4.0 H 只在 ~10% 注意力层转向，称足以纠正 Mamba-2 层漂移 | 削弱弱：回避式解法 |
| 2605.12770 WriteSAE（正文前 100k） | GDN/Mamba-2/RWKV-7 写入矩阵 SAE；Qwen3.5-0.8B 三个 cache 位置替换写入；持久性只由遗忘门公式隐含 | 已知近邻，未测持久 |
| 2606.11386、2609.11063（摘要） | 与 SSM 状态持久无关 | 无关 |

### 步 2 方法论单独搜
查询：`"state space" OR Mamba "prompt injection" persistence recurrent state contamination error accumulation`；`linear RNN SSM perturbation contractive Lyapunov "error propagation" Mamba-2 "gated delta"`；arXiv API `("hidden state"|"recurrent state") AND (poisoning|contamination|persistent) AND (Mamba|"state space"|"linear attention"|hybrid)`；`"Hidden State Poisoning" defense OR "state reset"`。

| 命中 | 说了什么 | 对主张 |
|---|---|---|
| 2601.01972 HiSPA（摘要） | 短触发串不可逆覆写 Mamba 状态；Jamba/Nemotron-3-Nano 混合同样崩；无修复 | 占"输入侧状态污染持久" |
| 2603.12206 CLASP、2603.12414 SpectralGuard（摘要） | 逐 token 分类／谱半径监控，只检测 | 占"检测"；"修复经哪个操作"空 |
| 2605.07755 Error Control Dynamics（正文前 100k） | Mamba/Mamba-3 经全局对角衰减收缩注入误差；token-gated RNN 放大；未测 DeltaNet | 削弱 (b) |
| 2609.30950、2609.38169、2610.15139（摘要） | 混合／delta-rule 状态量化误差按通道衰减率持久、长解码累积 | 蕴含"写进 S 的扰动按衰减率留存" |
| vLLM PR #56524 | 混合模型 Mamba 状态块分配时清零防跨请求污染 | 工程侧已意识到状态残留 |

### 步 3 蕴含检索
查询：`hybrid model attention vs recurrent layers ablation retrieval dominated by attention Jamba Zamba Nemotron-H`；`steering prefill only OR "prefix steering" vs generation persistence recurrent`；`steering Mamba decays OR half-life OR fades after intervention`。

| 命中 | 说了什么 | 对主张 |
|---|---|---|
| 2609.04434（摘要） | 检索只经 KV；语言／persona 经递推（70–80%） | 支持：persona 转向落在递推通道 |
| 2609.33093（正文） | 递推替换恢复 <1–3.6%、KV 96–100%；干扰由后续写入与目标方向重叠决定；未测衰减 | 削弱检索类；写入重叠机制可借用 |
| 2510.19861（摘要） | Jamba-Mini/RecurrentGemma 去注意力检索归零 | 削弱：检索无人痛 |
| 2609.32942 The Key Handoff（摘要） | 末注意力层后的递推层仍可写入事实改答案 | 支持：递推是可查询记忆 |
| 2610.04967 Prefix Steering、2609.11020（摘要） | transformer 上单 token 前缀转向持续影响；KV 轨迹移植改 persona | 相邻，transformer 侧 |

### 步 4 同义术语枚举
词表：steering vector / activation addition / ActAdd / CAA / RepE / concept vector / ITI / activation patching / SAE steering / control vector / cache steering / state steering / write-site；Mamba(-1/2/3) / RWKV(-5/6/7) / GLA / DeltaNet / Gated DeltaNet / Jamba / Zamba / Samba / Hymba / Qwen3-Next / Qwen3.5 / Nemotron-H / Nemotron 3 / Falcon-H1 / Granite 4 H / Bamba / MiniMax-01 / RecurrentGemma / Griffin / xLSTM。组合查询见子代理记录。命中：clehaxze.tw gemlog 2026-04-12（非同行评审，正文）：RWKV-7 直接编辑递推状态改事实、200 token 后仍有效、同实体属性串扰。其余架构除 2609.04721（Zamba2）、2602.17691（Granite 4 H）外无转向工作。中文检索无命中。

### 步 5 引用链（Semantic Scholar）
| 源 | 被引 | 相关的 |
|---|---|---|
| 2605.10664 | 8 | 无一涉及 SSM／递推／混合 |
| 2609.33093 | 0 | — |
| 2609.04434 | 4 | 2609.32942、2610.26830 |
| 2605.12770 | 2 | 2609.25053 LatentPort、2610.28753 |
| 2601.01972 | 2 | CLASP、SpectralGuard |
| 2404.05971 | 12 | 2609.32102、2609.04721、WriteSAE；无混合模型转向持久性工作 |

### 步 6 对抗式检索
- (a) 有人在 Mamba／混合上转向并报告持久效应或修复？无多轮／持久测量；最近 2603.16335（推断）、2609.04721（只报误拒）。未被占。
- (b) delta-rule 擦除项会自然冲掉扰动？无 GDN 扰动注入实验。2605.07755 证 Mamba 系全局衰减收缩（未含 DeltaNet）；由 2609.33093 可推：与后续 key 正交的扰动不被 delta 项擦、只随 α 衰减 —— 推导档，无人测。
- (c) 行为主要由 KV 决定？检索类：是。persona／语言／风格：否（2609.04434、2609.32942）。痛点在 persona／安全转向上成立，在检索类不成立。
- (d) 实务抱怨：见结论段；存在但无人归因到递推状态。

### 步 7 边界申报
- Semantic Scholar 被引滞后；Google Scholar、OpenReview 未查，在审稿件未覆盖。
- 非 arXiv：Research Square 两篇（rs-10023075、rs-11201314 "Where the Answer Is Born"，GDN 0.8B/27B 因果干预）只有标题，正文取不到。
- 非英文：仅一条中文查询；日／韩／俄未查。
- 检索截至 2026-11-04 的 arXiv 列表；2611 月内投稿可能未索引。
- 未读完：2605.10664 附录 J、WriteSAE 后 60k、2609.04721 后 166k、2605.07755 后 59k。

### 真正取到正文的
2605.10664（前 100k）、2605.12770（前 100k）、2404.05971、2609.04721（前 100k）、2605.07755（前 100k）、2609.33093、2603.16335、2604.11120（前 100k）、clehaxze gemlog、persona-lab README、llama.cpp 分支 PR#1、atlas PR#1132。其余只有摘要。
