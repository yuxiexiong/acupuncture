# 17 七步查重：A7 位置与顺序敏感（图文顺序 / 多图顺序 / 图内位置 / 剪枝后位置 id）

日期：2026-11-06。检索截至 2026-11。执行顺序 6 → 5 → 1 → 2 → 3 → 4 → 7。本候选本轮接受 38 条已执行的网页查询、2 次成功的被引列表扫描（共 114 条被引）、13 篇深读正文的检验；另有 2 条查询因会话检索额度用尽没有执行，OpenReview 审稿讨论没取到（见第 8 节）。

> **最不利的先说（都有出处，见第 4 节）**
> 1. (a) 图文顺序：在各模型卡推荐的"图在前"默认约定下这个失败不出现；把问题在图后再复述一遍（多约 1% token）即恢复大部分差距；Gemma-3-27B 上没有差距；思考模式把 Qwen3-VL-8B 的差距从 19.0 点降到 7.2 点。已有四个修法（提示复述、测试时训练、双序对比解码、改掩码重训）和一个带随机对照的机制解释。
> 2. (d) 剪枝位置 id：保留原位置 id 已成通行做法，ICLR 2026 一篇在 4 个模型族上 50% 剪枝保住 ≥99% 定位成绩。
> 3. (c) 图内位置：直接把图像块内掩码改成双向并重训的实验（LLaVA-1.5，三种编码器）显示代价只落在最前面几个 token，POPE 86.8 对 86.9。否定 RoPE 长程衰减的那篇论文，自己的正面归因在 v1 与 v2 之间换过（v1 归"位置分配不均"，v2 归"因果注意力错配"）。各模型的偏置形态不同。
> 4. (b) 多图顺序：ICML 2026 一篇在 3 族上报告"注意力对着正确的图、输出 logit 被位置先验带偏"，并报告 SoFA（改图间掩码）在 LLaVA-OneVision 上 N=4 时低于原模型（59.70 对 67.52）。
> 5. "四个子现象同根因"目前只有论证级的说法，散在多篇引言里；没有找到在同一协议下用同一干预检验 ≥2 个子现象的工作（对象层与结论层；第 3 步专门查询 4 条，另第 6 步相关 13 条）。最接近的一篇（Ask Twice）把图文顺序明确拆成两个可分离的机制。
> 6. 对第一轮笔记的两处更正：(i) 03 笔记 C9 写 FOCUS 证明"把图片顺序显式写进文本也不行"，原文那个实验是"每张图单独推理后把回答拼起来再附上顺序"，不是在联合输入里给图片编号；(ii) 04 笔记关键问题 3 写"对象层没找到 ≥2 族的选项位置内部工作"，本轮找到 SteerFair（ICML 2024，LLaVA / IDEFICS / InstructBLIP 三族，注意力头激活转向），属内部干预而非内部定位。

---

## 1. 候选定义

- **现象（一句）**：VLM 的答案随语义无关的位置或顺序变化而变——(a) 图像与问题谁在前；(b) 多图输入里图片的先后，以及描述一张图时混入另一张的内容；(c) 关键内容在图像里的位置；(d) 视觉 token 剪枝后位置 id 被重排。
- **根因主张（一句）**：语言解码器的因果掩码加上一维（或序列化的）位置索引，给本来二维或无序的输入强加了一个顺序。位于 LLM 的注意力掩码与位置编码。
- **预期结论（用于第 3 步蕴含检索）**
  - E1："四个子现象由同一处结构（因果掩码 × 序列化位置索引）造成；对这一处做同一类干预，四种敏感同时下降，且在 ≥2 个骨干无亲缘的模型族上成立。"
  - E2："把因果掩码的可见性、token 的序列顺序、位置 id / RoPE 三者在同一设置里分开后，图内位置偏置主要由其中某一项承载；RoPE 长程衰减的归因只在一维 RoPE 的 Llama 系成立（或不成立）。"
  - E3："图文顺序两种排法分叉的中层窄带，与多图顺序、图内位置的失败落在同一组部件上。"

---

## 2. 竞争者全景表

引文约定：行末断词的连字符按原词复原，引用编号以 […] 略去。阅读层级：**F** = 取到正文并读了方法、设定、对照、局限；**F浅** = 取到正文、按关键词定位读了相关段落；**F¹** = 第一轮已取正文、本轮未重读；**A** = 只读摘要；**S** = 只有检索片段。逐字引文均在下载的正文文本里 grep 核对过。

### 2.1 (a) 图文顺序

| 工作 | 类型 | 模型族 | 干预类型 | 对照 | 评测稳健性 | 效果数字 | 自认局限（逐字） | 代码 | 层级 |
|---|---|---|---|---|---|---|---|---|---|
| Ask Twice, Look Twice（[2607.15565](https://arxiv.org/abs/2607.15565) v2，2026-09，CMU，预印本） | 定位（机制）+ 修复 | 行为：Qwen3-VL-8B、Qwen2.5-VL-7B、InternVL3-8B、LLaVA-1.5-7B、Gemma-3-27B；机制只在 Qwen3-VL-8B | 推理时，纯改提示（问题复述 STIT、图像也复述 SITIT） | 注意力敲除带同尺寸随机文本 span 对照（随机 span 两种顺序下 ≤0.008）；提示消融排除"更多图像 token"（0.281）、"更多前置计算"（填充 5/40/120 个 token，约 0.266）、短提示（0.292）；第二份图像随机置换对照 SITIT-p | NaturalBench 1,900 组、POPE 9,000 题、Winoground 400 组，另 VQAv2 2,000 题开放式生成；配对 McNemar 与 bootstrap 95% CI；敲除用 250 对与结果无关的样本 | 差距（问题在后 − 问题在前）：NaturalBench 组准确率 Qwen3-VL +0.081、Qwen2.5-VL +0.175、InternVL3 +0.079、LLaVA-1.5 +0.123、Gemma-3 −0.006（p=.62）；LLaVA-1.5 问题在前时全答 Yes（POPE 0.500 对 0.871）。Qwen3-VL：STI 0.270、SIT 0.351、STIT 0.350、SITIT 0.374；Winoground 组 0.223 → 0.410。敲除：问题在后时切断"答案→问题"掉 0.056（CI [0.020, 0.096]），问题在前时该边无作用（+0.004），改为"答案→图像"掉 0.096 | "The logit lens is approximate, and activation patching would localize the circuit beyond our knockout."；"Gemma-3-27B, our only model without the paradox, is also our largest and our only one with bidirectional image attention, so we cannot say whether the paradox fades with scale, with bidirectional attention, or both"；"separating these causes needs models that vary scale and attention independently" | 项目页 rakshanda-cmu.github.io/ask-twice-look-twice/ | F |
| TTT for Modality Order Consistency（[2607.20351](https://arxiv.org/abs/2607.20351)，2026-07，UChicago / Reve，预印本） | 定位 + 修复 | InternVL2-8B、Qwen2.5-VL-7B、Qwen3-VL-8B；激活修补 InternVL2-8B 三个数据集 + Qwen3-VL-8B 仅 MMStar（n=500，可修子集 136） | 测试时训练：逐样本 3–5 步梯度，KL 把问题在前的分布对齐到图在前，用完复位 | 损失函数消融（对称 CE 只 +9.8）；移动/冻结教师；思考模型上 K=0 对照。**激活修补没有随机供体或随机位置对照**；修补只在最后一个 token | MMStar、RealWorldQA、AI2D 多选题；CHAIR 500 张（只 InternVL2）；纯文本基线 | 图在前高 6–26 点；TTT 后问题在前 +4.1 至 +26.1（Table 1；正文写 +5.2 至 +26.1），图在前 +0.0 至 +1.2。修补："recovery remains low before layer 17 on all datasets. Around layers 18–20, recovery rises sharply"。层窗消融：5–9 层 +25.2、16–20 层 +26.2、20–24 层 +25.2。思考模式：MMStar 差距 19.0 → 7.2 | "Our mechanistic analysis is strongest for InternVL2-8B; additional Qwen3-VL patching results show the same qualitative pattern, but a full cross-family circuit analysis remains future work."；"Our main evaluation focuses on multiple-choice benchmarks"；"A natural next step is to make this causal account more precise." | 正文写 "Code is available at link"，无 URL | F |
| DOCD（Gan et al.，[CVPR 2026 Findings](https://openaccess.thecvf.com/content/CVPR2026F/html/Gan_Mitigating_Vision-Text_Order_Bias_in_Vision-Language_Model_CVPRF_2026_paper.html)，pp. 9664–9673） | 修复 + 行为刻画 | 主结果 Qwen2.5-VL-3B / 7B；位置扫描另含 InternVL2-2B、Idefics2 | 推理时：图在前、图在后两路并行解码，用前者对后者的 logit 做对比补偿 | SFT 基线（加交错数据微调）；中间位置（r=0.5）复测；逐层注意力热图（相关） | 8 个基准（MMStar、AI2D、MuirBench、VLMs-are-Blind、MMMU-Pro 等） | 图在后比图在前在 MMStar、AI2D 上低 15–18 点；图放中间最差（U 形）；DOCD "recovers up to ∼17 points"；Idefics2 上 MMStar +12.66、MMBench +43.10；SFT "only modest improvements … and is sometimes harmful" | "DOCD doubles the number of autoregressive streams at inference time"；"it does not completely eliminate all order effects on every dataset"；"exploring tighter integration with training objectives" | 未核到 | F |
| MMA（[2503.02597](https://arxiv.org/abs/2503.02597) v3） | 修复（训练） | LLaVA 式，3 个 LLM 骨干 | 训练：改掩码，让靠前模态能看到靠后模态；对照为双序训练 DOT | 同数据同配置的因果掩码基线与 DOT | 12 个基准 | 平均 +6.2% | 未摘到 | github.com/sony/aki | F浅 |
| Words or Vision（[2503.02199](https://arxiv.org/abs/2503.02199)，CVPR 2025） | 行为 | Phi-3.5（顺序实验） | — | — | 三种文本变体 | "placing text tokens before image tokens increases text bias consistently" | — | — | F浅 |
| LREC 2026 "Do Multimodal LLMs Understand Order?"（[ACL Anthology](https://aclanthology.org/2026.lrec-main.716/)） | 基准 + 修法迁移检验 | 14 个模型（Gemini、Llama 4、Pixtral 等） | 自洽采样 | — | MMMU、CVQA、MMBench | 文本去偏方法迁移"most relative improvement values are negative" | — | — | F¹ |
| FACET-PROBE（[2606.26079](https://arxiv.org/abs/2606.26079)，Stanford，预印本） | 基准 | 18 个：Gemini 3.1 Pro、Claude Opus 4.7、ChatGPT 5.5 等 6 个闭源 + Qwen3.5-VL、InternVL3.5 等 12 个开源 | 提示级缓解（只在 Gemini 上） | 同序对照估计解码噪声底（Gemini 子集，温度 0）；贝叶斯 IRT 分离排序噪声与系统偏置 | 5 个面（选项、证据块、文档排名、图片集、混合模态），12 个数据集，>40 万次试验；多图题先筛掉题面含位置指代的（Mantis-Eval 52/70 被筛） | "None of the 18 MLLMs we audit are order-invariant: screened per-facet panel-mean flip rates span 24–50%"；"the best model still flips on 13.4% of trials"；提示级缓解 "are modality-conditional and do not transfer from text to visual reasoning" | 同序对照 "is scoped, not panel-wide"；图片集的机制行 "treated as exploratory" | "We plan to release" | F浅 |
| Order Matters（[2410.16983](https://arxiv.org/abs/2410.16983)） | 行为 + 利用 | Qwen-VL-Chat、DeepSeek-VL、IDEFICS / v2、LLaVA-NeXT、Video-LLaVA | 把关键内容放到首尾 | — | 位置不变准确率 PIA | 偏好上下文首尾；视频—字幕匹配平均 +14.7%、VQA +17.8% | — | — | F浅 |
| Test-time consistency in VLMs（Chou et al.，WACV 2026） | 修复（对称一致性） | 未核 | 测试时训练 | — | — | 2607.20351 按其对称目标自行实现作损失消融：InternVL2 / MMStar 上只 +9.8（不是该文自己的结果） | — | — | S |

### 2.2 (b) 多图顺序与跨图串扰

| 工作 | 类型 | 模型族 | 干预类型 | 对照 | 评测稳健性 | 效果数字 | 自认局限（逐字） | 代码 | 层级 |
|---|---|---|---|---|---|---|---|---|---|
| SoFA（[2503.13792](https://arxiv.org/abs/2503.13792)，CVPR 2025） | 定位（弱因果）+ 修复 | 行为：OpenFlamingo、Idefics2、LLaVA-NeXT-Interleave、GPT-4o；修法：Idefics2-8B、InternVL2-8B、VILA-13B、Mantis-8B、LLaVA-NeXT-Interleave-7B | 推理时：图间因果掩码与双向掩码线性插值，隔层施加 | 掩码三种形态（因果 / 隔离 / 双向）；**无随机掩码扰动对照**；位置嵌入一侧没测 | 图片位置多次打乱，报最小 / 平均 / 最大与不一致率；σ 用每任务 32 条验证集定 | 开源模型最好与最差排列间不一致率近 30%，GPT-4o 约 25%；SoFA 后降到 5–17%；平均准确率 +2~3 点（InternVL2 BLINK 38.95→43.26）；100 张图时 49.19→55.11 | 无局限小节。正文："these modifications lead to varying degrees of performance degradation … may substantially deviate from the training framework, leading to out-of-distribution hidden states"；"the optimal σ varies significantly across benchmarks"（NLVR2 0.75、MVBench 0.25）；"Whether the position bias in LVLMs is correlated with that of their LLM backbones remains an interesting question for further exploration." | github.com/xytian1008/sofa | F |
| LAD（[2605.11591](https://arxiv.org/abs/2605.11591)，ICML 2026） | 定位（相关）+ 修复 | Qwen2.5-VL-3B、LLaVA-OneVision-8B、InternVL3-8B | 推理时：用注意力信号逐样本校正 logit，5 条标定样本 | 对比 Instruction 提示、CoT、PriDe、自洽、SoFA、置换平均；4 种编号格式 | 5 次随机打乱，随机与对抗（视觉相似难负例）两档，N=2…12 | N=4 随机档：51.70→94.94、67.52→98.66、69.04→94.84；对抗档 38.04→65.72、49.56→71.06、61.00→76.64。SoFA 在 LLaVA-OV 上 59.70（原模型 67.52）。置换平均 99.04 / 92.86 / 74.32 / 60.16 对本法 98.66 / 94.92 / 71.06 / 55.34 | "necessitates white-box access"；"strictly tailored to discriminative retrieval over discrete candidate sets and does not straightforwardly extend to open-ended generative tasks" | github.com/brightXian/LAD | F |
| FOCUS（[2508.13744](https://arxiv.org/abs/2508.13744)） | 修复（串扰） | InternVL3、Qwen2.5-VL、Qwen3-VL、LLaVA-OneVision、Mantis | 推理时：每次只留一张干净图，N+1 次前向 | 隐藏状态相似度（相关；Qwen3-VL 0.340→0.366，Qwen2.5-VL 0.336 对 0.335） | Winoground、VisMin、Mantis-Eval、MuirBench、MIRB | 见第一轮 03 笔记 C9 | "FOCUS requires N+1 forward passes"；超参 "generalization to unseen settings without validation data has not been verified" | github.com/yejipark-m/FOCUS | F浅（本轮只复核了三处） |
| Delimiter Token Scaling（[2602.01984](https://arxiv.org/abs/2602.01984)，ICLR 2026） | 定位（相关）+ 修复（串扰） | Qwen2.5-VL（3B/7B/32B）、InternVL3（1B–14B）、LLaVA-OneVision（0.5B/7B） | 推理时：放大图像分隔符 token 的隐藏状态 | 去掉或替换分隔符 token 的消融；与 M-RoPE 时间位置嵌入对比 | Mantis、MuirBench、MIRB、QBench2；另多表格、多文档文本任务 | 去掉或替换分隔符 "leads to a performance drop of approximately 10 percentage points"；MuirBench Qwen2.5-VL-3B 37.31→42.42；Mantis InternVL3-2B 52.07→54.38；"applying M-RoPE alone results in lower performance than the baseline" | 未摘到局限小节 | github.com/MYMY-young/…（URL 截断） | F浅 |
| PeRL（[2506.14907](https://arxiv.org/abs/2506.14907)，NeurIPS 2025） | 修复（训练） | Qwen2.5-VL-7B | 强化学习 + 图片顺序置换增广 | — | 多图基准 | 未摘 | — | github.com/alchemistyzz/PeRL | F浅 |
| Image Retrieval Heads（[2611.04903](https://arxiv.org/abs/2611.04903)，2026-11-03） | 定位（相邻对象：多图里找目标图） | InternVL3.5-4B/8B、Qwen3-VL-4B/8B | 头零消融 | 等量随机头对照 | Visual Haystacks 多种规模 | "pointer"与"writer"两套头只 35–47 个重合；重合部分消融效应最一致。**两族 8B 模型 pointer 头前五名里有四个编号相同（L21H10、L21H11、L21H08、L21H09）** | "four recent open-weight LVLMs from two model families" | github.com/parkquasar/Image-Retrieval-Heads | F浅 |
| Looking Back and Forth（2603.07048，ECCV 2026）；PulseFocus（2603.04676） | 修复 | 未核 | 跨图注意力校准 / 逐图注意力门控 | — | — | — | — | — | S |

### 2.3 (c) 图内位置与远处区域

| 工作 | 类型 | 模型族 | 干预类型 | 对照 | 评测稳健性 | 效果数字 | 自认局限（逐字） | 代码 | 层级 |
|---|---|---|---|---|---|---|---|---|---|
| CCA（[2410.15926](https://arxiv.org/abs/2410.15926)，NeurIPS 2024） | 定位（弱因果）+ 修复 | LLaVA-1.5（CLIP + Vicuna-7B） | 训练：位置改同心环 + 相应因果掩码，重训 | 光栅与反光栅各训一个模型，正确率的空间分布翻转；第一层注意力有无 RoPE 对比。**反转的是视觉 token 的序列顺序，RoPE 距离与因果可见性同时变；方法本身也同时改位置与掩码** | POPE、CHAIR、MME 等 | POPE 三个数据集准确率 +5.48 / +7.86 / +6.70（第一轮摘） | "our focus is only limited to handling of image-text inputs."；附录 "our approach is validated on LLaVA" | github.com/xing0047/cca-llava | F |
| Beyond the Vision Encoder / AGCI（[2509.21984](https://arxiv.org/abs/2509.21984) **v2**，2026-02） | 行为 + 论证级归因 + 修复 | Qwen2.5-VL-7B/32B/72B、Qwen3-VL-8B、Gemma3n-E4B、LLaVA-v1.6-Mistral-7B、InternVL3-8B | 给每个图像 token 按相似度注入全局视觉上下文 + LoRA 微调（1 万条） | 遮挡搜索（Gemma3n、InternVL3，每位置 20 张）排除感知；编码器特征与文本嵌入相似度排除编码器；Qwen2.5-VL 分辨率扫描。**没有直接改掩码或改 RoPE 的干预** | 自建 3×3 拼图探针（9 万条）；6 个下游基准 | 各位置准确率方差 ∆：Gemma3n 2.39→0.25、LLaVA-v1.6 14.93→8.05、InternVL3 2.82→2.56、Qwen3-VL 5.98→3.45、Qwen2.5-VL-7B 1.54→0.84、32B 0.25→0.31、72B 0.95→0.12（Table 1；正文另写 7B 为 1.74；Qwen3-VL-AGCI 的 Avg 一格 87.44 与各位置数不符） | "our probing experiments focus primarily on a 3 × 3 spatial grid"；"Investigating whether the identified spatial bias persists or evolves in larger-scale models remains an important direction for future work." | github.com/AAAndy-Zhu/AGCI | F |
| From Bias to Balance / BaPA（同号 **v1**，2025-09） | 同上，归因不同 | Gemma3、LLaVA-NeXT、LLaVA-v1.6、Qwen2.5-VL-7B/32B | 推理时免训练：所有图像 token 赋同一个位置嵌入 | 同上 | 同上探针 | LLaVA-NeXT ∆ 54.90→0.02；Qwen2.5-VL 上方差无改善 | 同上 | github.com/AAAndy-Zhu/BaPA | F浅 |
| UAC / DAC（[2502.01969](https://arxiv.org/abs/2502.01969)） | 行为 + 修复 | LLaVA-1.5、mPLUG-Owl2、LLaVA-NeXT（7B） | UAC：减去空白图上的注意力偏置（免训练）；DAC：可学习校准模块 | 与 VCD、OPERA、SID、CCA 对比 | POPE、CHAIR、MME、LLaVA-Bench | 未摘 | "its performance may be limited when validation data is scarce. Future work could explore data-free calibration" | github.com/johnnyzyn/…（截断） | F |
| From Drop-off to Recovery（[2603.17228](https://arxiv.org/abs/2603.17228)，TUM） | 定位（因果，重训） | LLaVA-1.5（Vicuna-7B）× CLIP / DINOv2 / SigLIP 三种编码器 | 训练：图像 token 之间改双向掩码，其余保持因果 | 同配方因果与双向各训一个；注意力敲除 | ADE20K 逐 token 线性探针；9 个 VQA 基准 | 第 0 个图块像素准确率 +14.35 点（相对 +23.2%），"the gap decays in later image patches"；峰值 mIoU CLIP +0.42、DINOv2 +0.32；POPE CLIP 86.8→86.9、SigLIP 84.4→84.8、DINOv2 87.2→85.1 | "our conclusions might not generalize for significantly different architectures"；"Future work could explore whether these findings extend to broader task types and model architectures." | 未核到 | F |
| MCA-LLaVA（[2507.09184](https://arxiv.org/abs/2507.09184)） | 修复 | LLaVA-1.5-7B/13B；"InternVL-7B"（QLLaMA，基于 LLaMA2） | 训练：曼哈顿距离的二维衰减 | — | POPE、CHAIR | POPE +6.7（第一轮） | 未摘到 | github.com/ErikZ719/MCA-LLaVA | F浅 |
| Rethinking Causal Mask（[2505.18605](https://arxiv.org/abs/2505.18605)） | 修复 | LLaVA-7b / 13b | 推理时：放开视觉 token 对未来位置的掩码，或把未来注意力池化进过去位置 | 放开文本间掩码作反例 | 多图时序、OCR 等 | "selective improvements across benchmarks" | 未摘到 | 未核到 | F浅 |
| V²R-Bench（[2504.16727](https://arxiv.org/abs/2504.16727)） | 基准 | 21 个 LVLM；闭源 GPT-4o、Claude、Gemini 有定性例子 | 两类数据构造微调 | 坐标识别、路径追踪辅助任务 | 位置、尺度、朝向、上下文四类变化 | "LVLMs exhibit strong visual position bias with higher accuracy at peripheral regions" | "potential improvements through architectural modifications … remain unexplored" | — | F浅 |
| Spatial Attention Bias（[2512.18231](https://arxiv.org/abs/2512.18231)） | 行为 | InternVL2-8B、Qwen2.5-VL-7B 等 7 个，含阿拉伯语微调模型 | — | 阿拉伯语模型排除阅读方向；查训练集标注无"先左"指令 | 左右拼图 | 约 97% 先描述左边 | — | — | F浅 |
| PyPE（2501.10967）、Circle-RoPE（2505.16416）、MHRoPE / MRoPE-I（2510.23095）、RoPE scaling（2509.19191）、D²Pruner（2512.19443） | 修复 | 见第一轮 02 笔记 C2、C3 | 训练为主；RoPE scaling 与 D²Pruner 免训练 | — | — | 见第一轮 | 见第一轮 | 见第一轮 | F¹ |

### 2.4 (d) 剪枝后位置 id

| 工作 | 类型 | 模型族 | 干预类型 | 对照 | 评测稳健性 | 效果数字 | 自认局限（逐字） | 代码 | 层级 |
|---|---|---|---|---|---|---|---|---|---|
| GAP（[2506.21873](https://arxiv.org/abs/2506.21873)） | 定位（因果）+ 修复 | LLaVA-v1.5-7B、Llama-LLaVA-NeXT-8B、LLaVA-v1.6-13B、MiniGPTv2、Shikra（**LLM 全是 Vicuna / Llama 2 / Llama 3**） | 推理时免训练：保留原位置 id 的顺序与数值 | 把"顺序错位"与"数值压紧"两种错位分开测（LLaVA）；4 种剪枝准则含随机；多种剪枝率 | RefCOCO / + / g；GQA、VizWiz、OKVQA | LLaVA RefCOCO val 56.14 → 15.34（剪枝）→ 51.42（GAP）；五个模型提升 23%–75%；MiniGPTv2 剪 1% 即 87 → 18 | 无局限小节 | 未核到 | F |
| IVC-Prune（[2602.03060](https://arxiv.org/abs/2602.03060)，ICLR 2026） | 定位（论证 + 消融）+ 修复 | Qwen2.5-VL-7B、InternVL-2.5-8B、DeepSeek-VL2-Small-16B、LLaVA-v1.5 | 推理时免训练：保留原位置 id，另保留 RoPE 旋转矩阵近似单位阵或 90° 的"隐式坐标 token" | 与其他 token 模式对比（Table 6）；在 Qwen2.5-VL 上复现 SparseVLM 关掉聚类合并（即不重建位置 id） | 20 个基准；剪枝层用 RefCOCO testA 小子集选 | 约 50% token 保 ≥99%；Qwen2.5-VL 定位 Rel. Avg. FastV 84.7%、PDrop 75.4%、本法 99.6%；SparseVLM 默认 15.3% → 关掉合并 76.1%；InternVL-2.5 只留前景 token 时仍较高 | "the identification of IVC tokens is inherently tied to the mathematical structure of RoPE. Extending this framework to architectures using alternative positional encodings (e.g. learned 2D embeddings) will require additional theoretical and empirical validation."；剪枝层靠验证集选，"motivates further interpretability studies into the distinct functional roles of different layers in LVLMs" | github.com/FireRedTeam/IVC-Prune | F |
| FEATHER（[2412.13180](https://arxiv.org/abs/2412.13180)） | 定位（因果）+ 修复 | SigLIP（及 DINOv2+SigLIP）+ Llama 2 7B，单一 LLM | 推理时：打分时不施加 RoPE + 均匀采样 | 打乱图像 token 位置嵌入：定位任务"drops drastically" | 12 个基准，强调定位 | 去 RoPE 打分：K=3 时定位平均 +183%，K=8 时 +17% | "while removing RoPE for token pruning effectively eliminates positional bias, it may introduce unintended effects on attention weights influencing token selection. Future research could investigate more robust methods for encoding positional information in visually conditioned language models" | 未核到 | F |
| ASAP（[2603.14549](https://arxiv.org/abs/2603.14549)） | 修复 | LLaVA-1.5、LLaVA-NeXT | 免训练：双向软掩码打分 | — | — | 保留 LLaVA-NeXT-7B 99.02% | — | — | F浅 |
| Index-Preserving Token Pruning（ICLR 2026）、FocusUI（2601.03928）、PPE（2510.22936） | 修复 | Qwen2.5-VL / Qwen2-VL 等 | 保留位置索引 | — | 文档、UI 定位 | 检索片段称破坏索引时 ANLS 近零 | — | — | S |

### 2.5 选项顺序 / 位置偏置（专门复查）与文本 LLM 一侧

| 工作 | 类型 | 模型族 | 干预类型 | 对照 | 效果与局限 | 层级 |
|---|---|---|---|---|---|---|
| SteerFair（[2406.03631](https://arxiv.org/abs/2406.03631)，ICML 2024） | 修复（内部干预） | LLaVA-13B、IDEFICS-9B、InstructBLIP-13B | 推理时：在注意力头激活上找"第一个选项更可能对"之类规则的偏置方向并移开 | 与有监督的 ITI（100 / 500 标签）对比；跨数据集迁移方向。**未见随机方向对照** | ScienceQA、MME、VGR 上降低跨选项顺序的标准差。局限："The precise circumstances under which these conditions hold remain unclear."；选项多时效果 "more limited" | F |
| MCQA Selection Bias of LVLMs（2509.16805，EMNLP 2025） | 基准 + 输出层修复 | LLaVA-v1.5-13B、InternVL2_5-8B、Qwen2.5-VL-3B/7B | logit 偏置向量 | — | 把内部分析留给未来（见第一轮 04 笔记） | F¹ |
| Do LLMs Plan Answer Positions?（[2605.01846](https://arxiv.org/abs/2605.01846)） | 定位 + 转向（**出题**时的答案位置，不是答题） | 10 个 LLM + 5 个 VLM | 探针、激活转向 | — | 相邻对象 | F浅 |
| PINE（[2407.01100](https://arxiv.org/abs/2407.01100)，ICLR 2025） | 定位 + 修复（文本） | Llama-3 等；VLM 只有 Fuyu-8B 的 loss 图与 GPT-4V 个例 | 免训练：文档间改双向注意力并按注意力重排 | 去掉文档间注意力的对照 | "causal attention generally favors distant content, but RoPE prefers nearby content"；图注写 VLM "have lower losses … when images are presented at the bottom" | F浅 |
| On the Emergence of Position Bias（2502.01951，ICML 2025）；Lost in the Middle at Birth（2603.10123）；Structural Theory of Position Bias（2602.16837） | 理论（文本） | 2603.10123 用未训练的 Qwen2 与 GPT-2 验证 | — | — | 因果掩码偏向早位置，相对位置编码偏向近处，二者竞争；2603.10123："it is identical with or without RoPE" | A |
| Round and Round We Go（[2410.06205](https://arxiv.org/abs/2410.06205)，ICLR 2025） | 理论 + 实证（文本） | Gemma 7B | — | — | "we argue against the common claim that RoPE is helpful because it helps to decay activations as the relative distance between tokens increases" | F浅 |
| Set-LLM（2505.15433，NeurIPS 2025）、Set-Based Prompting、Found in the Middle（2406.16008） | 修复（文本） | — | 集合位置编码 + 集合掩码 / 注意力校准 | — | 方法先例 | S |

**竞争者计数**：全景表共 38 行、48 篇（合并行按篇数计，2509.21984 两个版本算一篇）。其中以 A7 四个子现象之一为对象的 37 篇（(a) 9、(b) 8、(c) 13、(d) 7），VLM 选项位置 3 篇，文本 LLM 与理论一侧 8 篇。

---

## 3. 各轴最高水位

| 轴 | 目前最好的是谁、做到什么 |
|---|---|
| **模型族数量与多样性** | 行为：FACET-PROBE 18 个模型含三家闭源前沿（F浅）；V²R-Bench 21 个（F浅）。内部因果：(a) Ask Twice 行为 4 族 5 模型，敲除只在 Qwen3-VL-8B；TTT 修补 2 族（Qwen3-VL 只一个数据集、放附录）。(b) SoFA 改掩码 5 个模型。(c) 直接改掩码或位置的干预全在 Llama 系 LLaVA 式模型（CCA、MCA、2603.17228、2505.18605）；跨 4 族的 AGCI 是微调对照，不是对掩码的干预。(d) IVC-Prune 4 族（Qwen2.5-VL、InternVL-2.5、DeepSeek-VL2、LLaVA-1.5）。注意 InternVL3.5 与 Qwen3-VL 的 pointer 头前五名里有四个编号相同（2611.04903），两者当两个独立骨干要存疑（推导：编号重合与共用同一 LLM 骨干相符；骨干谱系本轮没有另行核对）。 |
| **因果对照的严格程度** | Ask Twice：注意力边敲除 + 同尺寸随机 span 对照 + 配对 bootstrap CI + 与结果无关的 250 对样本 + 五项提示消融，并做了一条定量预测检验（差距随图像 token 数从 0.05 升到 0.08 后持平）。相邻对象上 2611.04903 有等量随机头对照。其余：TTT 修补无随机对照；SoFA 无随机掩码对照；CCA 把 RoPE 距离与因果可见性混着改；2509.21984 v2 没有对所主张根因的直接干预；GAP 把两种位置 id 错位分开测，但只在 LLaVA 上。 |
| **评测稳健性** | FACET-PROBE：同序对照估噪声底、IRT 分解、12 数据集、>40 万试验、筛掉含位置指代的多图题。Ask Twice：三基准 + 开放式 VQAv2 + 配对显著性。LAD：5 次打乱、难负例对抗档、4 种编号格式、N 从 2 到 12。 |
| **效果量** | (a) 现象 6–26 点；修后：TTT 把问题在前拉到距图在前 0–4 点以内；问题复述在 Qwen3-VL、InternVL3、LLaVA-1.5 上追平"问题在后"，图像也复述再 +0.024（NaturalBench 组）、Winoground 组 0.318→0.410。(b) 检索任务 LAD 67.5→98.7；一般多图基准 SoFA +2~3 点、不一致率约 30%→5–17%。(c) AGCI 把 LLaVA-v1.6 的位置方差 14.93→8.05；CCA POPE +5~8 点（相对各自重训基线）。(d) GAP 15.34→51.42（原 56.14 的 90%）；IVC-Prune 50% token 保 ≥99%。 |
| **任务与数据广度** | FACET-PROBE 5 个面 12 数据集；IVC-Prune 20 个基准；Ask Twice 含开放式生成；SoFA 含 ICL、100 图长上下文、视频（MVBench）。 |
| **是否免训练** | 是：Ask Twice（纯提示，+1% token）、LAD（单次前向 + 5 条标定）、GAP、IVC-Prune、SoFA（σ 要 32 条验证集）、Delimiter scaling、UAC、BaPA（v1）。否：TTT（两次前向 + 至多 10 步梯度）、DOCD（两路解码）、FOCUS（N+1 次前向）、CCA / MCA / PyPE / MMA（重训）、AGCI（LoRA）、PeRL（RL）。 |
| **是否给出统一解释** | 没有一篇在 VLM 上把四个子现象放进同一解释并检验。部分统一：PINE（一张图里并列文本文档顺序与 VLM 图内位置，归到因果注意力 + 位置嵌入，分析只在文本 LLM）；SoFA（多图 ← 位置嵌入 + 因果注意力，只测了后者）；Ask Twice（图文顺序 ← 读出距离，另加因果掩码下看不到整图）；2509.21984 v2（图内 ← 因果掩码错配，引 SoFA 作多图同类）；DOCD（图文顺序 ← 因果注意力下的融合路径 + 预训练语料以图在前为主）。文本 LLM 一侧有三篇理论给出掩码与位置编码竞争的闭式刻画。 |

---

## 4. 竞争解释与事实约束

### 4.1 事实约束（实测否定或收窄了某条路）

1. **(a) 在默认约定下不出现，且提示就能修大半。**模型卡普遍推荐图在前（Ask Twice 引言列了 Gemma 3、LLaVA、InternVL3、Qwen2.5-VL、Qwen3-VL 的模型卡；DOCD 写 "most leading models—including LLaVA, Qwen2.5-VL, MiMo-VL, and InternVL […]—recommend a prefix-ordered input format"）。问题复述在 Qwen3-VL 上 0.350 对"问题在后"0.351。例外：Qwen2.5-VL 上复述只到 0.191（"问题在后"0.277），要连图像一起复述才到 0.276。— [2607.15565](https://arxiv.org/abs/2607.15565) Table 3、8，F
2. **(a) Gemma-3-27B 无差距；思考模式缩小差距。**Gemma-3 NaturalBench −0.006（p=.62）。Qwen3-VL-8B 思考版 MMStar 差距 7.2（指令版 19.0），RealWorldQA 5.0（6.1）。— 2607.15565 Table 7；[2607.20351](https://arxiv.org/abs/2607.20351) Table 7，F
3. **(a) TTT 的修复不依赖定位出来的层带。**层窗消融里所有窗口都恢复 25 点以上；附录 D 写 "order consistency can be restored regardless of which layers are updated"。— 2607.20351 Table 3、附录 D，F
4. **(a) 加交错数据微调不消除图文顺序偏置。**"merely exposing the model to more interleaved training data is insufficient to eliminate vision–text order bias"。— DOCD §5.3，F
5. **(b) 注意力对、logit 错。**"while the final output logits are heavily corrupted by positional priors, the model's internal attention weights remain semantically aligned with the target visual region"，三族。— [2605.11591](https://arxiv.org/abs/2605.11591)，F
6. **(b) SoFA 不稳定复现。**LLaVA-OneVision 上 N=4 随机档 59.70 对原模型 67.52，对抗档 43.26 对 49.56；N=8 时略高（32.16 对 31.56）。LAD 的解释："the bidirectional mask used at inference is not the mask the model was trained under"。— 2605.11591 Table 8，F。SoFA 自己也写隔离与双向掩码都掉点、σ 逐任务差别大（F）。
7. **(b) 多图基准里许多题面本身含位置指代。**FACET-PROBE 筛掉 Mantis-Eval 70 条里的 52 条。SoFA 的"位置无关任务"子集是否做了同类筛查，原文只说选了 "position-agnostic questions"。— [2606.26079](https://arxiv.org/abs/2606.26079)，F浅
8. **(b) 提示指令与 CoT 修不了候选位置偏置。**Instruction 提示（明说"图片已随机打乱，请公平看待"）在 Qwen2.5-VL-3B 上 48.96（原 51.70）、LLaVA-OV 50.50（原 67.52）；CoT 在 InternVL3 上有帮助（69.04→77.96），在 LLaVA-OV 上变差（45.40）。四种编号格式下偏置都在。— 2605.11591 Table 1、Fig. 8，F
9. **(c) 直接改掩码的效应是局部的。**图像块内双向掩码重训后，受益集中在最前面几个 token；"Beyond these early positions, causal and bidirectional attention produce comparable representations"；POPE 基本不变。单一 LLM（Vicuna-7B）、每格一次训练、未报种子。— [2603.17228](https://arxiv.org/abs/2603.17228) §5、Table 1，F
10. **(c) 各模型偏置形态不同。**LLaVA-1.5 的空白图注意力沿光栅递增，mPLUG-Owl2 与 LLaVA-NeXT "displaying arbitrary attention distributions"（[2502.01969](https://arxiv.org/abs/2502.01969)，F）；InternVL 与 Qwen 偏外围（2512.19443，F¹）；21 个 LVLM 总体外围更准（[2504.16727](https://arxiv.org/abs/2504.16727)，F浅）；Qwen 系 MRoPE 注意力集中在每张图左上角（2510.23095，F¹）；左右拼图约 97% 先说左边（2512.18231，F浅）。
11. **(c) 新一代不一定更轻。**同一探针上 Qwen3-VL-8B 的位置方差 5.98，Qwen2.5-VL-7B 为 1.54；Qwen2.5-VL 随规模 1.54（7B）、0.25（32B）、0.95（72B）。— [2509.21984](https://arxiv.org/abs/2509.21984) Table 1，F
12. **(d) 保留原位置 id 已是通行做法。**GAP、IVC-Prune（F），Index-Preserving、FocusUI、PPE（S）。IVC-Prune 在 Qwen2.5-VL 上复现："the merging operation and consequent position ID reconstruction are the dominant sources of error"。剩下的掉点转到 OCR 与高剪枝率（2511.02650，F¹），偏能力型。
13. **(d) LLM 确实用位置信号做定位。**打乱图像 token 的位置嵌入后定位"drops drastically"，其他基准"relatively little"（[2412.13180](https://arxiv.org/abs/2412.13180) §A4，F）。这与"置换几乎不掉点"（2503.17349，F¹）合起来说明位置信号的作用依任务而定。
14. **前沿闭源模型仍然翻转**（最好的 13.4%），提示级缓解不跨模态迁移。这同时是现象仍在的先例支持；内部无法验证。— 2606.26079，F浅
15. **方法学约束。**(i) 推理期改掩码属分布外输入（上面第 6 条）。(ii) 末 token 修补：2607.20351 的"中层窄带"是只换最后一个 token 的隐藏状态得到的；早层换了以后后续层会从未改动的上下文重新读入，晚层换了等于直接搬运答案，所以"早层无效、中层陡升、之后持平"是末 token 修补的一般形状（推导；Ask Twice 对比两篇时写 "we localize a mechanism rather than a region"）。(iii) 注意力敲除可能触发备用通路："ablation-based interventions can reveal what models could do rather than what they normally do"（[2607.03358](https://arxiv.org/abs/2607.03358)，三族，F浅）。(iv) 对比解码在 POPE 上的增益被指主要来自单向偏移与贪心化（2504.10020，S），DOCD 属这一类方法。

### 4.2 竞争解释（同一现象的其他已发表解释）

- **(a) 图文顺序，四种说法**
  1. 读出距离：问题被几百个图像 token 隔开，答案位置读不到它；"perceptual steering and decoder access are dissociable, and the paradox lives entirely in access"（Ask Twice，Qwen3-VL-8B 敲除，F）。
  2. 中层窄带表征分叉、后层 MLP 部件重合度低（TTT，F）。与第 1 条不矛盾，但 TTT 没有区分"问题信息没到末 token"与"到了但表征不同"。
  3. 训练分布：预训练语料以图在前为主（DOCD）；Ask Twice 的消融也显示内容相同的 SITIT 比 STITI 高 2 点，"order-robustness is learned"。但 DOCD 同时报告加交错数据微调不够。
  4. 文本 token 在前加重偏文本（Words or Vision，Phi-3.5）。
- **(b) 多图顺序，四种说法**：图间因果注意力（SoFA）；继承 LLM 的位置偏置（SoFA 引言同时这么写，未检验）；决策层位置先验（LAD）；图像区分不足、分隔符 token 作用不够（Delimiter Token Scaling、FOCUS；FOCUS 明说自己处理的串扰与 SoFA 的位置偏置是两个失败）。
- **(c) 图内位置，六种说法**：RoPE 长程衰减（CCA、FEATHER、MCA-LLaVA、ASAP、PyPE）；位置分配不均（2509.21984 v1）；因果注意力与 ViT 双向注意力错配（同号 v2；2603.17228 部分支持但效应局部）；位置嵌入类型——"LLaVA's absolute embeddings … while the relative embeddings (e.g., RoPE) in InternVL and QwenVL"（D²Pruner，"We posit"；这句对 LLaVA 的描述与 CCA 附录 "RoPE is densely involved in LLaMA" 不符，推导）；视觉编码器与对齐模块（V²R-Bench："the vulnerability primarily stems from the upstream vision encoder and multimodal alignment module"，与 2509.21984 的"不在编码器"相反）；架构因素而非阅读方向或标注（2512.18231）。
- **(d) 剪枝后崩溃，四种说法**：位置 id 错位（GAP）；打分的 RoPE 偏置（FEATHER）；丢了隐式坐标 token（IVC-Prune，且称早层剪枝敏感 "arises from the removal of IVC tokens rather than pruning itself"）；保留 token 空间不均匀（D²Pruner 等）。没有一篇在同一设置里分账。
- **文本 LLM 一侧**：因果掩码偏向早位置、RoPE 偏向近位置，二者竞争（2502.01951、PINE）；U 形在初始化时就有、有无 RoPE 相同（2603.10123）；RoPE 并不必然带来衰减（2410.06205）。

### 4.3 专题：四个子现象是否已被归到同一根因

- **现有证据的形态**：论证级的统一说法出现在多篇引言里——SoFA "LVLMs may inherit the notorious position bias from their language component"；LAD "applying this architecture to non-temporal visual sequences introduces unintended asymmetries"；2509.21984 "As LVLMs inherit the autoregressive LLM backbone, these position biases naturally extend to multimodal settings"；PINE 图 1 把 VLM 图内位置与文本文档顺序并列。检验级的没有：没有找到在同一协议下用同一干预检验 ≥2 个子现象的工作（对象层与结论层；专门查询 4 条，相关 13 条）。
- **支持"共用因果掩码"的零散因果证据**：(b) 改图间掩码后位置偏置下降（SoFA，5 个模型）；(c) 图像块内双向掩码救回最前面的 token（2603.17228）；放开视觉 token 的未来掩码在部分任务上涨（2505.18605）；(a) 把图像再给一遍使第二份能看到整张图，Qwen3-VL +0.024，而本来就双向的 Gemma-3 上不涨（Ask Twice 附录 C，掩码类型是作者读各模型代码得到的）。这些都只在 Llama 系或 Qwen 系的单族上，且效应量小于各子现象自身的幅度。
- **指向"各有各的解释"的证据**：(a) Ask Twice 把主效应归到读出距离而不是掩码下的图像整体可见性，并写 "Two effects combine"；(b) LAD 显示注意力没错、错在 logit，且改掩码在另一模型上适得其反；串扰被两篇论文当作与位置偏置不同的失败；(c) 偏置形态因模型而异，改掩码的效应局部；(d) 是一次工程操作毁掉了模型依赖的位置信号，修法是不要重排——它和 (c) 共用"视觉 token 的位置索引"这个部件，但失败逻辑不是"被强加顺序"（推导）。
- **结论层占位情况**：E1 那句话没有找到有人写出并检验（结论层，查询同上）。E3 没有找到（对象层，同上）。

### 4.4 专题：RoPE 归因的争议现状

- **支持方（全在一维 RoPE 的 Llama 系 LLM 上）**：CCA（LLaVA-1.5；光栅与反光栅重训后空间分布翻转；第一层注意力有无 RoPE 对比）；FEATHER（SigLIP + Llama 2；打分去掉 RoPE 后定位大涨；原文归因句用 "We predict"）；MCA-LLaVA（LLaVA-1.5，另"InternVL-7B"其 LLM 为基于 LLaMA2 的 QLLaMA）；ASAP、PyPE（论证）。
- **反对方**
  - [2509.21984](https://arxiv.org/abs/2509.21984) 两个版本都写 "the bias should not be attributed to the long-term decay property of RoPE"，依据是：五个模型上准确率与 token 距离相关性差；Qwen2.5-VL 上换分辨率偏置形态不变，"lower-resolution inputs even exhibit more severe bias at positions farther away from the text tokens"。**但正面归因换过**：v1（2025-09，题为 From Bias to Balance）写 "the underlying issue lies not in long-term decay but in unbalanced position assignment"，修法 BaPA 是给所有图像 token 同一个位置嵌入、免训练；v2（2026-02）删去 BaPA，改归 "a mismatch in attention mechanisms between the vision encoder and the large language model"，修法改成需 LoRA 的 AGCI。v2 全文不再出现 BaPA，也没有解释更换原因。v2 没有对掩码的直接干预。
  - 这篇的分辨率检验做在 Qwen2.5-VL 上，它用的是二维 MRoPE；CCA 的主张针对一维 RoPE 下的光栅距离。两边不在同一设置里（推导）。
  - [2502.01969](https://arxiv.org/abs/2502.01969)："a predefined token reordering strategy cannot generalize well to LVLMs beyond LLaVA-1.5"；对比表脚注 "CCA is only applicable for LLaVA-1.5"。
  - 2603.17228 的直接掩码干预（上面事实约束 9）给"因果掩码错配"一个上界：有，但局部。
  - 文本一侧：2410.06205 反对"RoPE 因衰减而有用"；2603.10123 称 U 形与 RoPE 无关；PINE 称掩码与 RoPE 方向相反。
- **CCA 自身的混杂**（推导）：反光栅模型把视觉 token 的序列顺序整个倒过来，RoPE 距离和"谁能看到谁"同时翻转；CCA 的方法也同时改位置对齐与因果掩码。所以它的证据支持"序列顺序决定空间分布"，不能单独指向 RoPE。
- **现状**：未决。没有找到在 ≥2 个模型族上把掩码可见性、序列顺序、位置 id 三者分开的析因实验（对象层；专门查询 3 条：第 6 步第 1、7 条，第 3 步第 3 条）。

### 4.5 专题：便宜办法与新一代模型

| 子现象 | 便宜办法是否已让它在实际使用中不成问题 | 新一代模型上是否减弱 |
|---|---|---|
| (a) | 默认图在前即避开；必须问题在前时复述问题即可（Qwen2.5-VL 例外）。作者主张仍会遇到的场景：先陈述任务再附图的智能体管线、多轮对话、交错文档（Ask Twice、DOCD 的论述，没有使用频率数据）。 | Qwen3-VL-8B 差距小于 Qwen2.5-VL-7B（NaturalBench 0.081 对 0.175）；Gemma-3-27B 无；思考模式进一步缩小。前沿闭源在混合模态排序上仍翻转（FACET-PROBE）。 |
| (b) | 指令提示、CoT、换编号格式修不了候选位置偏置（LAD）。分隔符 token 模型本来就有，去掉掉约 10 点，放大它再涨 2–5 点（Delimiter scaling）。**没有找到以"是否给图片加文字编号"为主变量的对照**（对象层，专门查询 1 条）。第一轮关于 FOCUS 的那句不适用（见文首更正）。 | LAD 的三个模型都是 2025 年的；视频上 Gemini 2.5 Pro 位置偏置最小；"Positional bias is significantly alleviated as model size increases"；对商用模型偏置小的原因作者用 "We speculate"（Video-LevelGauge，ICLR 2026，F浅）。 |
| (c) | 改分辨率不改变偏置形态（2509.21984）。换提示：未找到。 | 不单调（上面事实约束 11）。 |
| (d) | 保留原位置 id，零成本。 | 不适用。 |

### 4.6 专题：选项顺序 / 位置偏置在 VLM 上的内部定位（专门复查）

- 本轮专门查询 5 条（第 6 步第 5、11 条，第 4 步后 3 条）；连同第一轮的 7 条共 12 条。
- **内部干预**层面已有 ≥2 族的工作：SteerFair（ICML 2024），三个 VLM 族，在注意力头激活上移除偏置方向。旧模型；未见随机方向对照；不回答"哪些头、为什么"。
- **内部相关读数**层面：LAD 在 3 族上给出"图片候选位置偏置"的注意力—logit 背离。
- **内部定位**（对选项位置或字母偏置做激活修补、头消融并带随机对照，≥2 个 VLM 族）：没有找到（对象层，12 条查询）。最接近的是出题侧的 2605.01846（探针 + 转向，含 5 个 VLM，对象不同）和文本 LLM 的 2601.03914、2407.15018、2405.03205。
- 一条反向的行为数据：VMMU 报告打乱选项只改变准确率约 0.33%（2508.13680，S，未核）。

### 4.7 专题：文本 LLM 的同类结论是否使 VLM 结论成为推论

- **(b) 的修法是推论**：SoFA 的操作（把段间因果注意力改成双向）与 PINE（2024-07，ICLR 2025）相同，对象从文档换成图片。方法层被占；对象层被 SoFA 占。
- **(a) 的修法接近推论**：Ask Twice 自己把它连到 lost in the middle 与问题复述文献（"prompt repetition helps most when the query sits far from the answer position"，引 Leviathan et al.）。它在 VLM 上多出来的是"感知被引导"与"读出失败"的分离。
- **(c) 的方向不是推论**：文本理论说因果掩码偏向早位置、RoPE 偏向近位置。图像 token 排在指令之前时，两者对"左上角"的作用相反，净效应取决于模型（类比）。这与各模型偏置形态不同相容，但没有人在 VLM 上检验过这条预测（对象层，第 1、3 步共 9 条查询）。
- **视频与长上下文**：Video-LevelGauge（27 个模型，五类偏置形态）、多视频摘要（2606.04596，S）、Visual Haystacks 与 MMNeedle（S）都停在行为层；SoFA 在 100 张图上 +5.9 点。

---

## 5. 作者留下的开口（逐字，已核对）

- "a full cross-family circuit analysis remains future work" — 2607.20351 §6
- "A natural next step is to make this causal account more precise." — 2607.20351 §6
- "activation patching would localize the circuit beyond our knockout" — 2607.15565 §8
- "we cannot say whether the paradox fades with scale, with bidirectional attention, or both … separating these causes needs models that vary scale and attention independently" — 2607.15565 §8
- "order-robustness is learned; mixing section orders during instruction-tuning may remove the paradox at the source" — 2607.15565 §8（作者用 "suggests" 与 "may"）
- "closed models and long-form generation beyond VQAv2 remain future work" — 2607.15565 §8
- "Whether the position bias in LVLMs is correlated with that of their LLM backbones remains an interesting question for further exploration." — 2503.13792 §3.2
- "does not straightforwardly extend to open-ended generative tasks" — 2605.11591 附录 A
- "it does not completely eliminate all order effects on every dataset" — DOCD §5.4
- "These results suggest that prompt-level mitigation alone is unlikely to provide general order robustness, motivating future work on training-time and architectural approaches." — 2606.26079 摘要
- "Investigating whether the identified spatial bias persists or evolves in larger-scale models remains an important direction for future work." — 2509.21984 v2 Limitations
- "Future research could investigate more robust methods for encoding positional information in visually conditioned language models to prevent positional artifacts in cross-modal interactions." — 2412.13180 §5
- "Extending this framework to architectures using alternative positional encodings (e.g. learned 2D embeddings) will require additional theoretical and empirical validation." — 2602.03060 §5.2
- "our conclusions might not generalize for significantly different architectures" — 2603.17228 §6
- "The precise circumstances under which these conditions hold remain unclear." — 2406.03631 附录 B
- "our focus is only limited to handling of image-text inputs" — 2410.15926 §6
- "We speculate that this difference may be attributed to the longer training contexts and larger parameters of commercial models" — 2508.19650 §4
- 第一轮已摘（F¹）："will provide more comprehensive analysis of model-specific attention patterns across different architectures" — 2509.16805；"it serves only as a localized remedy for potential limitations in RoPE" — 2509.19191

另两处引用核对中发现的问题（供引用时注意）：2607.20351 称 Hejabi et al. (2025)（Flip-Flop Consistency，2510.14242）"document that image-first prompting outperforms question-first"，该文正文里检索不到 image、VLM、vision 等词，是一篇文本 LLM 论文；2607.20351 的 Table 1 与 Table 5 对 Qwen2.5-VL / RealWorldQA 给出两组不同基线（60.0 / 67.8 对 63.8 / 70.2），正文一句"exceeding the image-first baseline of 61.8%"对应的数是 60.0。

---

## 6. 三列表

| 先例支持 | 事实约束与竞争解释 | 谁会因此改做法 |
|---|---|---|
| 四个子现象都在 ≥2 个模型族上被实测，(a)(b) 含 2026 年前沿闭源模型（FACET-PROBE） | (a) 默认约定避开、提示可修、Gemma-3 无、思考模式缩小（4.1 第 1–2 条） | **评测与基准维护者**：固定并报告输入顺序、报告跨排序翻转率。已有两篇这样呼吁（Ask Twice："protocols should fix and report it"；FACET-PROBE："We propose cross-ordering flip rate as a standard reporting axis"） |
| (a) 有带随机对照的注意力敲除机制证据（单模型）与 2 族末 token 修补 | (a) 四种解释并存；TTT 的修复与定位带脱钩（4.1 第 3 条） | **智能体与管线开发者**：图在前，或把问题在图后复述一遍。做法已由 Ask Twice 给出 |
| (b) 改图间掩码在 5 个模型上降低不一致率（SoFA） | (b) 注意力对、logit 错；SoFA 在 LLaVA-OV 上不如原模型；串扰是另一个失败（4.1 第 5–6 条、4.2） | **多图检索或排序系统的使用者**：单次前向的 logit 校正（LAD）或置换平均。已给出 |
| (c) 5 个模型上同一探针测到位置敏感；LLaVA-1.5 上有重训对照 | (c) 六种解释并存；RoPE 争议未决且反对方自己换过归因；直接掩码干预效应局部；各模型形态不同（4.1 第 9–11 条、4.4） | **训练新模型时决定图像块内掩码与位置编码的人**：未找到这类团队说明会依据什么证据改哪一步的直接表述。间接线索：Gemma 3 与 PaliGemma 已对图像块用双向或前缀掩码（Gemma 3 一项仅据 Ask Twice 作者读代码的陈述；PaliGemma 消融：把自回归掩码扩到图像 token "perform clearly worse"，F浅）；Qwen 团队发了 MHRoPE / MRoPE-I。Ask Twice 自认分不开规模与掩码（推测：这一处若被分开，是这类人会看的证据） |
| (d) 位置 id 错位在 Llama 系 5 个模型上有免训练因果证据，并在 Qwen2.5-VL 上被复现 | (d) 已有通行修法；剩余掉点偏能力型（4.1 第 12 条） | **剪枝方法作者**：保留原位置 id。已普遍采用 |
| 文本 LLM 一侧有掩码与位置编码竞争的理论与免训练修法 | (b) 的修法是文本结论的推论；(c) 的方向不是（4.7） | 未找到 |
| 选项位置偏置：3 族内部干预（SteerFair）、3 族注意力—logit 背离（LAD） | 文本去偏方法迁移到多模态多为负（LREC 2026，F¹）；末 token 修补在 VLM 上的解释局限 | **多选基准的使用者**：循环或全排列评测。已是常规做法 |

---

## 7. 要构成足够贡献至少需要做到什么（只列门槛）

1. **模型族**：内部因果证据覆盖 ≥3 个骨干无亲缘的模型族，超过 Ask Twice（机制 1 族）、TTT（修补 2 族，第二族只一个数据集）与 IVC-Prune（4 族，但只针对 (d)）。共用同一 LLM 骨干的模型不计为两族。其中需含至少一个对图像块用双向或前缀掩码的模型，以越过 Ask Twice 自认分不开的"规模还是掩码"。
2. **因果对照**：在同一设置里把因果掩码可见性、token 序列顺序、位置 id / RoPE 三者分开的析因干预，并带随机对照（同尺寸随机 span、等量随机头或随机置换）。需超过：CCA（三者混着改）、2509.21984 v2（无直接干预）、SoFA（无随机对照）、TTT（末 token 修补无随机对照）、Ask Twice（单模型敲除）。
3. **跨子现象**：若主张同根因，同一协议同一干预至少覆盖两个子现象，并正面处理三条现有反证——LAD 的注意力对而 logit 错、SoFA 在 LLaVA-OneVision 上不如原模型、2603.17228 的掩码代价只在最前面几个 token。现有最高水位是 Ask Twice 在一篇里触及图文顺序与图像整体可见性，但把它们称作两个机制。
4. **RoPE 争议**：在同一批模型（一维 RoPE 与 MRoPE 各 ≥1 个）上同时复做 CCA 的反光栅对照与 2509.21984 的分辨率扫描，并加入对位置编码与掩码各自的直接干预。现有两方不在同一设置。
5. **评测稳健性**：不低于 FACET-PROBE（同序噪声底、筛掉题面含位置指代的多图题、含闭源前沿模型的行为数据）与 Ask Twice（配对显著性、开放式生成），即不能只报多选题、不能只报一种排列对比。
6. **效果量，相对便宜基线**：修复要在便宜办法之上仍有增益，或在便宜办法失效的条件上有增益。各子现象的便宜基线：(a) 默认图在前、问题复述（Qwen3-VL STIT 0.350、SITIT 0.374）；(b) LAD（检索 94.9–98.7%）与置换平均；(d) 保留原位置 id（50% 剪枝 ≥99%）。已知便宜办法失效或不足的条件：Qwen2.5-VL 上问题复述欠恢复；对抗档 N=8 的多图检索（LAD 55.34，置换平均 60.16）；开放式生成（LAD 不适用）；(c) 没有便宜办法。
7. **成本**：免训练，且推理开销不高于 Ask Twice 的问题复述（+1% token）或 LAD（单次前向 + 5 条标定）；现有带训练或多次前向的方法（TTT、DOCD、FOCUS、AGCI）都高于这一线。
8. **统一解释的可检验性**：给出能同时容纳"各模型偏置形态不同"的定量预测（LLaVA-1.5 偏底部、Qwen 与 InternVL 偏外围、MRoPE 左上角、GPT-4o 多图 U 形、开源模型多图近因），而不是只解释一维 RoPE 的 Llama 系。文本一侧已有闭式理论（2502.01951、2603.10123、2602.16837），VLM 一侧的门槛是把它落到带图像 token 的实测上。
9. **新一代模型与思考模式**：在 Qwen3-VL、InternVL3.5、Gemma-3 一代以及思考模式下报告现象幅度。现有数字是：思考模式把 (a) 从 19.0 降到 7.2；Gemma-3-27B 上 (a) 为零；(c) 在 Qwen3-VL 上反而大于 Qwen2.5-VL。
10. **若把选项位置偏置纳入**：需超过 SteerFair（3 族、头级转向、无随机方向对照、2023 年的模型）与 LAD（3 族、相关级），即带随机对照的内部定位，≥2 个当代 VLM 族。
11. **基准形态的贡献**：需超过 FACET-PROBE 的五个面与 18 个模型；它没有覆盖的是图内位置 (c) 与剪枝 (d)，以及任何内部读数。

---

## 8. 七步检索日志

### 第 6 步 对抗式检索（先做）— 13 条

1. VLM spatial bias not caused by RoPE long-term decay causal attention
2. image-question order sensitivity vision-language models prompt fix "image first"
3. multi-image position bias LVLM image order permutation robust newer models
4. position bias transformers causal masking residual connections U-shaped "lost in the middle" not positional encoding 2603.10123
5. VLM multiple-choice option position bias attention heads activation patching vision-language mechanistic
6. visual token pruning position IDs preserve original positions grounding collapse Qwen2-VL InternVL fix training-free
7. concentric causal attention CCA fails to generalize Qwen InternVL position bias "does not" replicate RoPE hallucination
8. Order Matters: Exploring Order Sensitivity in Multimodal Large Language Models 2410.16983
9. multi-image VLM image index tokens "Image 1:" delimiter reduces position bias order sensitivity ablation
10. order-invariant training multi-image MLLM permutation augmentation removes image order bias fine-tuning
11. vision-language model answer option order bias mechanistic interpretability steering vector LLaVA InstructBLIP IDEFICS permutation
12. VLM in-image position bias center bias object location benchmark GPT-4o Gemini Qwen2.5-VL "position" robustness same object different location
13. bidirectional attention image tokens decoder VLM instead of causal mask improves "prefix" PaliGemma Gemma 3 image tokens bidirectional ablation

- **命中**：Ask Twice 与 DOCD（提示与解码级修法）；LAD（SoFA 不复现、注意力—logit 背离）；IVC-Prune（(d) 的 4 族修法）；2502.01969（CCA 不泛化）；2603.17228（直接掩码干预）；SteerFair；2603.10123 与 2602.16837（与 RoPE 无关的 U 形）；Delimiter Token Scaling；PeRL；V²R-Bench；2512.18231。
- **未命中**：在 Qwen 或 InternVL 上跑 CCA 官方代码的复现；以"给图片加文字编号"为主变量的对照；证明定位结果与随机对照分不开的工作（针对 2607.20351 的复核）。

### 第 5 步 引用链挖掘

- **Semantic Scholar 被引列表**：成功 2 篇——SoFA（32 条被引，全部过目）、CCA（82 条，全部过目）。失败 5 篇（2509.21984、2506.21873、2607.20351、2607.15565、2602.03060，三轮重试均返回 429）。
- **参考文献列表**：从正文通读 2607.20351 全部参考文献、2607.15565 第 1–26 条；2509.21984、SoFA、LAD 按引用处定位。
- **补充网页查询 3 条**：(14) "Mitigating Vision-Text Order Bias in Vision-Language Models" CVPR 2026 Findings；(15) "Heads That Write, Not Just Point" 2611.04903；(16) "question-first paradox" OR "modality order" … follow-up。
- **OpenReview**：搜索接口取到 CCA 的 forum id（CIRPE1bSmV，NeurIPS 2024 poster）与 IVC-Prune 的条目（ICLR 2026 Poster）；取审稿内容的接口与网页都要求人机验证，**审稿讨论一篇也没读到**。
- **由引用链找到的**：DOCD（CVPR 2026 Findings，SoFA 的被引）、2611.04903、MMA（2503.02597，CCA 的被引）、2502.01969（经 2509.21984 的 "Zhu et al. 2025c"）、Words or Vision 与 Flip-Flop Consistency（2607.20351 的参考文献）、Promptception 与 Order Matters（2607.15565 的参考文献）、Video-LevelGauge、ID-Align、TokenPenalty、DAPE-BR、"What drives attention sinks?"（后三者只有标题）。
- **未命中**：引用 2607.20351 或 2607.15565 的后续工作（唯一一条查询只返回这两篇本身）。

### 第 1 步 抽象阶梯 — 5 条

模板："带因果掩码与一维位置编码的序列模型处理二维、多段或无序输入时，序列化顺序被当成语义顺序。"
1. position bias LLM mechanism causal attention relative positional encoding "PINE" eliminating position bias bidirectional inter-segment attention
2. order-invariant LLM set-structured input permutation invariance attention mask position ids "Set-LLM" OR "set-based prompting"
3. video LLM positional bias frame position "lost in the middle" video context mechanism mitigation Video-LevelGauge
4. lost in the middle cause positional hidden states attention bias calibration "found in the middle" Ms-PoE training data recency primacy explanation
5. serialization order bias table graph LLM row column permutation sensitivity 2D structure flattened 1D positional encoding

- **命中**：PINE、Set-LLM、Set-Based Prompting、Found in the Middle、Video-LevelGauge、表格行列置换（ROTATOR-LLM、The Power of Order）、多视频摘要位置偏置。
- **未命中**：语音模型里的同类内部解释（只见行为层的 2510.00628、2609.34223，S）。

### 第 2 步 方法论单独搜 — 5 条

1. activation patching limitations last token patching interpretation pitfalls "best practices" metrics corrupted prompt out-of-distribution
2. modifying causal attention mask at inference without retraining out-of-distribution degradation bidirectional attention pretrained decoder LLM
3. contrastive decoding VLM gains artifacts "mirage" spurious improvements POPE adaptive plausibility unidirectional
4. RoPE long-term decay not learned attention "what makes rotary positional encodings useful" high frequencies semantic low frequencies positional Gemma analysis
5. attention knockout causal tracing vision-language models fallback pathways ablation reveals what models could do not what they do

- **命中**：Heimersheim & Nanda（修补的解释取决于供体提示与指标）；BidirLM（检索摘要转述：只把掩码从因果翻成双向，结果不稳定；未核原文，S）；2504.10020（对比解码增益的来源）；2410.06205；2607.03358。
- **未命中**：专门讨论末 token 修补的方法学论文；测试时训练在 VLM 上的已知失败模式。

### 第 3 步 蕴含检索 — 4 条

1. unified explanation position bias vision-language models causal mask positional encoding image order modality order in-image position single mechanism（扩展模式）
2. permutation-invariant multi-image VLM position encoding images same position id order-invariant inference training-free "order-invariant"
3. "causal" attention "raster" order image tokens VLM spatial bias intervention shuffle token order keep position ids disentangle RoPE mask
4. survey position bias order sensitivity multimodal large language models 2026 taxonomy modality order image order option order

- **命中**：FACET-PROBE（五个面的统一测量，非统一解释）；2506.11063（多模态 RAG 位置偏置，S）；C²RoPE、SoPE（三维，S）。
- **未命中**：E1、E2、E3 三句话的任何一句（结论层）；把四个子现象并列的综述或分类法。

### 第 4 步 同义术语枚举 — 8 条（含选项位置专门复查 3 条）

词表：
- (a) modality order / vision-text order bias / prompt ordering / question-first paradox / prefix vs suffix order / image placement / interleaving order / input order perturbation
- (b) multi-image position bias / image order sensitivity / permutation (in)variance / image-set ordering / cross-image information leakage / image identity confusion / ordinal-matching bias / needle position
- (c) spatial bias / spatial perception bias / image alignment bias / positional attention bias / attention shift / long-term decay / context starvation / top-left attention sink / center–periphery bias / raster-scan bias
- (d) position ID misalignment / position re-indexing / positional preservation / index-preserving pruning / implicit visual coordinates
- 选项：selection bias / option-order bias / answer-moving attack / token bias / label bias / position bias in MCQA

1. "needle in a multimodal haystack" OR "Visual Haystacks" position of needle image accuracy drop index location bias GPT-4o Gemini newer models
2. multimodal in-context learning demonstration order recency bias vision-language attention last demonstration mechanism mitigation
3. "ordinal" OR "index" matching bias multi-image answer refers "first image" "second image" confusion VLM image identity binding mechanism
4. token merging pruning "position" drift MRoPE Qwen2-VL 2D position ids preserved grounding OCR degradation "positional" preservation video LLM
5. "image alignment bias" OR "spatial perception bias" OR "positional attention bias" LVLM top-left attention sink MRoPE Qwen InternVL evaluation fix
6. LVLM "selection bias" multiple-choice internal attention analysis hidden states option position layer-wise where bias emerges vision-language
7. multimodal LLM option order bias "circuit" OR "logit lens" OR "causal tracing" answer letter bias image question Qwen2.5-VL InternVL 2026
8. debiasing option position bias VLM representation-level intervention MCQ "position bias" hidden state direction removal multimodal benchmark permutation consistency 2025 2026

- **命中**：Index-Preserving Token Pruning、FocusUI；多模态 ICL 近因偏置（2404.15736、2510.24331，S）；2509.21984 v1 的 BaPA（由此发现两版归因不同）；2605.01846；VMMU。
- **未命中**：选项位置偏置的 VLM 内部定位（见 4.6）；多模态 ICL 近因偏置的内部解释。

### 查询合计

已执行 38 条（6 步 13、5 步 3、1 步 5、2 步 5、3 步 4、4 步 8）。**未执行 2 条**（会话的网页检索额度用尽）："Beyond the Vision Encoder" 的后续工作；Qwen3-VL 技术报告对 Interleaved-MRoPE 的动机说明与 Gemma 3 图像块双向掩码的官方出处。后一条意味着"Gemma-3 对图像块用双向掩码"这一点本笔记只依据 Ask Twice 作者读代码的陈述。

### 阅读层级计数（分开数）

- **F（读了方法、设定、对照、局限）13 篇**：2607.20351、2607.15565（两篇通读含附录）、2503.13792、2509.21984 v2、2410.15926、2412.13180、2506.21873、2602.03060、2605.11591、2502.01969、2603.17228、DOCD（CVPR 2026 Findings）、2406.03631。
- **F浅（取到正文，按关键词读了相关段落）20 篇**：2509.21984 v1、2606.26079、2508.13744、2602.01984、2504.16727、2407.01100、2410.06205、2505.18605、2503.02597、2503.02199、2611.04903、2607.03358、2407.07726、2507.09184、2603.14549、2410.16983、2605.01846、2508.19650、2512.18231、2506.14907。
- **F¹（第一轮取过正文，本轮未重读）12 篇**：LREC 2026、2509.16805、2512.19443、2505.16416、2510.23095、2509.19191、2501.10967、2503.17349、2511.02650、2502.11501、2601.03914、2511.22341。
- **A（只读摘要）3 篇**：2502.01951、2603.10123、2602.16837。
- **S（只有检索片段或标题）36 篇**：Chou et al. WACV 2026、2603.07048、2603.04676、2609.34223、2510.00628、Index-Preserving Token Pruning、2601.03928、2510.22936、2505.21465、TokenPenalty、DAPE-BR、"What drives attention sinks?"、2602.10551、2602.22716、2505.15433、Set-Based Prompting、2503.23483、2406.16008、2604.02045、LLM2Vec、2504.10020、2404.15255、MMNeedle、Visual Haystacks、2404.15736、2510.24331、2606.04596、2506.11063、2310.01651、2508.13680、2407.15018、2405.03205、ROTATOR-LLM、The Power of Order（2605.00445）、2509.03986、2510.14242（最后两篇取到了正文，只做了"有无相关词"的检索；2407.15018 与 2405.03205 取到正文未读）。另有一条检索片段把 "Behind RoPE: How Does Causal Mask Encode Positional Information?" 标成 2509.21042，下载该号得到的是另一篇（LayerNorm Induces Recency Bias in Transformer Decoders），未采用。

### 第 7 步 边界申报

- **OpenReview 审稿讨论没有覆盖**：接口与网页都被人机验证挡住。CCA、IVC-Prune、Video-LevelGauge、Delimiter Token Scaling、MHRoPE、RoPE scaling 的审稿意见里可能有针对归因的质疑，本笔记没有。
- **被引链不完整**：最近的五篇里只有两篇的被引列表扫到；2607.20351、2607.15565、2509.21984 的被引一条没取到。2026-07 之后引用这两篇图文顺序论文的后续工作是本笔记最可能漏掉的一类。
- **在审稿件与并行未公开工作**：2607.20351、2607.15565、2606.26079、2611.04903 都是预印本，发表去向未知；ICLR 2027 在审稿件不可见。
- **非 arXiv**：只取到 CVPR 2026 Findings 一篇与第一轮的 LREC 一篇；TokenPenalty（ACL 2026）、DAPE-BR（EMNLP 2025）、Chou et al.（WACV 2026）没有取到正文。
- **非英文**：没有检索。
- **闭源模型**：只有行为数据，内部无法验证；GPT-4o 多图 U 形与开源模型近因偏置的差别没有解释。
- **代码仓库**：没有打开任何仓库核对实现（例如各剪枝方法是否默认保留位置 id、Gemma 3 的掩码实现）。
- **知识截止**：本轮依赖在线检索而非记忆；2026-06 之后的工作全部来自检索，其中 2607.x 与 2611.x 的四篇无第二来源交叉核对。
- **数字核对范围**：表中数字来自正文文本抽取；CCA 的 POPE 增益、PyPE、Circle-RoPE、RoPE scaling、D²Pruner、FOCUS 的主要数字沿用第一轮，本轮没有重核。pdftotext 抽取的表格有错位风险，已对 2509.21984 Table 1、2602.03060 Table 1、2605.11591 Table 1 与 Table 8、2603.17228 Table 1 用保留版式的抽取复核。
- **执行环境记录**：中途 /tmp 配额报满，我删除了本次任务自己下载的论文 PDF（保留文本抽取件），没有动其他文件；此后改为下载即转文本即删。
