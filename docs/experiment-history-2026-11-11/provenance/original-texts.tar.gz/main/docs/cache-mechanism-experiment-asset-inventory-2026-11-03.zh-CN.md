# Acupuncture 近期实验资产总盘点与机制主线

> 历史证据快照。后续实验、解释更正和当前边界见[2026-11-04统一归档](RESEARCH_ARCHIVE_2026-11-04.zh-CN.md)。本页原数值与日期保留；旧“尚未／下一步”不作为当前状态。

盘点日期：2026-11-03。证据快照：`f557099946ebe559492c9bedeac41bfc238d95f6`。范围：2026-10-30 至 11-03 的缓存机制、早段定位、跨针眼与跨模型基础资产；更早的实验由[上一份资产盘点](cache-formation-mechanism-asset-inventory-v1-2026-10-31.zh-CN.md)承接。

本文统一说明实验目的、实际操作、结果、相互关系与可复用数据。附录覆盖 **65 个实验/设计/审计目录、4,891 个版本化文件、252,698,180 字节**；[文件级清单](cache-mechanism-experiment-assets-2026-11-03.json)登记全部路径、大小和 SHA-256，包括原始记录、分析、失败尝试和运行收据。服务器大张量的清单与哈希也在资产中，张量本体不等于已进入 Git。

## 1. 我们正在回答什么，已经推进到哪里

核心问题一直是：**少数通道上的干预，怎样改变模型的写入、历史状态处理和后续读取，最终改变目标选择与完整回答。**

这几天的推进分为四段：

1. **形成与承载。** 早段干预会留下持续的状态差异；撤针后仍产生新的写入差异。深层历史能搬运大部分停止侧分数变化，形成期浅层历史的操作又能改变这份深层效应。
2. **V 与行为的分离。** 卷积历史中的 V 是一个有效干预入口。固定 45 头能搬运停止侧分数效应，但不能稳定恢复完整答案。共享首字母任务进一步表明，开始输出编号与选对记录是不同的行为要求。
3. **选择缺口的具体变量。** 在 V 已恢复的背景中，宽窗口仍会留下目标选择错误。简单的注入总量解释不足；末端 q/k 历史的查询身份交换不转移答案，但去除跨场景估计的共同偏移能修复，k 分量承担主要修复效应。
4. **从有效变量走到计算连接。** QKD、QSR 的分解没有支持预设的单项解释。随后 KRD 用历史交换证明，k 修复的相当部分效应经 t1 后历史传递；KHC 在 t2 的 q 固定为供体时，把这份历史效应进一步定位到递推状态 S。KUC 随后完成更新项替换：只改变 t1 新值写入项里的 k，就能复现主要分差效应并改变完整回答；旧预测修正项单独替换很弱。

**当前已经获得一段具体更新计算与完整回答之间的条件性因果连接。** KUC 把有效变量推进到了更新式的新值写入项；KHC 提供了固定 q 条件下的 S 载体证据。接下来需要说明写入改变为何削弱目标优势，并检验这段关系怎样接回未恢复 V 的原生干预及其他模型。

这里有一条已经积累起来的条件性链条：

> 形成期干预 → 末端卷积历史共同 k 偏移 → 去除偏移改变完整回答 → t1 后历史能搬运修复 → 固定 t2 q 时，历史效应主要保存在 G 层递推 S；进一步在 t1 替换更新项，主要效应由新值写入项中的 k 承担。

随机扰动和不致错的 C1343 也能走相似的历史传播路径。因此，传播路径与是否跨过回答边界需要一起解释；不能以“同一路径”代替“同样会错”。

## 2. 读数、样本和符号对照

| 名称 | 实际含义 | 汇总时的处理 |
|---|---|---|
| D | 停止集合最大 logit 减非停止集合最大 logit | 赢家可能变化；与固定 token 分差分开 |
| EOS | 自然下一 token 是否停止 | 不等于完整回答正确 |
| 固定首词分差 | 正确首词/共同首字母相对停止或竞争 token 的分差 | 不替代目标选择与后续交付 |
| M | 后期任务中目标编号相对竞争编号的分差；具体竞争者按合同 | 强制前缀的 C 路线与自然 N 路线分列 |
| Y / Y_full | 自然生成完整正确交付 | 分母包含全部冻结输入；同时记录停止、首条偏好、复述等错误 |
| P、B | QCO/QKF 中修复比例、原错误复现比例 | 按合同先逐场景再汇总，不能随意改成池化比例 |
| 6 个场景×2 事实版本 | 早期常用 12 输入面板 | 同场景两个版本为配对；不是 12 个独立场景 |
| 54 格 | 后期 6 场景×3 排序×3 查询 | 模板、方向、干预臂重复使用这批文本 |
| 48 格 | QST 后冻结的面板 | 目标不排第一的子集为 32；不能与全 48 的比例混用 |
| N4146、N1210、C1343 | 原生通道方向，后期多为 L0、剂量 −1 | R0 等为随机方向；不同方向不是不同模型 |
| G / A | G 为递推层，A 为全注意力层 | 深层 G 共 14 层；注意力 KV 与卷积 k/v 不是同一种资产 |
| F | 早期也用作卷积缓存组名；后期表示 q/k 与 V 均恢复的混合条件 | 后期 F 仍保留受针的其他背景，不是全干净 C |
| V、Rk、Ak | 后期分别为只恢复 V、再去 k 偏移、在 F 上加 k 偏移 | 每一比较使用同一输入与合同规定的背景 |
| H、Q | KRD 中 H 为 t1 后 G 层 S 与 A 层 KV，Q 为 t2 的 q 节点 | KHC 的 S/KV 分解固定 Q 为供体；不外推到 Q 自由响应 |

## 3. 形成期：从持续影响到深层材料

以下每行的目录与完整设计、分析、原始数据入口均在附录 A。

| 实验 | 设计要回答的问题 | 主要数据与结果 | 它使下一步有了什么依据 |
|---|---|---|---|
| early-state stage2-v2，10-30 | 早、中、晚干预，以及历史组移植，哪些改变能进入行为？ | 29,112 条生成、58,224 次候选评分。L0 的新题 TTT 完整交付 0/24，组 4 干净替换为 7/24；中晚段 TTT 仍有 96–100% 交付。历史组 4 去除约 3.2/20.3 的分差，全线性组约 16.4。正式工作量约 10.4 GPUh | 选择早段可见失败作为窗口；历史内部差异必须与行为一起看 |
| CFM-S1 | 原生轨迹中的状态、写入与读取怎样变化？ | 36 条轨迹。L0 的 ΔS/S_C 约 0.81–0.98，L12 约 0.72–0.83；写入与旧状态处理项部分抵消。晚段写入对末端净差贡献约 82–93%。L0 EOS 12/12，L12 0/12 | 状态差异大不自动意味着停止；需要受控时序和操作 |
| CFM-S2 | 同一起点后的写入/处理差异，与早段遗留差异如何区别？ | 84 条轨迹、早/晚窗口 2×2。第一步旧来源处理差约为写入差的一半，方向部分相反；同起点晚段 ΔS 主要来自边界后写入。早段撤针后的写入差异在 L0 为晚段直接扎针的 38–92%，L12 为 13–53%。预测 r10<0.5：L0 0/6，L12 5/6 | 直接观察到撤针后仍在形成新差异；不能用“只携带一份旧误差”概括 |
| fact-signal-native，CPU | 事实区分信号是否已消失，或写入不变而读取坏了？ | 36 个锚点/条件/场景记录；没有发现预设的“v 保持而误差项弱”的类别。L0 的事实差方向明显转动，范数未普遍消失；晚段干预不改之前事实位置的 KV 是时序决定的 | 收缩“内容被抹掉”的说法，转向变化怎样参与更新 |
| CFM-S3 | 分别替换 V、门、k 等，哪个操作改变结果？ | 24 单元×130 条件=3,120 格及参照。晚段停止侧：去 V 的比例 L0 0.62–0.76、L12 0.66–0.89；只保留 V 为 L0 1.06–1.11、L12 0.58–0.93。去衰减门接近 0。撤针后的干净更新+读取仍保留 52–62% 分数效应，但 EOS 12→0 | V 是强入口；分数保留与停止跨界不同；某些事实读数受随机扰动影响大 |
| E2 深度移植 | 深层状态是否足以承载效应？ | 留出 12 输入×9 格；深层 13–31 搬运 75–94% 的 D 变化，6/6 场景强；浅层 0–12 约 10–18%。深层单独移植 EOS 0/12，原生 L0 晚段 8/12 | 确认深层载体，但不把载体当形成起源 |
| FORM-AB v2 | 形成时入口残差与浅层历史，如何影响深层结果？ | 5 条件、60 次形成、72 次评分。A 在 L13 入口减去 L0 残差差，B 每步恢复浅层历史；B 改变停止侧分差约 5.36–9.08。统一评分下 C/X0/XB/XAB 均 EOS 0，XA 2，原生 T 8 | 形成期历史操作能改变深层材料；后续钉住 V 检验连接 |
| FORM-READ-BRIDGE | B 的效应能否通过形成期 V 搬运？ | 9 条件、108 次形成、168 次评分；逐位置钉 V_C/V_T/V_H，其他变量自然响应。V 双向操作有效，但递推 S 单独交叉不足以替代全部效果 | 从“V 有效”转向 V 形成的缓存组合 |
| CACHE-COMBINATION | V 诱导的深层效应保存在 S、卷积 F、注意力 K 的何种组合？ | 36 次新增形成、300 次评分。C→CT 的 S+F 联合搬运约 80.9–90.2%，S 单独 20.4–28.2%，F 单独 39.0–57.1% | 完整缓存组合决定可读出效应，不能以 S 单项大小代替行为贡献 |
| cross-channel-validation | 形成期 V 操作是否只对 N4146 有效？ | −1 剂量覆盖 10 个原生方向与 4 个随机方向，V 加入/去除有可重复的条件效应；−0.5 下方向分化，无对应随机面板 | 存在同模型跨方向复用证据；不是跨架构证据 |

这一段的关键资产是冻结文本、逐步形成记录、同输入的干净/受针缓存、驱动量与大张量哈希。后来各轮不断重放这些端点，建立了实验之间的数值连接。

## 4. V 的停止侧效应为何没有直接给出完整答案机制

| 实验/审计 | 操作与结果 | 推进或停止的理由 |
|---|---|---|
| formation-asset-audit / update-readout-audit / output-path-audit | 已有张量与来源核验；更新恒等式重建；区分动态赢家 D 与固定 token 分差。原生 EOS 8/12，深层混合 0/12；原生停止优势仅约 0.0625–0.75，浅层变化可移动 1.125–4.3125 | 端点差异可以让同一深层材料跨过或不过边界；输出投影大不自动指向可干预的单层机制 |
| LOCAL-readout | 删除 L13 的局部 I/J 项。原生停止变化约 −0.125 至 +0.188，8 个 EOS 不翻；混合背景 I 仅约 2.5% 针效应 | 该局部候选没有承担主要停止效应，分支收束 |
| CONV-factor | 深层卷积 q/k 与 V 的 2×2，在原生和混合背景比较。只留受针 V 可复现原生完整卷积的 94–100% 停止侧效应；Q 的效应依赖 V 背景；去 V 原生 EOS 8/12→0 | q/k 与 V 有条件依赖，不能只按单项份额排序 |
| CONV-path / FV-local-path，CPU | 首个深层共同入口的读出交互为结构零，写入交互非零。直接 V 路径合计仅约实际停止差的 1–12%；正负方向抵消 | 代数结构提供候选，不等于已解释最终行为 |
| VQ-WRITE B1 | 删除 L13 局部 V×Q 写入交互。原生停止 δ −0.04 至 +0.01，0/6 通过，EOS 8/12 不变；混合比例 0.12–0.39，仅 1/6 | 局部交互不承担原生主要效应，不能从混合背景推出原生机制 |
| B1 paired-propagation，CPU | 14–31 层跟踪删除差；36 模块，无稳定候选。随机删除的下游差更大；传播可放大，但停止投影小 | 停止按层追热点 |
| B2 V-subset×Q | 45 头 H 与其余 403 头 R 的 V 因子，交叉 Q。Q 效应在所有 V 干净时 0.80–1.87，所有 V 受针时 0.01–0.23；答案读数与停止读数方向不同 | 固定小子集的意义要在留出输入和不同读数上检验 |
| B2 computation-followup，CPU | 局部投影占比约 ±0.04，0/6；末层总和亦未达跨场景要求 | 没有选出单个计算候选 |
| C1P 固定头规则前瞻 | 6 新场景、12 输入。固定旧 45 头保留完整 V 的 98–107% 停止效应；自适应 45 头 93–109%。答案侧固定头仅约 35–46%（该答案分析为修正后的描述） | 固定集合确有跨文本停止侧复用，接着跨针眼验证 |
| C2 跨方向 | N4146/N1210/R0/R1，固定 45 头停止保留约 98–156%；答案侧约 33–60%。R0 原生仅 1/12 EOS，固定头操作可为 6/12 | 方向间可重复的是条件分数效应，不是统一自然行为 |
| B3 固定头×其余头 | 其余头自身正效应约 0.42–1.68，交互负效应约 −1.71 至 −0.92，净效应可抵消；随机切分也有相似模式 | “其余头净效应小”不意味着其余头无作用 |
| B3P / B3P1，CPU | 大量同向能量被跨项抵消；未找到稳定单层候选，早期对齐不能独立解释效果 | 停止扩大层级追踪 |
| B4 非固定头读取钳制 | 钳制其余 403 头读取后，停止效应仍保留 0.88/0.94/0.96/0.90；预设机制失败 | 固定头分支已有充分边界，转向自然交付 |

### 4.1 原生背景的组合依赖与完整交付

| 实验 | 关键结果 | 对主线的作用 |
|---|---|---|
| NFC 原生首步竞争，CPU | 原生 D 变化 12.6–14.2；入口+S/KV 部分约 54–63%，固定 V 部分约 33–43%；其余头自身与交互抵消 | 把固定头结果放回完整受针背景 |
| EH 入口×历史 | 历史单独约 56–71%，入口 11–21%，交互 +1.2–2.4；固定 V 放到干净背景仍有分数效应，但 EOS 0/48 | 分数变化与形成背景共同决定跨界 |
| EH-XC | 14 方向：8 新原生、2 原生参照、4 随机；历史/入口条件关系在 8/8 新原生、4/4 随机重复；2×2 格 EOS 均为 0 | 同模型跨针眼的通路复用已经做过；不是只测一个方向 |
| SK | 原生恢复 S 为 10–17%，KV 为 3–5%，联合 21–29%；历史效果依赖背景与组合 | 后期不能先验把 S 与 KV 当可相加的独立份额 |
| NR 三因子 | 入口 X、卷积 F、其余历史 H 单独去除约 10–20%、33–48%、21–29%；任一单独保留均不足一半，存在正二阶与负三阶项 | 解释原生干预须保留组合结构 |
| CT 竞争者更替，CPU | 正确首词原生排名约 55–104；停止对正确词差约 19，但对新出现的非停止竞争词仅 0.1–6.3。恢复卷积后正确词 48/48 第一，恢复历史 38/48，恢复入口 0/48 | 不再把输出只看成 EOS 与原答案的二选一 |
| FC 自然续写 | 干净 12/12，原生 0/48；屏蔽首步 EOS 也不稳定恢复交付。强制正确首词 47/48，但该首词已唯一标识目标；完整卷积恢复 48/48 | 强制首词实验包含答案泄露，需要共享前缀任务 |
| SP 共享首字母 | 强制共同首字母后四方向正确数为 4/4/4/5（各 12）；47/48 输出第一条记录；完整卷积恢复 12/12/10/12 | 明确“开始编号”与“选择目标”的缺口 |
| FX 固定 V 完整交付 | 全 V 恢复 48/48；固定 45 头仅 0/3/0/4（各 12），其余 403 与随机 45 头也不能稳定恢复 | 固定 45 头不能作为完整答案机制，分支关闭 |
| FXS 固定分数随访 | 固定头+其余头在 3/4 方向表现分数超加；等范数扩增其余 403 头可使正确首词 46/48 第一 | 覆盖与幅度都有影响，不能把头集合当单独语义模块 |
| SVQ 共享前缀×V/QK | V 恢复为 4/4/4/10，QK 单独均 0，联合为 12/12/10/12；V 后共同首字母 48/48，却在前三方向的非首位目标中 8/8 选择第一条 | 开始回答与选对目标依赖不同的状态组合，进入查询与形成条件比较 |

## 5. 问题布局、剂量与查询身份

### 5.1 从“恢复是否有效”到“形成条件为何影响恢复”

| 实验 | 冻结比较 | 实际结果与后续逻辑 |
|---|---|---|
| NQ-01 | 54 格：6 场景×3 排序×3 查询，按名查询，问题在记录前，固定尾窗口 | V 为 54/54/45/54（各 54），联合恢复全 54；原生 0/0/0/1。目标跟随判据 4/4，首位假说 0/4。但与 SP 同时改变了布局、指定方式和覆盖 |
| QC-01 | 54 格×NA/LA/NB/LB 及尾窗口；原布局和指定方式交叉 | NA 宽窗口 V=18/31/40/54；LA 宽窗口=17/22/25/53。NA 尾窗口=54/54/54/54；LA 尾窗口=54/53/48/54。LB 干净仅 48/54，不可作合格比较；宽 26–27 token、窄 20 token 混有剂量差 |
| QCD-01 工程 G | 同一受针缓存，交叉干净 V 来源与计算切分 | 宽窄分类稳定，每对仅 0–2 格翻转，M 最大变化约 0.38 logit；恢复来源数值路径未改变本轮主要结论 |
| QCD-01 位置主比较 | E1 与 N1 都 20 token，实际剂量审计；E1 覆盖问题与前段指令，N1 覆盖尾段 | LA 的 N4146/N1210：N1 为 54/54，E1 为 20/29；NA R0 为 54 对 53，无稳定差异；其余 **5/8** 模板×方向不可判。跨方向主位置判据未达成 |
| QCD-01 剂量补充 | 窄窗口按范数和、平方范数和增幅；宽窗口降幅 | NA 两种窄窗口增幅均 54/54；LA N-A=54/47/46/54，N-Q=54/49/44/54；宽基线仍低。总量不足以单独解释恢复差异。宽窗口降幅常使原始损伤消失，不能据此否定幅度作用 |
| QCD 错误类型，CPU | 全部自然轨迹按输出与目标位置复核 | E1 多编号是按记录顺序复述；恢复 V 会把部分原本正确的条件格改错（共 44 格，重复使用同批文本）。先筛出“只交付一个编号”的成功子集再说选择正常，会漏掉大量从第一条开始复述的失败 |
| layout-token-audit，CPU | L0/L1/L2/L2s 的真实 tokenizer 与区段 | 108/108 问题 token 在布局间相同，问题长 5–6 token。L1/L2s 总长相同，但移动问题改变之前可见上下文、顺序与后续更新；没有一个配对只改变内容而保持所有时序/上下文条件 |
| QST-01 | NA 原布局、48 输入；同记录不同查询的末端 q/k 供体，干净/受针两类；双外来供体作配对 | 干净接收者及“受针+干净 q/k”条件外来供体后，各方向 84/84 仍答自己的题。没有稳定定向转移；受针供体可保留首条偏好。该候选关闭，转向干净与受针之间的共同变化 |

QST 换的是读出前卷积缓冲中几个模板位置的投影，不是全部查询历史。不同查询供体对输出影响最多约 0.125–0.25 logit；这个数是输出变化，不是 q/k 张量距离。自供体下干净 q/k 为四方向 48/48，受针 q/k 为 16/28/38/48，说明这里更显著的差别是形成状态，而非查询身份。

### 5.2 QCD 的工程资产与成本

E1/N1 实际注入的总范数和/平方范数和差约不超过 0.09%，逐步向量差不超过约 0.5%；剂量配平条件误差不超过约 0.9%。因此“等预算”有实际向量审计，不只依赖名义倍率。

G 正式 1,512 次形成、4,536 条轨迹；S 正式 3,132 次形成、4,320 条轨迹。S 原预算写为 3,024，漏计 108 次干净缓存重建；补充验收并保留原失败记录。总耗时约 3.9 GPUh。它比早期分钟级工作长，主要因为全答案生成、布局/剂量矩阵、交叉供体和形成次数增加，不能用单步评分次数估计。

## 6. 共同偏移：已得到的局部行为因果关系

### 6.1 QCO-01：跨场景共同偏移可以双向改变结果

共同偏移是受针 q/k 减干净 q/k 的平均差；对一个输入使用其余 5 个场景估计，本场景不参与。V 保持干净，其他背景保留受针影响。

| 方向 | 只恢复 V：正确/48 | 去共同偏移 | 去等范数随机 | 加共同偏移：正确/48 | 加随机：正确/48 |
|---|---:|---:|---:|---:|---:|
| N4146 | 16 | 47 | 14 | 16 | 26 |
| N1210 | 28 | 48 | 21 | 29 | 35 |
| R0 | 38 | 48 | 27 | 40 | 44 |
| C1343 | 48 | 48 | 48 | 48 | 47 |

“加共同偏移后逐 token 复现原输出”为 48/48、47/48、46/48，包含本来正确的输出。真正按原错误格计数为 **32/32、19/20、8/10**；随机为 **20/32、7/20、2/10**。合同 B 先逐场景计算，故报告为 1.00、0.93、0.77，不能拿池化 0.95、0.80 替换。

去共同偏移的 P 约 0.97–1.00，且没有把原本正确的格改错；去随机向量会造成额外错误。各输入的偏移与留出场景共同偏移余弦约 0.97–0.99，去除后剩 3–7% 平方范数。几何描述与双向行为操作相互补充。

### 6.2 QKF-01：k 分量承担主要效果，q 并非恒等于无作用

| 方向 | V 基线 | 只去 q | 只去 k | q/k 都去 | 只加 q：正确/48 | 只加 k：正确/48 |
|---|---:|---:|---:|---:|---:|---:|
| N4146 | 16 | 16 | 44 | 47 | 43 | 16 |
| N1210 | 28 | 28 | 48 | 48 | 48 | 29 |
| R0 | 38 | 40 | 48 | 48 | 48 | 42 |

去 k 的修复明显强于去 q；“k 比 q 强”的冻结跨场景判据为 2/3，R0 未全通过。联合恢复与单项的交互，在连续 M 与完整答案上分别统计；二者不能互相代替。加入 k 的原错误复现 B 为 1.00/0.93/0.55。

卷积后旧槽贡献配平的随机对照依然有作用：去随机正确数 15/20/26，加随机 23/35/41。预检把匹配容差由 5% 改为 6%，发生在行为结果前，并已登记；总运行约 0.63 GPUh。

偏移尺度的 CPU 检查撤回了“偏移远大于原 q/k、把方向淹没”的假说：卷积前偏移约为干净 q/k 的 0.85–0.93 倍，部分反向（余弦约 −0.4 至 −0.5）；旧槽卷积后约为 0.4–0.7 倍。k 旧槽贡献变化比 q 更大是一个预测线索，不是“转过某个角度必然选首条”的规律。

## 7. 从分量到过程：QKD、QSR、KRD、KHC

### 7.1 描述性分解排除了什么

| 实验 | 设计与主要发现 | 当前保留的认识 |
|---|---|---|
| QKD-01 | 捕获 t1 与强制共同前缀 t2，拆局部 k 效应。t2 的 q·k 系数 J 与旧状态预测 H 各约 0.44–0.55；“主要经旧预测项”失败。只换当步 k 解释不了实际输出差的 91–98%（t2）及 57–79%（t1）；t2 实际差中旧状态读取项约占 0.78–0.86 | 局部瞬时计算不足，前一步留下的历史必须进入分析 |
| QKD 余量分析，CPU | F→V 时目标 logit 变化 −5.18/−2.82/−2.71/−1.93；首条为 −1.32/−0.24/+0.05/+0.82。F 的 M 均值 3.47/3.56/3.66/6.47，V 为 −0.19/1.23/1.10/3.61 | 目标优势下降是具体描述；C1343 下降后仍有较大正余量 |
| 同批数据逐题检查，CPU | 非首位目标中，N1210/R0 的 F 余量区分错误 AUROC 0.91/0.85；降幅为 0.29/0.39，与错误反向相关 | 撤回“各题均匀削弱”。F 是混合参照，余量来源不能归给未测的 V 损伤；分差终值预测选择也不是新机制 |
| QSR-01 | 对 Δ(αSᵀq) 作 S/q/α 对称分解。Rk−V 的 S 份额 0.38/0.57/0.57，虽最大且各场景稳定，但不足冻结 0.60 门槛；Ak−F 仅 2/3 为 S。随机加入 S 份额更高，C1343 也同样以 S 为主 | 没有候选卡，按合同停止。未推翻 QKF 的修复因果效应，只否定“读出差全由 S 承担”的解释 |

QSR 的价值在于阻止把最大范数分量直接当成致错机制。下一步因此从“哪项数值最大”改成“把它搬走，修复是否跟着走”。

### 7.2 KRD-01：历史效应可以因果搬运

在共同偏移去除/加入配对中，交换 t1 后 H（G 层递推 S+A 层注意力 KV），交叉 t2 的 Q 节点。主比较包括修复丢失与修复获得两个方向，另含随机加入与 C1343。

| 操作 | 目标分差 M 的缺口转移比例 | 自然完整答案 |
|---|---|---|
| 只换 H | 0.35–0.78；三个缺口方向的 12 个配对都有诊断转移 | 12/12 配对出现对应方向的答案变化，不是 12 个输入全部翻转 |
| 只换 Q | N1210、R0 均≤0.18；N4146 修复丢失侧达约 0.47 | 大多不变 |
| H+Q 都换 | 约 0.75–0.90；一格为 0.903 | 大面积随供体改变 |

N4146 的例子：Rk 接收 V 的 H+Q，28 个修复全部丢失；反向 V 接收 Rk 的 H+Q，28 格中 24 格修好。P1 为 3/3，P2 为 5/6；不能把 0.903 那格改写成通过 0.9 上界。

随机加入按缺口归一化后的 H 转移约 0.39–0.69，与共同偏移 0.35–0.72 相近。旧合同用绝对转移量定义“特异”，让端点缺口大的条件占优势；该标签不支持共同偏移专有通路。C1343 的 M 转移可达 0.74–0.98，但完整答案不变，显示传递与跨界是两件事。H+Q 后剩余 10–25% 当时未被定位，不能归给卷积直接通路。

### 7.3 KHC-01：固定 Q 时，H 的效应主要保存在 S

KHC 在 KRD 面板上把 H 拆成 S/KV 的 2×2，**t2 Q 固定为供体**；同输入、三组配对及其反向，覆盖三个缺口方向与 C1343。比例分母改为当前固定 Q 下的 H 缺口 h=M11−M00。

三个缺口方向中，只换 S 的 pS=0.9563–1.0281；只换 KV 的 |pKV| 最大为 **0.05263**，通常更小。S 几乎复现 S+KV 的 M 和完整答案效果。随机加入也有同样载体关系；C1343 中有 M 变化而没有答案翻转。

下表从 `analysis/khc-readouts-r01.json` 直接抽取，完整答案正确数均以 48 为分母；00/10/01/11 分别为不换、只 S、只 KV、两者都换，Q 在四格中保持同一供体值。

| 方向 | 配对（接收者←供体） | h | pS | pKV | Y00 / Y10 / Y01 / Y11 |
|---|---|---:|---:|---:|---|
| N4146 | Rk←V | −1.1875 | 1.0132 | −0.0526 | 26 / 16 / 27 / 16 |
| N4146 | V←Rk | 1.8203 | 1.0215 | −0.0043 | 16 / 40 / 16 / 40 |
| N4146 | Ak←F | 2.3633 | 1.0281 | 0.0083 | 17 / 43 / 17 / 42 |
| N4146 | F←Ak | −1.2852 | 1.0061 | −0.0304 | 37 / 21 / 36 / 21 |
| N4146 | Ark←F | 1.5352 | 0.9720 | 0.0102 | 25 / 40 / 26 / 40 |
| N4146 | F←Ark | −1.0273 | 0.9848 | 0 | 43 / 36 / 43 / 36 |
| N1210 | Rk←V | −1.3047 | 1.0120 | −0.0329 | 48 / 34 / 48 / 35 |
| N1210 | V←Rk | 1.6875 | 1.0069 | 0.0116 | 28 / 43 / 28 / 43 |
| N1210 | Ak←F | 2.0000 | 1.0059 | 0.0156 | 31 / 45 / 31 / 45 |
| N1210 | F←Ak | −1.4570 | 0.9920 | 0.0080 | 48 / 41 / 48 / 41 |
| N1210 | Ark←F | 1.3398 | 0.9563 | 0.0204 | 34 / 44 / 34 / 44 |
| N1210 | F←Ark | −1.0664 | 0.9707 | 0.0293 | 48 / 46 / 48 / 46 |
| R0 | Rk←V | −1.4375 | 0.9647 | 0.0326 | 46 / 43 / 47 / 42 |
| R0 | V←Rk | 1.7148 | 0.9863 | 0.0273 | 40 / 48 / 41 / 48 |
| R0 | Ak←F | 2.0977 | 0.9777 | 0.0298 | 42 / 48 / 42 / 48 |
| R0 | F←Ak | −1.6055 | 0.9635 | 0.0122 | 48 / 44 / 48 / 44 |
| R0 | Ark←F | 1.2500 | 0.9719 | 0.0250 | 44 / 46 / 42 / 46 |
| R0 | F←Ark | −1.0586 | 0.9815 | 0.0369 | 48 / 46 / 48 / 46 |

C1343 的四个共同偏移配对全为 48/48；随机 Ark←F 四格均 47/48，反向四格均 48/48。随机配对 h 约 0.4531、−0.4277，小于比例门槛，pS/pKV 未定义，不能纳入比例平均。

两项汇总校正：

- 报告“|pKV|≤0.05”是两位小数概括；精确最大值为 0.05263。
- 报告“只换 KV 对完整答案影响最多 1 例”与表不符：R0 的 Ark←F 为 44→42，变化 **2 例**。这不改变 S 承担绝大多数 H 效应的结论，但应使用真实计数。

KV 操作确实生效：1,152 个比较格的全词表 logits 均有变化，但 M 差中位数为 0、最大 0.25。正式运行 2,304 条自然轨迹、17,232 decode 步；2,304 次 N 路线桥接逐位复现 KRD。总约 0.74 GPUh，一次通过。当前最明确的新增结论是：**在该固定 Q 条件下，能搬运的修复历史主要保存在递推 S，KV 对选定分差和交付的贡献很小。**

## 8. KUC：从 k 修复推进到新值写入的计算连接

盘点期间 KUC 正式结果入库（`f5570999`）。本节核对了[合同](../experiments/cache-k-update-causal-v1-2026-11-03/CONTRACT.zh-CN.md)、[报告](../experiments/cache-k-update-causal-v1-2026-11-03/REPORT.zh-CN.md)、[分析数据](../experiments/cache-k-update-causal-v1-2026-11-03/analysis/kuc-readouts-r01.json)和[正式验收](../experiments/cache-k-update-causal-v1-2026-11-03/runs/formal-r01/verification.json)。

KUC 接续 KHC，问 t1 的 k 改变究竟通过旧预测修正 E、新值写入 W，还是两者配合，产生后续回答变化。同一背景下的 2×2 为：

\[
S_1=D-\beta k_E(k_E^T D)+\beta k_W v^T,\quad D=\alpha S_0.
\]

E 中两个 k 一起替换；W 中替换一个 k。只在 t1 动手，t2 后自然响应。影子 k 在真实卷积更新前克隆缓冲、编辑旧槽，使用相同当前输入计算，不把影子旧槽写回。因而可以区分“仅 t1 更新改变”与“继续保留卷积旧槽编辑”。R 为修复，A 为加入共同偏移，Z 为加入随机偏移。

下表直接取分析 JSON。g1 为只在 t1 两项都替换的 M 效应，E/W 比例以 g1 为分母；M 使用目标非首列 32 条的场景等权汇总。Y 为全 48 条自然完整正确数，四格依次为不处理、只换 E、只换 W、两项都换；最后列保留持续卷积编辑的原端点。

| 方向 | 族 | g1 | E/g1 | W/g1 | Y：00 / 10 / 01 / 11 / 原端点 |
|---|---|---:|---:|---:|---|
| N4146 | R | +2.783 | -0.021 | 1.056 | 16 / 16 / 42 / 40 / 44 |
| N4146 | A | -3.576 | -0.012 | 1.010 | 48 / 48 / 17 / 17 / 16 |
| N4146 | Z | -2.661 | 0.123 | 0.918 | 48 / 47 / 26 / 24 / 23 |
| N1210 | R | +2.028 | -0.048 | 1.028 | 28 / 28 / 48 / 48 / 48 |
| N1210 | A | -2.257 | -0.017 | 1.054 | 48 / 48 / 29 / 31 / 29 |
| N1210 | Z | -1.637 | 0.095 | 0.878 | 48 / 48 / 39 / 36 / 35 |
| R0 | R | +2.030 | -0.009 | 1.012 | 38 / 38 / 48 / 48 / 48 |
| R0 | A | -2.384 | 0.003 | 0.976 | 48 / 48 / 43 / 43 / 42 |
| R0 | Z | -1.653 | 0.163 | 0.833 | 48 / 48 / 44 / 42 / 41 |
| C1343 | R | +2.417 | -0.096 | 0.965 | 48 / 48 / 48 / 48 / 48 |
| C1343 | A | -1.867 | 0.017 | 1.131 | 48 / 48 / 48 / 48 / 48 |
| C1343 | Z | -0.804 | 0.170 | 0.760 | 48 / 48 / 47 / 47 / 47 |

三个有恢复缺口的方向，R/A 的只换 W 比例为 **0.976–1.056**，只换 E 为 **−0.048–0.003**。N4146 修复侧只换 W 把正确数从 16 提到 42，两项都换为 40；加入侧只换 W 把 48 降到 17。N1210、R0 修复侧只换 W 均达到 48/48。旧预测修正项单独替换在这六组中的正确总数不变。预注册 P1 在 3/3 方向通过；三个方向×三族的九组均按冻结规则判为 `single_W`。

这使主线获得了一个明确的计算结论：**在 V 已恢复的混合背景中，只改 t1 更新式新值写入项里的 k，足以产生主要的 k 修复/致错效应；这些效应体现在后续目标分差和自然完整回答上。** 单项替换是对共享 k 的人工拆分，说明该计算项的干预作用，不表示模型有独立的“写入通道”。

随机 Z 同样主要由 W 承担（缺口方向 W/g1 为 0.833–0.918），所以这是本面板中多类 k 扰动共有的计算关系。C1343 的 M 也移动，R/A 的完整答案仍全对；Z 的四格为 **48/48/47/47**，原端点 47。原报告把 Z 概括为“47 不变”不够准确，应按四格记录。它继续说明计算效应与行为翻转不是同一个量。

只在 t1 两项都改，已搬运原持续编辑效应的 0.89–0.99（九组缺口方向）。原端点与 11 在 t1 之后只剩卷积 k 旧槽差，C 路线 t2 的残余 M 差绝对值不超过 0.32；修复侧 N4146/N1210/R0 为 +0.03/+0.06/+0.06，C1343 为 −0.05。不能概括为所有方向都同号。自然路线的正确数差为 −2 至 +4，还含后续残留和生成分叉。

工程与成本：预检、正式一次通过；00/11 与原核数值匹配；10/01 的 FP64 公式核对最大相对误差 2.04e−7（门槛 1e−5）；有符号零例外 0 次。正式 240 次形成、2,688 条自然轨迹、14,926 decode、32,256 次影子卷积；两 worker 合计 1,768s，约 0.49 GPUh，含预检约 0.52 GPUh。t1/t2 logits 约 2.7GB 留在服务器，清单和收据入库。

KUC 与 KHC 分别给出更新项和条件性历史载体的干预证据；QKD 的 t2 旧状态读出分账仍是描述性连接。当前尚未把整个“写入→S→特定读出计算→目标优势”逐段作完因果检验。下一步应围绕这段已得到的计算关系解释其内容与适用范围，而不是重新寻找最大的状态分量。

## 9. 跨针眼、跨架构资产现在实际具备什么

**同模型跨针眼不是空白。** 形成期 V 的 10 原生+4 随机方向、C2 的固定头跨方向、EH-XC 的 8 个新原生方向以及后期 N4146/N1210/R0/C1343 对照，已经分别检验了材料操作、停止侧效应和历史传播。它们使用的任务、背景和终点不同；目前不能合并成“所有方向同一完整机制”。

跨模型 foundation 另有三个资产目录：公共面板、固定文本的 history×current 四格、自然生成的 CONT/WITHDRAW/REBUILD。涉及 Qwen3.5-4B、Qwen3-4B、Llama3.2-3B、FalconH1-3B。快照中的主要产出是 **F1 工程与开发检查**：

- D18 实际注入校验每模型 432 次；最大误差约 0.87%、1.21%、0.83%、1.02%，其中两模型未满足 1% 门槛。
- D19 在大效应条件下检查数值路径，报告保留各模型/剂量的可判与不可判，不作正式跨架构科学结论。
- D20 自然流程可达性：FalconH1 L3 44/72，Qwen3 L17 54/72；列表重复会阻止进入指定的比较位置。

因此，跨架构的可执行基础已部分建立，但共同因果原则仍是待验证目标。当前主线贡献的是一个可翻译的候选关系：**短时内部扰动可通过后续历史更新持续影响目标竞争，行为是否翻转取决于变化与当时目标优势的组合。** 需要在其他模型使用对应的内部操作验证，不能仅凭相似输出成立。

## 10. 资产怎样复用，哪些分支已经结束

| 资产/分支 | 当前用途 |
|---|---|
| S1/S2 驱动量、逐步状态及缓存 | 形成过程来源、同起点与撤针后新写入的证据；避免重复做架构恒等式实验 |
| E2→FORM-AB→BRIDGE→COMBO | 干预形成、深层载体与 V 操作之间的来源链；缓存/供体带/哈希可追溯 |
| 固定 45 头、C1P/C2/B3/B4/FX | 留出文本和跨方向的停止侧材料结果，以及完整答案失败边界；不再作为默认拆层主线 |
| FC/SP/SVQ/NQ/QC/QCD | 自然完整答案、共享前缀、查询顺序、覆盖与剂量的任务资产；保留所有失败输出 |
| QST | 查询身份转移阴性；关闭“这几个末端模板位置携带可搬运查询身份”的候选 |
| QCO/QKF | 留一场景共同偏移、随机参照、q/k 因子、自然行为；是 k 修复因果证据的起点 |
| QKD/QSR | 数值捕获、局部分解和失败预测；提供哪些解释没成立，不作为后续因果研究的禁止条件 |
| KRD/KHC | 双向历史转移与 S/KV 载体条件；连接 k 修复与后续状态的行为因果证据 |
| KUC | t1 新值写入项的双向因果作用；四格、影子 k、原端点桥接支持计算项与后续行为的连接 |
| layout、design-audit、result-review 目录 | 文本位置、公式、合同修正和历史口径纠正；独立审计资产，不计新实验阳性 |
| behavior-validation / native-behavior-reference | 当前快照为规划与基准准备材料，没有正式结果；保留为未运行设计 |

## 11. 数字、成本与执行记录的核验

### 11.1 核心成本台账

表中 GPUh 按原报告的累计卡时口径；秒数为该轮报告的 worker/运行时间，不能简单混加。成本已发生与预算分开。

| 实验 | 主要运行规模 | 已报告耗时 |
|---|---|---|
| stage2-v2 | 29,112 生成；58,224 候选评分 | 约 10.4 GPUh |
| S1 / S2 / S3 | 36 / 84 / 3,120 格及参照 | S2 正式约 124s；S3 8 workers 约 634s |
| FORM-AB / BRIDGE / COMBO | 60/72；108/168；36/300（形成/评分） | AB 约 119s；BRIDGE 约 247s |
| FC / SP / FX | 216 / 216 / 300 条自然轨迹 | 分钟级 |
| NQ / QC | 702 / 3,588 条轨迹 | 约 0.22 / 1.17 GPUh |
| QCD | G 4,536 + S 4,320 条轨迹 | 约 3.9 GPUh |
| QST | 1,380 条轨迹、240 次形成 | 约 0.37 GPUh |
| QCO | 正式 1,392 条轨迹，另有偏移采集 | 约 0.49 GPUh |
| QKF | 3,072 条轨迹、192 次形成 | 约 0.63 GPUh |
| QKD | 240 次形成、288 自然轨迹、6,909 decode | 约 0.51 GPUh |
| QSR | 240 次形成、2,304 decode | 正式约 0.28 GPUh |
| KRD | 5,756 自然轨迹、25,830 decode | 正式 0.82，含预检约 0.88 GPUh |
| KHC | 2,304 自然轨迹、17,232 decode；另 2,304 次单步桥接 | 正式 0.70，含预检约 0.74 GPUh |
| KUC | 2,688 自然轨迹、240 次形成、14,926 decode | 正式 0.49，含预检约 0.52 GPUh |

### 11.2 必须随结果保留的修正

| 位置 | 准确记录 |
|---|---|
| FORM-AB 路径 | 整段与逐 token BF16 路线不逐位相同；在冻结前用探针与合同定义桥接，不能写成完全相同路径 |
| QCD | 主比较为 5 个不可判；总量解释不足不等于幅度无关；漏计的 108 次干净重建与补充验收保留 |
| QCD 事后错误分类 | “48–54/54 开口”已改为“37–54/54 直接以编号开头”；非编号开头不等于不回答；44 格不是 44 个独立输入 |
| QST | 输出小变化不证明没有任何查询编码；没有稳定答案定向转移是本实验的结果 |
| QCO | 全输出复现与原错误复现分母不同；P/B 场景均值与池化比例分开 |
| QKF | 6% 容差是预检阶段相对原计划的修订；撤回 k 角度阈值与 q 无用的泛化 |
| QKD | 首次预检因继承不存在的字段失败，r02 重冻重试；旧尝试保留 |
| QSR | P1 没通过、没有候选卡；不改写成阳性，不撤销前轮行为因果证据 |
| KRD | CPU/GPU 对比错误导致一次预检重试；授权文件提交号笔误登记；绝对量“特异”标签失效，P2 为 5/6 |
| KHC | 精确 pKV 最大值与 KV 两例变化按 §7.3 修正；Q 固定为供体是结果条件 |

### 11.3 本次盘点自查

本次为同一作者的资产核对，不是独立复现实验。

- **设计与结果分开：** 逐阶段对照方案/合同、报告与分析；KUC 已按新入库正式数据更新；跨模型 F1 保持工程与开发检查的定位。
- **数字对照：** 核查核心读数的分母、场景汇总、自然/强制路线与背景。KHC 全部 24 配对的 h、比例和四格 Y 从分析 JSON 抽取核对；KUC 全部 12 个方向×族的 g1、E/W 比例、五列 Y 与标签从 JSON 生成核对。报告概括与表不一致的地方以数据表为准。
- **文件完整性：** 对范围内 4,891 个 Git 文件计算 SHA-256 和字节数；解析 3,842 个 JSON、69 个 JSONL/压缩 JSONL，共 21,963 条记录，解析错误 0。解析通过表示文件可读，不替代实验统计复算。
- **数据定位：** 每个目录的合同、分析、运行与数据入口列在附录；文件清单保留失败和预检文件，不删除不利结果。服务器张量只登记已有来源与哈希，本次没有重新下载或读取全部模型张量。
- **逻辑自查：** 没有把 EOS 分数当完整交付，没有把最大分量当因果主导，没有把随机方向同样有效的传播关系说成共同偏移专有，没有把 F 参照余量当全干净模型抗扰能力。
- **课题推进：** 阴性分支说明为何改变问题；当前计算连接接回形成与历史主线。C1343 与随机参照保留在解释中；不以重复相关性检查阻挡已获支持的因果检验。

本文是固定快照。后续正式结果进入仓库后，应更新对应阶段、数据入口和状态，而不是覆盖本次引用的原始记录。

## 附录 A：全部资产入口

本附录按目录登记全部版本化资产。文件级路径、字节数、SHA-256 和可解析数据的记录数见[完整资产清单](cache-mechanism-experiment-assets-2026-11-03.json)。清单包括正式数据、预检、失败尝试、授权收据、代码和设计，不能把其中的文件数或轨迹数直接相加当作独立样本数。

### cache-b1-paired-propagation-v1-2026-11-01

[目录](../experiments/cache-b1-paired-propagation-v1-2026-11-01/)：8 个文件，810,035 字节；其中 1 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b1-paired-propagation-v1-2026-11-01/CONTRACT.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b1-paired-propagation-v1-2026-11-01/REPORT.zh-CN.md)。

### cache-b2-computation-followup-v1-2026-11-01

[目录](../experiments/cache-b2-computation-followup-v1-2026-11-01/)：8 个文件，83,728 字节；其中 1 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b2-computation-followup-v1-2026-11-01/CONTRACT.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b2-computation-followup-v1-2026-11-01/REPORT.zh-CN.md)。

### cache-b2-v-subset-q-dependence-design-v1-2026-11-01

[目录](../experiments/cache-b2-v-subset-q-dependence-design-v1-2026-11-01/)：2 个文件，258,485 字节；其中 2 个数据/收据/清单文件。

### cache-b2-v-subset-q-dependence-v1-2026-11-01

[目录](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/)：61 个文件，505,398 字节；其中 45 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/analysis/)、[logs](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/logs/)、[readiness](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/readiness/)、[runs](../experiments/cache-b2-v-subset-q-dependence-v1-2026-11-01/runs/)。

### cache-b3-fixed-head-trace-v1-2026-11-01

[目录](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/)：67 个文件，1,792,592 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/analysis/)、[logs](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/logs/)、[readiness](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/readiness/)、[runs](../experiments/cache-b3-fixed-head-trace-v1-2026-11-01/runs/)。

### cache-b3p-energy-ledger-v1-2026-11-01

[目录](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/)：14 个文件，4,806,256 字节；其中 4 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/analysis/)、[logs](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/logs/)、[readiness](../experiments/cache-b3p-energy-ledger-v1-2026-11-01/readiness/)。

### cache-b3p1-early-alignment-v1-2026-11-01

[目录](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/)：14 个文件，9,237,148 字节；其中 4 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/analysis/)、[logs](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/logs/)、[readiness](../experiments/cache-b3p1-early-alignment-v1-2026-11-01/readiness/)。

### cache-b4-nonfix-readout-v1-2026-11-02

[目录](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/)：69 个文件，4,984,724 字节；其中 53 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/analysis/)、[logs](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/logs/)、[readiness](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/readiness/)、[runs](../experiments/cache-b4-nonfix-readout-v1-2026-11-02/runs/)。

### cache-behavior-validation-v1-2026-10-30

[目录](../experiments/cache-behavior-validation-v1-2026-10-30/)：14 个文件，51,223 字节；其中 0 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-behavior-validation-v1-2026-10-30/CONTRACT.zh-CN.md)；[PLAN.zh-CN.md](../experiments/cache-behavior-validation-v1-2026-10-30/PLAN.zh-CN.md)。

资产分区：[e00-existing-evidence](../experiments/cache-behavior-validation-v1-2026-10-30/e00-existing-evidence/)、[e01-eos-only](../experiments/cache-behavior-validation-v1-2026-10-30/e01-eos-only/)、[e02-recurrent](../experiments/cache-behavior-validation-v1-2026-10-30/e02-recurrent/)、[e03-convolution](../experiments/cache-behavior-validation-v1-2026-10-30/e03-convolution/)、[e04-kv](../experiments/cache-behavior-validation-v1-2026-10-30/e04-kv/)、[e05-joint-linear](../experiments/cache-behavior-validation-v1-2026-10-30/e05-joint-linear/)。

### cache-c2-cross-direction-v1-2026-11-01

[目录](../experiments/cache-c2-cross-direction-v1-2026-11-01/)：125 个文件，2,042,888 字节；其中 109 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-c2-cross-direction-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-c2-cross-direction-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-c2-cross-direction-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-c2-cross-direction-v1-2026-11-01/analysis/)、[data](../experiments/cache-c2-cross-direction-v1-2026-11-01/data/)、[logs](../experiments/cache-c2-cross-direction-v1-2026-11-01/logs/)、[readiness](../experiments/cache-c2-cross-direction-v1-2026-11-01/readiness/)、[runs](../experiments/cache-c2-cross-direction-v1-2026-11-01/runs/)。

### cache-common-offset-v1-2026-11-02

[目录](../experiments/cache-common-offset-v1-2026-11-02/)：167 个文件，3,110,749 字节；其中 147 个数据/收据/清单文件。

文档：[ANALYSIS-offset-scale.zh-CN.md](../experiments/cache-common-offset-v1-2026-11-02/ANALYSIS-offset-scale.zh-CN.md)；[CONTRACT.zh-CN.md](../experiments/cache-common-offset-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-common-offset-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-common-offset-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-common-offset-v1-2026-11-02/analysis/)、[logs](../experiments/cache-common-offset-v1-2026-11-02/logs/)、[readiness](../experiments/cache-common-offset-v1-2026-11-02/readiness/)、[runs](../experiments/cache-common-offset-v1-2026-11-02/runs/)。

### cache-competitor-turnover-v1-2026-11-02

[目录](../experiments/cache-competitor-turnover-v1-2026-11-02/)：10 个文件，493,151 字节；其中 3 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-competitor-turnover-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-competitor-turnover-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-competitor-turnover-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-competitor-turnover-v1-2026-11-02/analysis/)、[readiness](../experiments/cache-competitor-turnover-v1-2026-11-02/readiness/)。

### cache-conv-factor-design-audit-v1-2026-11-01

[目录](../experiments/cache-conv-factor-design-audit-v1-2026-11-01/)：18 个文件，123,885 字节；其中 8 个数据/收据/清单文件。

文档：[README.md](../experiments/cache-conv-factor-design-audit-v1-2026-11-01/README.md)；[REPORT.zh-CN.md](../experiments/cache-conv-factor-design-audit-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[review-r02](../experiments/cache-conv-factor-design-audit-v1-2026-11-01/review-r02/)。

### cache-conv-factor-path-audit-v1-2026-11-01

[目录](../experiments/cache-conv-factor-path-audit-v1-2026-11-01/)：5 个文件，1,220,069 字节；其中 1 个数据/收据/清单文件。

文档：[PLAN.zh-CN.md](../experiments/cache-conv-factor-path-audit-v1-2026-11-01/PLAN.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-conv-factor-path-audit-v1-2026-11-01/REPORT.zh-CN.md)。

### cache-conv-factor-v1-2026-11-01

[目录](../experiments/cache-conv-factor-v1-2026-11-01/)：87 个文件，2,008,594 字节；其中 66 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-conv-factor-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-conv-factor-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-conv-factor-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-conv-factor-v1-2026-11-01/analysis/)、[logs](../experiments/cache-conv-factor-v1-2026-11-01/logs/)、[readiness](../experiments/cache-conv-factor-v1-2026-11-01/readiness/)、[runs](../experiments/cache-conv-factor-v1-2026-11-01/runs/)。

### cache-coverage-dose-design-v1-2026-11-02

[目录](../experiments/cache-coverage-dose-design-v1-2026-11-02/)：2 个文件，11,275 字节；其中 1 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-coverage-dose-design-v1-2026-11-02/README.zh-CN.md)。

### cache-coverage-dose-v1-2026-11-02

[目录](../experiments/cache-coverage-dose-v1-2026-11-02/)：290 个文件，55,635,878 字节；其中 268 个数据/收据/清单文件。

文档：[ANALYSIS-failure-steps.zh-CN.md](../experiments/cache-coverage-dose-v1-2026-11-02/ANALYSIS-failure-steps.zh-CN.md)；[CONTRACT.zh-CN.md](../experiments/cache-coverage-dose-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-coverage-dose-v1-2026-11-02/DECISIONS.zh-CN.md)；[DEVIATIONS.zh-CN.md](../experiments/cache-coverage-dose-v1-2026-11-02/DEVIATIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-coverage-dose-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-coverage-dose-v1-2026-11-02/analysis/)、[data](../experiments/cache-coverage-dose-v1-2026-11-02/data/)、[logs](../experiments/cache-coverage-dose-v1-2026-11-02/logs/)、[readiness](../experiments/cache-coverage-dose-v1-2026-11-02/readiness/)、[runs](../experiments/cache-coverage-dose-v1-2026-11-02/runs/)。

### cache-cross-channel-validation-v1-2026-10-31

[目录](../experiments/cache-cross-channel-validation-v1-2026-10-31/)：96 个文件，17,070,442 字节；其中 77 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-cross-channel-validation-v1-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-cross-channel-validation-v1-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-cross-channel-validation-v1-2026-10-31/README.md)。

资产分区：[analysis](../experiments/cache-cross-channel-validation-v1-2026-10-31/analysis/)、[data](../experiments/cache-cross-channel-validation-v1-2026-10-31/data/)、[logs](../experiments/cache-cross-channel-validation-v1-2026-10-31/logs/)、[readiness](../experiments/cache-cross-channel-validation-v1-2026-10-31/readiness/)、[runs](../experiments/cache-cross-channel-validation-v1-2026-10-31/runs/)。

### cache-eh-cross-channel-v1-2026-11-02

[目录](../experiments/cache-eh-cross-channel-v1-2026-11-02/)：65 个文件，2,280,780 字节；其中 51 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-eh-cross-channel-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-eh-cross-channel-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-eh-cross-channel-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-eh-cross-channel-v1-2026-11-02/analysis/)、[logs](../experiments/cache-eh-cross-channel-v1-2026-11-02/logs/)、[readiness](../experiments/cache-eh-cross-channel-v1-2026-11-02/readiness/)、[runs](../experiments/cache-eh-cross-channel-v1-2026-11-02/runs/)。

### cache-entry-history-v1-2026-11-02

[目录](../experiments/cache-entry-history-v1-2026-11-02/)：66 个文件，939,805 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-entry-history-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-entry-history-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-entry-history-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-entry-history-v1-2026-11-02/analysis/)、[logs](../experiments/cache-entry-history-v1-2026-11-02/logs/)、[readiness](../experiments/cache-entry-history-v1-2026-11-02/readiness/)、[runs](../experiments/cache-entry-history-v1-2026-11-02/runs/)。

### cache-first-token-continuation-v1-2026-11-02

[目录](../experiments/cache-first-token-continuation-v1-2026-11-02/)：67 个文件，680,834 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-first-token-continuation-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-first-token-continuation-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-first-token-continuation-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-first-token-continuation-v1-2026-11-02/analysis/)、[logs](../experiments/cache-first-token-continuation-v1-2026-11-02/logs/)、[readiness](../experiments/cache-first-token-continuation-v1-2026-11-02/readiness/)、[runs](../experiments/cache-first-token-continuation-v1-2026-11-02/runs/)。

### cache-fixed-v-delivery-v1-2026-11-02

[目录](../experiments/cache-fixed-v-delivery-v1-2026-11-02/)：67 个文件，711,227 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-fixed-v-delivery-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-fixed-v-delivery-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-fixed-v-delivery-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-fixed-v-delivery-v1-2026-11-02/analysis/)、[logs](../experiments/cache-fixed-v-delivery-v1-2026-11-02/logs/)、[readiness](../experiments/cache-fixed-v-delivery-v1-2026-11-02/readiness/)、[runs](../experiments/cache-fixed-v-delivery-v1-2026-11-02/runs/)。

### cache-formation-asset-audit-v1-2026-10-31

[目录](../experiments/cache-formation-asset-audit-v1-2026-10-31/)：12 个文件，636,275 字节；其中 4 个数据/收据/清单文件。

文档：[REPORT.zh-CN.md](../experiments/cache-formation-asset-audit-v1-2026-10-31/REPORT.zh-CN.md)；[SELF_CHECK.zh-CN.md](../experiments/cache-formation-asset-audit-v1-2026-10-31/SELF_CHECK.zh-CN.md)。

资产分区：[source](../experiments/cache-formation-asset-audit-v1-2026-10-31/source/)。

### cache-formation-cache-combination-v1-2026-10-31

[目录](../experiments/cache-formation-cache-combination-v1-2026-10-31/)：67 个文件，2,285,993 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-cache-combination-v1-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-cache-combination-v1-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-cache-combination-v1-2026-10-31/README.md)。

资产分区：[analysis](../experiments/cache-formation-cache-combination-v1-2026-10-31/analysis/)、[logs](../experiments/cache-formation-cache-combination-v1-2026-10-31/logs/)、[readiness](../experiments/cache-formation-cache-combination-v1-2026-10-31/readiness/)、[runs](../experiments/cache-formation-cache-combination-v1-2026-10-31/runs/)。

### cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31

[目录](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/)：67 个文件，1,294,480 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/IMPLEMENTATION.zh-CN.md)；[PLAN.zh-CN.md](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/PLAN.zh-CN.md)；[README.md](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/README.md)；[REPORT.zh-CN.md](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/analysis/)、[data](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/data/)、[logs](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/logs/)、[readiness](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/readiness/)、[runs](../experiments/cache-formation-mechanism-e2-depth-transplant-v1-2026-10-31/runs/)。

### cache-formation-mechanism-fact-signal-native-v1-2026-10-31

[目录](../experiments/cache-formation-mechanism-fact-signal-native-v1-2026-10-31/)：6 个文件，856,399 字节；其中 1 个数据/收据/清单文件。

文档：[ANALYSIS_PLAN.zh-CN.md](../experiments/cache-formation-mechanism-fact-signal-native-v1-2026-10-31/ANALYSIS_PLAN.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-formation-mechanism-fact-signal-native-v1-2026-10-31/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-fact-signal-native-v1-2026-10-31/analysis/)、[logs](../experiments/cache-formation-mechanism-fact-signal-native-v1-2026-10-31/logs/)。

### cache-formation-mechanism-formation-ab-v2-2026-10-31

[目录](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/)：68 个文件，1,737,461 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/README.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/analysis/)、[logs](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/logs/)、[readiness](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/readiness/)、[runs](../experiments/cache-formation-mechanism-formation-ab-v2-2026-10-31/runs/)。

### cache-formation-mechanism-s1-native-trace-v1-2026-10-31

[目录](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/)：100 个文件，9,441,054 字节；其中 84 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/README.md)；[REPORT.zh-CN.md](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/analysis/)、[data](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/data/)、[logs](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/logs/)、[readiness](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/readiness/)、[runs](../experiments/cache-formation-mechanism-s1-native-trace-v1-2026-10-31/runs/)。

### cache-formation-mechanism-s2-formation-test-v3-2026-10-31

[目录](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/)：203 个文件，7,779,417 字节；其中 189 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/README.md)；[REPORT.zh-CN.md](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/analysis/)、[readiness](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/readiness/)、[runs](../experiments/cache-formation-mechanism-s2-formation-test-v3-2026-10-31/runs/)。

### cache-formation-mechanism-s3-route-intervention-v3-2026-10-31

[目录](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/)：126 个文件，5,344,467 字节；其中 102 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/README.md)；[REPORT.zh-CN.md](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/analysis/)、[logs](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/logs/)、[readiness](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/readiness/)、[runs](../experiments/cache-formation-mechanism-s3-route-intervention-v3-2026-10-31/runs/)。

### cache-formation-readout-bridge-v1-2026-10-31

[目录](../experiments/cache-formation-readout-bridge-v1-2026-10-31/)：67 个文件，13,205,165 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-formation-readout-bridge-v1-2026-10-31/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/cache-formation-readout-bridge-v1-2026-10-31/IMPLEMENTATION.zh-CN.md)；[README.md](../experiments/cache-formation-readout-bridge-v1-2026-10-31/README.md)。

资产分区：[analysis](../experiments/cache-formation-readout-bridge-v1-2026-10-31/analysis/)、[data](../experiments/cache-formation-readout-bridge-v1-2026-10-31/data/)、[logs](../experiments/cache-formation-readout-bridge-v1-2026-10-31/logs/)、[readiness](../experiments/cache-formation-readout-bridge-v1-2026-10-31/readiness/)、[runs](../experiments/cache-formation-readout-bridge-v1-2026-10-31/runs/)。

### cache-fv-local-path-v1-2026-11-01

[目录](../experiments/cache-fv-local-path-v1-2026-11-01/)：7 个文件，2,104,962 字节；其中 1 个数据/收据/清单文件。

文档：[PLAN.zh-CN.md](../experiments/cache-fv-local-path-v1-2026-11-01/PLAN.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-fv-local-path-v1-2026-11-01/REPORT.zh-CN.md)。

### cache-fx-fixed-score-followup-v1-2026-11-02

[目录](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/)：66 个文件，525,405 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/analysis/)、[logs](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/logs/)、[readiness](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/readiness/)、[runs](../experiments/cache-fx-fixed-score-followup-v1-2026-11-02/runs/)。

### cache-head-rule-prospective-v1-2026-11-01

[目录](../experiments/cache-head-rule-prospective-v1-2026-11-01/)：84 个文件，1,267,190 字节；其中 68 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-head-rule-prospective-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-head-rule-prospective-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-head-rule-prospective-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-head-rule-prospective-v1-2026-11-01/analysis/)、[data](../experiments/cache-head-rule-prospective-v1-2026-11-01/data/)、[logs](../experiments/cache-head-rule-prospective-v1-2026-11-01/logs/)、[readiness](../experiments/cache-head-rule-prospective-v1-2026-11-01/readiness/)、[runs](../experiments/cache-head-rule-prospective-v1-2026-11-01/runs/)。

### cache-k-computation-design-v1-2026-11-03

[目录](../experiments/cache-k-computation-design-v1-2026-11-03/)：4 个文件，18,094 字节；其中 2 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-k-computation-design-v1-2026-11-03/README.zh-CN.md)。

### cache-k-computation-diagnostic-v1-2026-11-03

[目录](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/)：119 个文件，8,590,372 字节；其中 98 个数据/收据/清单文件。

文档：[ANALYSIS-target-vs-first.zh-CN.md](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/ANALYSIS-target-vs-first.zh-CN.md)；[CONTRACT.zh-CN.md](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/analysis/)、[logs](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/logs/)、[readiness](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/readiness/)、[runs](../experiments/cache-k-computation-diagnostic-v1-2026-11-03/runs/)。

### cache-k-history-carrier-v1-2026-11-03

[目录](../experiments/cache-k-history-carrier-v1-2026-11-03/)：95 个文件，3,408,267 字节；其中 81 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-k-history-carrier-v1-2026-11-03/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-k-history-carrier-v1-2026-11-03/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-k-history-carrier-v1-2026-11-03/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-k-history-carrier-v1-2026-11-03/analysis/)、[logs](../experiments/cache-k-history-carrier-v1-2026-11-03/logs/)、[readiness](../experiments/cache-k-history-carrier-v1-2026-11-03/readiness/)、[runs](../experiments/cache-k-history-carrier-v1-2026-11-03/runs/)。

### cache-k-repair-dependence-v1-2026-11-03

[目录](../experiments/cache-k-repair-dependence-v1-2026-11-03/)：111 个文件，4,389,758 字节；其中 93 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-k-repair-dependence-v1-2026-11-03/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-k-repair-dependence-v1-2026-11-03/DECISIONS.zh-CN.md)；[DEVIATIONS.zh-CN.md](../experiments/cache-k-repair-dependence-v1-2026-11-03/DEVIATIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-k-repair-dependence-v1-2026-11-03/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-k-repair-dependence-v1-2026-11-03/analysis/)、[logs](../experiments/cache-k-repair-dependence-v1-2026-11-03/logs/)、[readiness](../experiments/cache-k-repair-dependence-v1-2026-11-03/readiness/)、[runs](../experiments/cache-k-repair-dependence-v1-2026-11-03/runs/)。

### cache-k-update-causal-v1-2026-11-03

[目录](../experiments/cache-k-update-causal-v1-2026-11-03/)：95 个文件，2,345,937 字节；其中 81 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-k-update-causal-v1-2026-11-03/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-k-update-causal-v1-2026-11-03/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-k-update-causal-v1-2026-11-03/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-k-update-causal-v1-2026-11-03/analysis/)、[logs](../experiments/cache-k-update-causal-v1-2026-11-03/logs/)、[readiness](../experiments/cache-k-update-causal-v1-2026-11-03/readiness/)、[runs](../experiments/cache-k-update-causal-v1-2026-11-03/runs/)。

### cache-layout-token-audit-v1-2026-11-02

[目录](../experiments/cache-layout-token-audit-v1-2026-11-02/)：3 个文件，660,076 字节；其中 1 个数据/收据/清单文件。

文档：[LAYOUT-AUDIT.zh-CN.md](../experiments/cache-layout-token-audit-v1-2026-11-02/LAYOUT-AUDIT.zh-CN.md)。

### cache-local-readout-causal-v1-2026-11-01

[目录](../experiments/cache-local-readout-causal-v1-2026-11-01/)：60 个文件，714,672 字节；其中 45 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-local-readout-causal-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-local-readout-causal-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-local-readout-causal-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-local-readout-causal-v1-2026-11-01/analysis/)、[logs](../experiments/cache-local-readout-causal-v1-2026-11-01/logs/)、[readiness](../experiments/cache-local-readout-causal-v1-2026-11-01/readiness/)、[runs](../experiments/cache-local-readout-causal-v1-2026-11-01/runs/)。

### cache-name-query-order-v1-2026-11-02

[目录](../experiments/cache-name-query-order-v1-2026-11-02/)：112 个文件，1,922,676 字节；其中 96 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-name-query-order-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-name-query-order-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-name-query-order-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-name-query-order-v1-2026-11-02/analysis/)、[data](../experiments/cache-name-query-order-v1-2026-11-02/data/)、[logs](../experiments/cache-name-query-order-v1-2026-11-02/logs/)、[readiness](../experiments/cache-name-query-order-v1-2026-11-02/readiness/)、[runs](../experiments/cache-name-query-order-v1-2026-11-02/runs/)。

### cache-native-complement-recovery-v1-2026-11-02

[目录](../experiments/cache-native-complement-recovery-v1-2026-11-02/)：67 个文件，1,623,572 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-native-complement-recovery-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-native-complement-recovery-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-native-complement-recovery-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-native-complement-recovery-v1-2026-11-02/analysis/)、[logs](../experiments/cache-native-complement-recovery-v1-2026-11-02/logs/)、[readiness](../experiments/cache-native-complement-recovery-v1-2026-11-02/readiness/)、[runs](../experiments/cache-native-complement-recovery-v1-2026-11-02/runs/)。

### cache-native-first-token-competition-v1-2026-11-02

[目录](../experiments/cache-native-first-token-competition-v1-2026-11-02/)：11 个文件，477,698 字节；其中 3 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-native-first-token-competition-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-native-first-token-competition-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-native-first-token-competition-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-native-first-token-competition-v1-2026-11-02/analysis/)、[logs](../experiments/cache-native-first-token-competition-v1-2026-11-02/logs/)、[readiness](../experiments/cache-native-first-token-competition-v1-2026-11-02/readiness/)。

### cache-output-path-audit-v1-2026-11-01

[目录](../experiments/cache-output-path-audit-v1-2026-11-01/)：15 个文件，2,256,858 字节；其中 7 个数据/收据/清单文件。

文档：[README.md](../experiments/cache-output-path-audit-v1-2026-11-01/README.md)；[REPORT.zh-CN.md](../experiments/cache-output-path-audit-v1-2026-11-01/REPORT.zh-CN.md)；[SELF_CHECK.zh-CN.md](../experiments/cache-output-path-audit-v1-2026-11-01/SELF_CHECK.zh-CN.md)。

### cache-qk-component-factor-design-v1-2026-11-02

[目录](../experiments/cache-qk-component-factor-design-v1-2026-11-02/)：3 个文件，29,343 字节；其中 2 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-qk-component-factor-design-v1-2026-11-02/README.zh-CN.md)。

### cache-qk-component-factor-v1-2026-11-02

[目录](../experiments/cache-qk-component-factor-v1-2026-11-02/)：99 个文件，5,884,392 字节；其中 83 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-qk-component-factor-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-qk-component-factor-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-qk-component-factor-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-qk-component-factor-v1-2026-11-02/analysis/)、[logs](../experiments/cache-qk-component-factor-v1-2026-11-02/logs/)、[readiness](../experiments/cache-qk-component-factor-v1-2026-11-02/readiness/)、[runs](../experiments/cache-qk-component-factor-v1-2026-11-02/runs/)。

### cache-query-layout-coverage-v1-2026-11-02

[目录](../experiments/cache-query-layout-coverage-v1-2026-11-02/)：331 个文件，8,294,007 字节；其中 315 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-query-layout-coverage-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-query-layout-coverage-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-query-layout-coverage-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-query-layout-coverage-v1-2026-11-02/analysis/)、[data](../experiments/cache-query-layout-coverage-v1-2026-11-02/data/)、[logs](../experiments/cache-query-layout-coverage-v1-2026-11-02/logs/)、[readiness](../experiments/cache-query-layout-coverage-v1-2026-11-02/readiness/)、[runs](../experiments/cache-query-layout-coverage-v1-2026-11-02/runs/)。

### cache-query-state-direction-audit-v1-2026-11-02

[目录](../experiments/cache-query-state-direction-audit-v1-2026-11-02/)：2 个文件，19,752 字节；其中 1 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-query-state-direction-audit-v1-2026-11-02/README.zh-CN.md)。

### cache-query-state-result-review-v1-2026-11-02

[目录](../experiments/cache-query-state-result-review-v1-2026-11-02/)：3 个文件，28,117 字节；其中 1 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-query-state-result-review-v1-2026-11-02/README.zh-CN.md)。

### cache-query-state-transfer-design-v1-2026-11-02

[目录](../experiments/cache-query-state-transfer-design-v1-2026-11-02/)：4 个文件，174,907 字节；其中 2 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-query-state-transfer-design-v1-2026-11-02/README.zh-CN.md)。

### cache-query-state-transfer-v1-2026-11-02

[目录](../experiments/cache-query-state-transfer-v1-2026-11-02/)：67 个文件，3,054,683 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-query-state-transfer-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-query-state-transfer-v1-2026-11-02/DECISIONS.zh-CN.md)；[DEVIATIONS.zh-CN.md](../experiments/cache-query-state-transfer-v1-2026-11-02/DEVIATIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-query-state-transfer-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-query-state-transfer-v1-2026-11-02/analysis/)、[data](../experiments/cache-query-state-transfer-v1-2026-11-02/data/)、[logs](../experiments/cache-query-state-transfer-v1-2026-11-02/logs/)、[readiness](../experiments/cache-query-state-transfer-v1-2026-11-02/readiness/)、[runs](../experiments/cache-query-state-transfer-v1-2026-11-02/runs/)。

### cache-shared-prefix-continuation-v1-2026-11-02

[目录](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/)：68 个文件，731,346 字节；其中 53 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/analysis/)、[data](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/data/)、[logs](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/logs/)、[readiness](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/readiness/)、[runs](../experiments/cache-shared-prefix-continuation-v1-2026-11-02/runs/)。

### cache-sk-history-v1-2026-11-02

[目录](../experiments/cache-sk-history-v1-2026-11-02/)：67 个文件，1,530,906 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-sk-history-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-sk-history-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-sk-history-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-sk-history-v1-2026-11-02/analysis/)、[logs](../experiments/cache-sk-history-v1-2026-11-02/logs/)、[readiness](../experiments/cache-sk-history-v1-2026-11-02/readiness/)、[runs](../experiments/cache-sk-history-v1-2026-11-02/runs/)。

### cache-sp-v-qk-delivery-v1-2026-11-02

[目录](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/)：66 个文件，736,694 字节；其中 52 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/analysis/)、[logs](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/logs/)、[readiness](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/readiness/)、[runs](../experiments/cache-sp-v-qk-delivery-v1-2026-11-02/runs/)。

### cache-state-readout-decomposition-v1-2026-11-03

[目录](../experiments/cache-state-readout-decomposition-v1-2026-11-03/)：95 个文件，1,692,478 字节；其中 81 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-state-readout-decomposition-v1-2026-11-03/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-state-readout-decomposition-v1-2026-11-03/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-state-readout-decomposition-v1-2026-11-03/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-state-readout-decomposition-v1-2026-11-03/analysis/)、[logs](../experiments/cache-state-readout-decomposition-v1-2026-11-03/logs/)、[readiness](../experiments/cache-state-readout-decomposition-v1-2026-11-03/readiness/)、[runs](../experiments/cache-state-readout-decomposition-v1-2026-11-03/runs/)。

### cache-update-readout-audit-v1-2026-11-01

[目录](../experiments/cache-update-readout-audit-v1-2026-11-01/)：28 个文件，4,033,641 字节；其中 15 个数据/收据/清单文件。

文档：[README.md](../experiments/cache-update-readout-audit-v1-2026-11-01/README.md)；[REPORT.zh-CN.md](../experiments/cache-update-readout-audit-v1-2026-11-01/REPORT.zh-CN.md)；[SELF_CHECK.zh-CN.md](../experiments/cache-update-readout-audit-v1-2026-11-01/SELF_CHECK.zh-CN.md)。

资产分区：[source](../experiments/cache-update-readout-audit-v1-2026-11-01/source/)。

### cache-vq-write-interaction-causal-v1-2026-11-01

[目录](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/)：61 个文件，787,153 字节；其中 45 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/CONTRACT.zh-CN.md)；[DECISIONS.zh-CN.md](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/DECISIONS.zh-CN.md)；[REPORT.zh-CN.md](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/analysis/)、[logs](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/logs/)、[readiness](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/readiness/)、[runs](../experiments/cache-vq-write-interaction-causal-v1-2026-11-01/runs/)。

### cache-vq-write-interaction-design-audit-v1-2026-11-01

[目录](../experiments/cache-vq-write-interaction-design-audit-v1-2026-11-01/)：3 个文件，46,440 字节；其中 1 个数据/收据/清单文件。

文档：[README.zh-CN.md](../experiments/cache-vq-write-interaction-design-audit-v1-2026-11-01/README.zh-CN.md)。

### cross-channel-planning-audit-v1-2026-10-31

[目录](../experiments/cross-channel-planning-audit-v1-2026-10-31/)：5 个文件，193,643 字节；其中 2 个数据/收据/清单文件。

文档：[REPORT.zh-CN.md](../experiments/cross-channel-planning-audit-v1-2026-10-31/REPORT.zh-CN.md)；[SELF_CHECK.zh-CN.md](../experiments/cross-channel-planning-audit-v1-2026-10-31/SELF_CHECK.zh-CN.md)。

### cross-model-foundation-common-v1-2026-11-02

[目录](../experiments/cross-model-foundation-common-v1-2026-11-02/)：102 个文件，2,185,649 字节；其中 56 个数据/收据/清单文件。

文档：[DECISIONS.zh-CN.md](../experiments/cross-model-foundation-common-v1-2026-11-02/DECISIONS.zh-CN.md)；[F1_CHECKS.zh-CN.md](../experiments/cross-model-foundation-common-v1-2026-11-02/F1_CHECKS.zh-CN.md)；[F1_STEPS.zh-CN.md](../experiments/cross-model-foundation-common-v1-2026-11-02/F1_STEPS.zh-CN.md)；[PREFLIGHT.zh-CN.md](../experiments/cross-model-foundation-common-v1-2026-11-02/PREFLIGHT.zh-CN.md)；[PREFLIGHT_R02.zh-CN.md](../experiments/cross-model-foundation-common-v1-2026-11-02/PREFLIGHT_R02.zh-CN.md)。

资产分区：[runs](../experiments/cross-model-foundation-common-v1-2026-11-02/runs/)。

### cross-model-history-current-v1-2026-11-02

[目录](../experiments/cross-model-history-current-v1-2026-11-02/)：1 个文件，8,885 字节；其中 0 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cross-model-history-current-v1-2026-11-02/CONTRACT.zh-CN.md)。

### cross-model-natural-withdrawal-v1-2026-11-02

[目录](../experiments/cross-model-natural-withdrawal-v1-2026-11-02/)：1 个文件，5,530 字节；其中 0 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/cross-model-natural-withdrawal-v1-2026-11-02/CONTRACT.zh-CN.md)。

### early-state-localization-stage2-v2-2026-10-30

[目录](../experiments/early-state-localization-stage2-v2-2026-10-30/)：885 个文件，39,284,633 字节；其中 781 个数据/收据/清单文件。

文档：[CONTRACT.zh-CN.md](../experiments/early-state-localization-stage2-v2-2026-10-30/CONTRACT.zh-CN.md)；[IMPLEMENTATION.zh-CN.md](../experiments/early-state-localization-stage2-v2-2026-10-30/IMPLEMENTATION.zh-CN.md)；[PLAN.zh-CN.md](../experiments/early-state-localization-stage2-v2-2026-10-30/PLAN.zh-CN.md)；[README.md](../experiments/early-state-localization-stage2-v2-2026-10-30/README.md)；[REPORT.zh-CN.md](../experiments/early-state-localization-stage2-v2-2026-10-30/REPORT.zh-CN.md)。

资产分区：[analysis](../experiments/early-state-localization-stage2-v2-2026-10-30/analysis/)、[data](../experiments/early-state-localization-stage2-v2-2026-10-30/data/)、[exports](../experiments/early-state-localization-stage2-v2-2026-10-30/exports/)、[readiness](../experiments/early-state-localization-stage2-v2-2026-10-30/readiness/)、[reading](../experiments/early-state-localization-stage2-v2-2026-10-30/reading/)、[runs](../experiments/early-state-localization-stage2-v2-2026-10-30/runs/)。

### native-behavior-reference-v1-2026-11-01

[目录](../experiments/native-behavior-reference-v1-2026-11-01/)：8 个文件，174,215 字节；其中 4 个数据/收据/清单文件。

文档：[PLAN.zh-CN.md](../experiments/native-behavior-reference-v1-2026-11-01/PLAN.zh-CN.md)；[QUESTIONS.zh-CN.md](../experiments/native-behavior-reference-v1-2026-11-01/QUESTIONS.zh-CN.md)；[SELF_CHECK.zh-CN.md](../experiments/native-behavior-reference-v1-2026-11-01/SELF_CHECK.zh-CN.md)。