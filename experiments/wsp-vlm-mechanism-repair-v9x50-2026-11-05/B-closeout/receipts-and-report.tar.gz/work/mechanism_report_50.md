# Task B: 50-round mechanistic repair report

## 1. Decision and strength of evidence

Automatic selection: **round 38**, `c-84ca0f976010174a0a5618921b42963491d8ae388a333a69989ffb479ca8cbcd`.

Retain the automatic R38 selection for freezing without diagnostic reranking. The evidence supports local, context-dependent causal effects on numerical answer competition and a small official seen-development gain. It does not establish a robust incremental benefit of the selected pair over its head-only control, a shared spatial-success direction, a uniquely necessary zero-aligned component, serial spatial mediation, or general spatial-reasoning repair.

The original 30-round selection and freeze remain archived. This report supersedes that selection only for the reopened 50-round experiment; it does not rewrite the earlier evidence. All 50 candidate identities and content signatures were verified as distinct, with complete evaluations under the same protocol. No further repair was proposed after round 50.

## 2. Exact selected intervention

Base: `w0-72b28080bcd9951ceeeebfb62a5fd532cb3d52e4714ea3baedea3796b650ed06`. Layer, head, and channel indices are the recorded zero-based indices; column ranges are half-open.

- `model.language_model.layers.24.self_attn.o_proj.weight[:, 1664:1792]`: multiply the W0 head-13 output block by **1.5**. This changes 327,680 scalars.
- `model.language_model.layers.34.mlp.down_proj.weight[:, 1057:1058]`: replace the W0 output column by **zero**. This changes 2,560 scalars.
- All other parameters remain W0. Vision weights are untouched.
- Values are rounded to BF16 using round-to-nearest, ties-to-even. Total support is **330,240**, with delta L2 **5.530221067838229**.

The two committed tensor content hashes are:
- L24: `d6a502373294dcc941ebd579e4b94bffeb35837d533665a5fa93f6d1a1827d33`
- L34: `55fc8c1d36a72eb2cfd9f12b67fa1d2ce62575ef3d3ce7defb216b847b47e685`

Fresh CPU reconstruction verified both saved replacement blocks against canonical W0, exact BF16 rounding, support, delta norm, and equality outside the edited regions. It did not stage or commit another candidate. See `selected_weight_audit_50.json`, `round38_provenance.json`, and commit/evaluation actions 262/263.

## 3. Official behavioral outcome—not a repeat-adjusted score

| Metric | W0 | R38 |
|---|---:|---:|
| Correct prompts | 320/464 | 325/464 |
| Accuracy | 68.9655% | 70.0431% |
| Repair score, joint B0 pairs across T0/T1 | 55/116 | 57/116 |
| Primary B0:T0 joint | 27/58 | 27/58 |
| B0:T1 joint | 28/58 | 30/58 |
| B1:T0 joint | 29/58 | 29/58 |
| B1:T1 joint | 31/58 | 32/58 |
| Format errors / truncated outputs | 0 / 0 | 0 / 0 |

There are five official wrong-to-correct changes, no correct-to-wrong changes, and three wrong-to-wrong changes. All eight are shown below. Selected-cell accuracy does not decrease. Across all 50 candidates, the largest observed cell loss is one of 58 examples, within the unchanged 0.035 protection limit; every full evaluation has zero format errors and zero truncations.

Round 48 has higher raw accuracy (327/464), but repair score 56/116, eight repairs and one regression. It is **not** the automatic best. Neither raw accuracy nor diagnostic answers were substituted for the selection rule.

## 4. Fresh paired audit: decisive qualifications

Actions 341 and 342 remeasured R38 and W0 on 22 cases: the fixed 15-case panel plus all additional official R38 answer changes. Action 343 verified the full artifacts, complete generations, capture hashes, and input/chat hashes. This selected diagnostic panel is not a held-out set or a replacement 464-prompt evaluation.

| Case | Gold | Official W0 -> R38 | Fresh W0 -> R38 | Official change | Fresh margin (new minus old), W0 / R38 |
|---|---:|---|---|---|---|
| B-10840:subset:T1:B0 | 0 | 1 -> 0 | 1 -> 1 | repair | -0.5 / -0.25 |
| B-508641:subset:T1:B0 | 1 | 2 -> 1 | 2 -> 1 | repair | -0.25 / 0 |
| B-518494:total:T1:B0 | 3 | 4 -> 3 | 3 -> 3 | repair | 0 / 0.5 |
| B-445896:subset:T1:B1 | 0 | 2 -> 1 | 2 -> 1 | wrong to wrong | -0.25 / 0.25 |
| B-485772:subset:T1:B1 | 2 | 3 -> 2 | 3 -> 2 | repair | -0.25 / 0 |
| B-277920:subset:T1:B0 | 0 | 4 -> 3 | 3 -> 3 | wrong to wrong | 0 / 0.75 |
| B-372918:total:T0:B1 | 8 | 7 -> 8 | 7 -> 8 | repair | 0 / 0.5 |
| B-188190:subset:T0:B0 | 4 | 1 -> 2 | 1 -> 2 | wrong to wrong | 0 / 0.5 |

Only three of the five official repair contrasts reproduce in this fresh pair of diagnostic runs:
`B-508641:subset:T1:B0`, `B-485772:subset:T1:B1`, and `B-372918:total:T0:B1`.
The first two have tied candidate logits for the new and old answers. The third has tied W0 logits. Reproduction on these runs is not evidence of robustness to numerical or input perturbations.

The official zero repair on `B-10840:subset:T1:B0` does **not** reproduce: both models answer 1; W0 and R38 have 1-minus-0 margins +0.5 and +0.25. On `B-518494:total:T1:B0`, the official contrast is 4 to gold 3, but both fresh runs answer 3. W0 also changes 4 to 3 on `B-277920:subset:T1:B0`, where both answers are wrong.

There are no correctness regressions in this 22-case fresh pair, and no truncated generations. This does not establish zero repeat regressions over all 464 prompts. No repeat-adjusted aggregate score is reported.

For the overlapping 15 cases, fresh candidate and W0 answers, digit logits, and all captures exactly match their respective earlier diagnostic runs. This preserves rather than explains away the evaluation-versus-diagnostic discrepancies. Identical input/chat hashes do not identify their computational cause.

### Incremental benefit over head-only enhancement

R23, the head-13 x1.5 single-component control, obtains 324/464 and repair score 56/116. R38 has just one additional official correctness gain over R23: the non-reproducing zero repair on `B-10840:subset:T1:B0`. Both diagnostic runs answer 1; the head-only margin +1.0 falls to +0.25 under the pair without crossing zero.

A second official head-only-to-pair change, `B-129884:subset:T1:B0`, changes 3 to 0 with gold 5: neither is correct. It was not included in the fresh 22-case W0-versus-R38 panel. Thus the selected pair's incremental behavioral advantage over its head-only control is not robustly established. See `selected_head_only_comparison_50.json`.

## 5. Internal observations and their limits

The earlier investigation used same-image failure/success prompt contrasts, correct-answer controls, and last-prompt captures. L34 channel 1057 was strongly associated with answer 1: recorded median activation was 22.125 for 21 answer-one cases versus approximately 0.333 for 18 answer-zero cases. Correct-one cases also activated it. Prompt-form projection controls did not eliminate answer-content confounding; the small zero-answer contrast set had weak leave-one-out alignment. These observations do not identify a spatial-error detector or a shared spatial-success representation.

Temporary last-token interventions changed numerical margins and sometimes thresholded answers. Permanent weight-column edits act at all positions; they must not be equated with a last-token-only intervention. The visible outcome is context-dependent answer competition, not uniform suppression of the token 1.

For selected R38:
- L23 MLP inputs and layer outputs exactly match W0 on all 22 fresh cases.
- All checked captures before the edited L34 output match head-only R23 on the 15 cases with a head-only reference.
- The other seven cases lack that head-only reference; they are not counted as passes.
- These checks support correct intervention ordering. They do not establish head-specific attention routing or path-specific mediation.

Correct-one controls remain important negatives: on `B-242725:subset:T0:B0`, R38 changes the 1-minus-0 margin from 5.75 to 5.25 while keeping answer 1; on `B-538866:total:T0:B0`, it increases that margin from 17.75 to 18.0. The wrong answer 3 on `B-170386:subset:T1:B0` persists. The original failure on `B-538866:subset:T0:B0` also remains answer 1 with unchanged 1-minus-0 margin 3.25. No general spatial repair follows.

## 6. What the first 30 rounds established—and did not

The original experiment tested L34 attenuation/enhancement, projection removal/retention, activity-matched transfers, random perturbations, geometry-matched controls, alternative MLP columns, head-13 edits, a norm-matched head-24 control, and paired MLP edits.

Key counterevidence is retained:
- Removing the proposed parallel component did not reproduce the zebra repairs, whereas retaining it did; its removal was not necessary.
- Geometry-matched random-retention controls also repaired the same zebra cases. This weakens uniqueness claims for the proposed success direction and leaves generic attenuation as a live alternative.
- Global activity matching did not supply a good conditional eligible-column match; thresholds were not relaxed to manufacture one.
- L23 interventions incurred total-count regressions, and effects on downstream MLP activations occurred in both wrong and correct-one cases.
- Previous paired edits showed interactions and partial redundancy, but no path-specific mediation test was performed.
- Clarification and other prompt changes did not consistently resolve the failure behavior.

The original automatically selected R14 was itself a geometry-matched control, with 322/464 and repair score 56/116. Its original report, repeat audit, full ledger, and freeze record remain intact. The exact original evidence, including prior diagnostic disagreements, is linked by the preserved 30-round manifest rather than silently relabeled as evidence for R38.

## 7. Fixed continuation: rounds 31–50

The continuation plan was fixed after seeing the first 30 rounds, with SHA-256
`2d855d36dc1a1d33bcea52b18b3f1fe8c13c498b99901bffb0fbceb6f3bf36d0`.

- R31–R39: the 3 x 3 combination of head-13 factors 0.5, 0, 1.5 and L34-column factors 0.5, 0, 1.5.
- R40: a norm-matched head-24 enhancement-only anchor.
- R41–R46: head-24 attenuation/enhancement controls combined with half/zero L34 output.
- R47–R50: head-13/head-24 attenuation controls combined with half/zero L32 channel 619.

Each was reconstructed independently from W0; no cumulative editing or retuning after round 50 occurred. Head-24 factors were fixed from pre-rounding edit-norm matching: 0.5561204116261893, 0.11224082325237872, and 1.4438795883738107. BF16 rounding leaves small actual norm differences; exact equality after rounding is not claimed.

The complete 50-row table is `final_experiment_table_50.md`; the machine-readable ledger preserves every repair, regression, wrong-to-wrong change, cell delta, candidate ID, and action reference in `final_experiment_summary_50.json`.

Dose tests did not establish a specific shared spatial computation. Under head-13 enhancement, L34 factors 0, 0.5, 1, 1.5 give zebra-case 1-minus-0 margins 0.25, 0.75, 1.0, 1.25; all diagnostic answers remain 1. Correct-one controls also move, and the total-count control can move in the opposite direction. R43 is a useful negative: 320/464, no repairs or regressions, and only one wrong-to-wrong change.

## 8. Matched-head and alternative-MLP comparisons

Let m be a recorded digit-logit margin. The conditional MLP effect is
`m(head + MLP edit) - m(head edit)`.
Where both single-edit measurements exist, factorial interaction is
`m(head + MLP edit) - m(head edit) - m(MLP edit) + m(W0)`.

The matched-head contrast below subtracts the head-24 conditional effect from the head-13 conditional effect, over the same 15 cases and three margins. It does not compare raw paired margins without accounting for the head-only effect.

| Head-13 / norm-matched head-24 rounds | Correct | Repairs | Regressions | Maximum absolute conditional differences: 1-0, 1-2, 3-0 |
|---|---|---|---|---|
| 31 / 41 | 323 / 322 | 4 / 2 | 1 / 0 | 0.25, 0.5, 0.25 |
| 32 / 42 | 324 / 322 | 5 / 2 | 1 / 0 | 0.25, 0.375, 0.25 |
| 34 / 43 | 323 / 320 | 5 / 0 | 2 / 0 | 0.25, 0.375, 0.25 |
| 35 / 44 | 323 / 323 | 5 / 3 | 2 / 0 | 0.5, 0.25, 0.375 |
| 37 / 45 | 324 / 323 | 4 / 4 | 0 / 1 | 0.25, 0.5, 0.25 |
| 38 / 46 | 325 / 323 | 5 / 4 | 0 / 1 | 0.25, 0.375, 0.375 |
| 47 / 49 | 323 / 322 | 4 / 2 | 1 / 0 | 0.5, 0.5, 0.25 |
| 48 / 50 | 327 / 321 | 8 / 1 | 1 / 0 | 0.5, 0.375, 0.375 |

The largest observed absolute matched-head conditional differences are 0.5, 0.5, and 0.375 for the three margins. Such small observed differences do not demonstrate equivalence, numerical noise, or a uniquely spatial head-13-to-MLP pathway. Whole-development answer counts can differ at decision boundaries.

Four cross-MLP comparisons at identical head settings compare L34 channel 1057 with L32 channel 619. Their maximum absolute differences in the three conditional margins are:
- R31/R47: 0.5, 0.5, 0.75; both have 323/464.
- R35/R48: 0.5, 1.25, 1.625; 323 versus 327/464.
- R41/R49: 0.25, 0.75, 0.875; both have 322/464.
- R44/R50: 0.75, 1.25, 1.75; 323 versus 321/464.

These MLP-column edits are **not norm-matched to each other**. They are alternative-component comparisons, not evidence of an isolated layer effect.

Standalone R2/R3 diagnostics were unavailable. Interactions needing those anchors remain null; conditional effects and dose comparisons do not fill in the missing measurements. Existing evaluation-versus-diagnostic discrepancies in the L32 half-edit reference also remain a limitation. Full records are in `matched_head_L34_pairs_31_46.json` and `matched_L32_and_cross_MLP_comparisons_50.json`.

## 9. Continuation diagnostic disagreements

Every entry below is retained separately from official scoring. These are comparisons on the fixed 15-case panel, not whole-development repeat tests.

| Round | Official-evaluation versus diagnostic answer disagreements on the fixed 15-case panel |
|---:|---|
| 31 | B-538866:subset:T0:B1 |
| 32 | None |
| 33 | None |
| 34 | None |
| 35 | None |
| 36 | None |
| 37 | None |
| 38 | B-10840:subset:T1:B0 |
| 39 | None |
| 40 | B-10840:subset:T1:B0; B-3805:subset:T1:B1 |
| 41 | B-10840:subset:T1:B0; B-3805:subset:T1:B1 |
| 42 | B-3805:subset:T1:B1 |
| 43 | None |
| 44 | B-10840:subset:T1:B0 |
| 45 | B-10840:subset:T1:B0 |
| 46 | None |
| 47 | None |
| 48 | B-101422:subset:T0:B1 |
| 49 | B-10840:subset:T1:B0; B-3805:subset:T1:B1 |
| 50 | B-10840:subset:T1:B0; B-3805:subset:T1:B1 |

Per-round diagnostic audits preserve complete answers, margins, capture metadata, ordering checks, and identified or missing interaction references. The final 22-case selected audit additionally documents the W0 disagreements described above.

## 10. Scope, independence, and stopping

There are 58 image groups, 464 correlated prompts, and 116 correlated B0 total/subset pairs across templates. Fifty candidates were examined on development data. The fixed continuation is not independent of the first-stage evidence, and the selected diagnostic panel is not an unbiased estimate of generalization. No independent-prompt significance claim is made.

No held-out or branch-C evaluation, independent confirmation, or completed independent scientific review is claimed. The primary B0:T0 joint metric never improved in this search. Passing the observed protection constraints does not establish preservation on unseen inputs.

All 50 planned rounds are complete. Diagnostic findings were not used to replace official selection, conceal unsuccessful tests, or create a 51st candidate. Report submission and freezing are separate harness steps; this evidence packet alone does not assert that either has already succeeded.

## 11. Reproducibility packet

New files:
- `mechanism_report_50.md` and `mechanism_report_50.json`
- `final_experiment_summary_50.json` and `final_experiment_table_50.md`
- `final_evidence_manifest_50.json`
- `completion_verification_50.json`
- `selected_weight_audit_50.json`
- `selected_head_only_comparison_50.json`
- `selected_best_final_audit_plan_50.json`
- `selected_best_repeat_audit_50.json`

The manifest hashes the preserved original sources, continuation provenance and replacement blocks, commit/evaluation/diagnostic artifacts, referenced continuation/final capture arrays, and new reports. It excludes its own hash to avoid self-reference. The original 30-round manifest entries were verified unchanged before these files were created.

**Bottom line:** a small official development gain with boundary-sensitive, context-dependent numerical effects; no established general spatial mechanism and no robustly demonstrated incremental behavioral benefit of the selected pair over its head-only control.
