# Direct math-weight repair
No edits yet. Baseline diagnosis precedes localization.
Disjoint diagnostic/tuning/validation/confirmation IDs saved in splits.json.
Primary criterion: paired accuracy gain on untouched problems larger than its SE.
Secondary: mechanism-specific behavior, dose-response, and dense teacher-forced evidence.

Pass 1: original 192 cases, accuracy 92.71%; GSM8K 91.67%, MATH 99.11%, AIME 71.88%; mean 8775.7 tokens. 14 failures: 9 cutoffs, 5 wrong answers. MATH error inspected was interval-format equivalence; GSM errors mainly ambiguity. AIME cutoffs include repeated reconsideration and explicit sequence loops. All-layer MLP means collected.

Pass 2: matched-text repetition probes expose concordant amplification in L30 neurons 8 and 47 (early means near 0; repeated means -7.11/-5.76 and -5.78/-4.85 in two independent loops). L31 neurons 13 and 8174 also amplify. Productive recurrence and combinatorics controls included. Testing sparse down-projection ablation; no norm/embedding/boundary edits.

Pass 3: ablating L30 neurons 8/47 did not selectively reduce repeated-text likelihood; discarded. Pass 4 attention localization: L27 head13 assigns 90.7% attention to the successor position in prior repeated blocks, versus only 0.3% to the recent six tokens. Strongest +1 induction head. Testing 50% head-output attenuation, not a whole-tensor scale.

Pass 5: head27.13 x0.5 weakly reduces repeated likelihood, but also productive solution likelihood. Pass 6 paired generation (64 enriched diagnostic items x2): 83.59% ->78.12%, delta -5.47pp SE3.88pp; cut share 13.28% ->18.75%; 4 rescues,11 regressions. Reject x0.5. Testing reverse intervention x1.5 to distinguish continuity-support from repetition-driving function.

Pass 7: head27.13 x1.5 also harms: -3.91pp SE3.01pp, cut share17.97%. Both directions rejected; head27.13 appears important for useful continuity. Next causal target: last-layer head31.5, 56.3% successor-copy attention, less opportunity for downstream correction.

Pass 8: head31.5 ablation -3.12pp SE3.84pp, discarded. New direction-level hypothesis: recurrent-state persistence represented by shared late-minus-first hidden32 direction on token-identical repeated blocks. Orthogonalized to productive recurrence progress and thinking/EOS readout. Analytic rank-one removal from layer31 MLP output, no fitting or embedding/norm edits.

Pass 9 falsified the reinforcement sign: removing the loop-axis MLP31 component INCREASED residual loop scores (first planning block -40.95 -> -21.38; sixth14.31 ->20.49). Unproductive first planning likelihood rose +0.145 nat/token; productive controls lost0.021/0.027. Thus MLP31 provides compensatory anti-loop output. Testing doubling this axis (alpha=-1), a 2.596% Frobenius rank-one edit.

Pass 10: doubling final-MLP loop-axis correction failed paired generation: -2.34pp SE3.60pp; cut share13.28% ->14.84%. Rejected. Need layer-resolved localization instead of assuming final MLP is source.

Pass 12: sparse24 ablation selectively lowered repeated-block likelihood (up to0.0149nat/token), lowered raw layer31 loop scores by~1.9, and improved productive controls+0.0030/+0.0023. Pass13 paired diagnostic accuracy neutral:6 rescues/6 regressions, delta0 SE2.73pp; mean tokens-302, cutshare+0.78pp. Testing same24 neurons at scale-1 for stronger predefined dose.

Pass14 sparse24 scale-1: delta-0.78pp SE2.61pp,6 rescues7 regressions; mean tokens-745; cuts unchanged. MATH+2.5pp/GSM0/AIME-3.13pp on small enriched panel. Kernel transport restarted; records restored. Next: disjoint128 tuning MATH/GSM items x2, candidate unchanged.

Pass15 sparse24 scale-1 on disjoint tuning128 x2: delta0pp SE1.36pp,7 rescues/7 regressions. Mean7428.5->6970.8; cuts3.91%->3.12%. Not validated; reject as final candidate.

New hypothesis: persistent DeltaNet state sustains repeated re-derivation. Weight-only screening: L24 head9 nominal decay0.000661, loop-axis alignment1.305x isotropic, highest among late persistent heads. Pass16 baseline six matched probes. Candidate changes only L24 A_log[9] += log16 (16x decay), not boundary or readout weights.

Pass17 L24h9 decayx16 dense deltas: [{"probe": 0, "start": 29, "early_delta": 0.0017390514258295298, "late_delta": 0.013344804756343365}, {"probe": 1, "start": 35, "early_delta": -0.0007248320034705102, "late_delta": 0.002041022526100278}, {"probe": 2, "start": 46, "early_delta": -0.0034234339836984873, "late_delta": 0.008703087456524372}, {"probe": 3, "start": 29, "early_delta": 0.007155392784625292, "late_delta": 0.10440555214881897}, {"probe": 4, "start": 29, "early_delta": -0.003168769646435976, "late_delta": 0.02650870382785797}, {"probe": 5, "start": 43, "early_delta": -0.004008632153272629, "late_delta": 0.056714627891778946}]. Productive full-text likelihood deltas +0.0411,+0.0090,+0.0226 nat/token. Next paired tuning128x2, not validation.

Pass18 L24h9 decayx16 tuning128x2: 95.70%->97.27%, delta+1.56pp SE1.10pp,7 rescues3 regressions; mean7428.5->7152.8; cuts3.91%->1.17%. Candidate saved /work/candidate_l24h9_x16. Not yet validated.
NEXT pass19: only model.language_model.layers.24.linear_attn.A_log[9] = original + log(4); all others original. Generation both, IDs /work/tuning128_ids.json, n=2,max_tokens32768. Predefined weaker dose test.

Pass19 L24h9 decayx4 tuning128x2: delta+0.39pp SE1.30pp,7 rescues6 regressions; cuts3.91%->1.95%; mean7428.5->7085.2. Neutral accuracy.
NEXT pass20: only model.language_model.layers.24.linear_attn.A_log[9] = original + log(64); all others original. Generation both, exact IDs /work/tuning128_ids.json, n2,max_tokens32768. Predefined strong dose.

Pass20 L24h9 decayx64 tuning128x2: +1.17pp SE1.41pp,8 rescues5 regressions; cuts1.95%,mean7394.6. Dose results x4 +0.39, x16 +1.56, x64 +1.17pp: suggestive, not significant.
FROZEN candidate for four validation batches: ONLY model.language_model.layers.24.linear_attn.A_log[9] = original + log16. No other edits. Preselected 1024 unseen problems, four256 batches each64GSM+192MATH, IDs in /work/memory_validation_batches.json. No outcome-based stopping or tuning within these four batches. Aggregate paired accuracy and source-specific outcomes decide retention.
NEXT pass21: both models, memory_validation_batches.json batch0, n1,max_tokens32768, frozen L24h9x16.

Formatting caveat: passes16/17 chats inserted an empty thinking segment before the supplied <think>; their dense evidence is provisional and requires raw-text replication. Generation protocol unaffected.
Pass21 frozen L24h9x16 validation batch0: 96.48%->95.31%, delta-1.17pp SE0.67pp,0 rescues3 regressions; cuts2.73%->4.30%; mean7349.4->8169.2. Adverse, candidate NOT validated.
NEXT pass22: ONLY model.language_model.layers.24.linear_attn.A_log[9]=original+log16; both models; /work/memory_validation_batches.json batch1, n1,max_tokens32768. Continue fixed four-batch plan without tuning.

Pass22 frozen L24h9x16 validation batch1: delta0pp SE1.46pp,7 rescues7 regressions; original95.31%,edited95.31%; cuts1.95%->2.73%. Transport restarted kernel, persistent records intact.
NEXT pass23: ONLY model.language_model.layers.24.linear_attn.A_log[9]=original+log16; both models; /work/memory_validation_batches.json batch2,n1,max_tokens32768. No tuning during validation.

Pass23 L24h9x16 validation batch2: delta-0.39pp SE0.87pp,2 rescues3 regressions;94.53%->94.14%; cuts unchanged2.34%;mean6879.6->7094.8. Cumulative768 unseen:9 rescues13 regressions, no support.
NEXT pass24: ONLY model.language_model.layers.24.linear_attn.A_log[9]=original+log16; both; /work/memory_validation_batches.json batch3,n1,max_tokens32768. Last fixed validation batch.

Pass24 L24h9x16 validation batch3: -1.17pp SE1.17pp,3 rescues6 regressions. Full1024:12 rescues19 regressions, delta-0.684pp. REJECTED and all edits cleared. MATH worsened despite tuning gains; cannot retain.

Next hypothesis: repetition-dependent reconsideration feedback. Selected top8 MLP channels by min across two token-matched loop activation changes times output alignment with a reconsideration direction and control specificity. Channels saved reconsideration_components.json: [[30, 19], [28, 43], [30, 158], [18, 295], [17, 71], [30, 8], [31, 199], [31, 2]]. Direction saved reconsideration_direction.pt: mean readout(Wait/But/However/Maybe/Perhaps/check/verify/again/reconsider) minus progress words, using original embedding*final-norm only for analysis, orthogonalized to think/end tokens and digits/operators. NO embedding/norm edits.
NEXT pass25: ORIGINAL model, no current edits. Eight raw-text probes with exact evaluation prompt format: repetitive multiplication, repetitive complex equations, repetitive digit statements, independent multiplication verification, distinct-digit counting, productive recurrence, legitimate arithmetic error correction, legitimate sign correction. Return logprobs and MLP17,18,28,30,31 plus hidden31. Baseline for predefined alpha8 selective projection removal and dose tests, not early termination.

Pass25 valid raw-text baseline recorded at /work/fwd_25. Eight probes, lengths320,356,406,147,203,243,154,113. Legitimate error corrections included.
NEXT pass26: EDITED, same eight raw texts as pass25. Exact edit: for (L,j) in reconsideration_components.json, original down_proj[:,j] minus 8*u*(u dot original down_proj[:,j]), u in reconsideration_direction.pt; only layers17,18,28,30,31 MLP down_proj. All other weights original. Return logprobs,hidden31,MLP17,18,28,30,31.

Pass26 reconsider8 alpha8 dense: [{"i": 0, "answer_delta": 9.6e-05, "late_delta": -0.001086, "reconsider_tokens": 25, "reconsider_delta": -0.003321}, {"i": 1, "answer_delta": -0.001863, "late_delta": -2.6e-05, "reconsider_tokens": 9, "reconsider_delta": 0.013354}, {"i": 2, "answer_delta": -1.9e-05, "late_delta": -7e-06, "reconsider_tokens": 6, "reconsider_delta": -0.006664}, {"i": 3, "answer_delta": -0.002878, "late_delta": -0.003064, "reconsider_tokens": 1, "reconsider_delta": -0.019739}, {"i": 4, "answer_delta": -0.000479, "late_delta": 0.001862, "reconsider_tokens": 0, "reconsider_delta": null}, {"i": 5, "answer_delta": -0.000477, "late_delta": -0.001961, "reconsider_tokens": 0, "reconsider_delta": null}, {"i": 6, "answer_delta": -0.003633, "late_delta": -0.002178, "reconsider_tokens": 1, "reconsider_delta": -0.000111}, {"i": 7, "answer_delta": -0.001223, "late_delta": -0.006488, "reconsider_tokens": 1, "reconsider_delta": 0.093331}]. Effects tiny, no clear specificity yet.
NEXT pass27: EDITED same eight raw texts as pass25. Exact edit: selected columns in reconsideration_components.json, W[:,j]=W0[:,j]-64*u*(u@W0[:,j]); u=reconsideration_direction.pt, layers17,18,28,30,31 only. Strong causal stress test; logprobs and hidden31.

Pass27 reconsideration-direction alpha64 still nonselective/tiny (loop full deltas -0.00159,+0.00070,+0.00096; controls mostly worsened). REJECT direction-only eight-channel edits; removed.
New localization: L17 neuron71 late loop means -1.002,-0.728,-0.771 vs productive/correction +0.079,+0.049,+0.083,+0.122,+0.092. L18 neuron295 loops1.208,1.070,0.804 vs controls0.014,0.012,0.012,0.005,-0.001. Strong replicated selectivity, sign still unknown.
NEXT pass28 EDITED: ONLY model.language_model.layers.17.mlp.down_proj.weight column71 and layers.18.mlp.down_proj.weight column295 set to zero, all other values original. Teacher forced raw probes0,1,6,7 from fwd25 (two loops and two genuine corrections), logprobs,hidden31,mlp17,18. Causal sign test.

Pass28 two-neuron ablation: first probe has accidental missing space at391.That, invalidating full-text comparison; restrict comparison to common prefix. Matched results [{"probe": 0, "common_prefix_tokens": 258, "delta_nat": 0.0032594159711152315}, {"probe": 1, "common_prefix_tokens": 356, "delta_nat": -0.0009465770563110709}, {"probe": 6, "common_prefix_tokens": 154, "delta_nat": 0.0009333746274933219}, {"probe": 7, "common_prefix_tokens": 113, "delta_nat": -0.002119989600032568}]. Other probes exact. No strong dense benefit established.
NEXT pass29: both models, /work/tuning128_ids.json, n2,max_tokens32768. ONLY L17.mlp.down_proj[:,71]=0 and L18.mlp.down_proj[:,295]=0 (full tensor names model.language_model.layers.*); all other weights original. Causal generation test of two-neuron ablation.

Pass29 pair ablation tuning128x2: -1.17pp SE1.03pp,3 rescues6 regressions; mean7070.6 vs7428.5, cutshareunchanged3.91%. Reject ablation. Test opposite causal sign.
NEXT pass30: only model.language_model.layers.17.mlp.down_proj[:,71] and layers.18.mlp.down_proj[:,295] multiplied by4 relative to ORIGINAL; all other values original. Teacher raw probes0,1,6,7 from fwd25, EXACT corrected spaces; return logprobs,hidden31. Hypothesis compensatory feedback.

Pass30 pairx4 dense [{"probe": 0, "full_delta": -0.0036332737654447556, "last_half_delta": -0.005396013148128986}, {"probe": 1, "full_delta": -0.0032315137796103954, "last_half_delta": -0.006599317770451307}, {"probe": 6, "full_delta": -0.0012837153626605868, "last_half_delta": -0.002977580763399601}, {"probe": 7, "full_delta": -0.003135785460472107, "last_half_delta": -0.005342408083379269}]. Loop likelihood slightly lower, controls also slightly lower; weak specificity.
NEXT pass31: both models, IDs /work/tuning128_ids.json,n2,max_tokens32768. ONLY model.language_model.layers.17.mlp.down_proj[:,71] and layers.18.mlp.down_proj[:,295] =4x original columns; all other weights original. Causal opposite-sign generation.

Pass31 two-neuron x4: -1.17pp SE1.41pp,6 rescues9 regressions; rejected, all edits cleared. Natural MATH cutoffs often re-derive already correct results. Next: decompose exact repeated-block residual changes to distinguish attention reinforcement from MLP compensation. Direction in attention_loop_direction.pt uses raw hidden31 with initial/productive means and thinking/EOS readouts projected out; no norm/embedding edits.

New localization: raw hidden31 loop-axis agreement0.681 across exact repeated blocks; L30 DeltaNet attention adds2.405/1.768 units, largest shared attention reinforcement. Candidate ONLY L30.linear_attn.out_proj.weight W=W0-alpha*u*(u@W0), u=attention_loop_direction.pt; alpha1 now. NEXT pass32 edited exact four synthetic texts from fwd11, logprobs and hidden31/32; compare repeated late-vs-first blocks and productive controls. All other weights original.

Pass32 L30attention loop-axis alpha1 dense: [{"probe": 0, "answer_delta": 0.001003, "early_delta": 0.005512, "late_delta": 7.8e-05, "loop_accumulation_before": 19.521, "loop_accumulation_after": 17.011}, {"probe": 1, "answer_delta": -0.001259, "early_delta": 0.000474, "late_delta": -0.00176, "loop_accumulation_before": 16.728, "loop_accumulation_after": 14.885}, {"probe": 2, "answer_delta": 0.001248}, {"probe": 3, "answer_delta": -0.004913}].
NEXT pass33 same four exact raw texts, edited alpha3: W30.out_proj=W0-3*u*(u@W0); logprobs,hidden31/32. All other weights original.

Pass33 L30attention loop-axis alpha3 dense: [{"probe": 0, "answer_delta": -0.000146, "early_delta": 0.005883, "late_delta": -0.002264, "loop_accumulation_before": 19.521, "loop_accumulation_after": 11.998}, {"probe": 1, "answer_delta": -0.004869, "early_delta": -0.000183, "late_delta": -0.005565, "loop_accumulation_before": 16.728, "loop_accumulation_after": 11.181}, {"probe": 2, "answer_delta": 0.000262}, {"probe": 3, "answer_delta": -0.004578}].
NEXT pass34 both models, tuning128_ids.json,n2,max_tokens32768. ONLY L30.linear_attn.out_proj=W0-3*u*(u@W0), u=attention_loop_direction.pt. Paired accuracy is primary; synthetic effects not sufficient.

Pass34 L30attention alpha3 tuning128x2: delta0pp SE1.11pp,6 rescues6 regressions; mean7428.5->7526.3,cuts3.91%->4.30%. No accuracy support. NEXT pass35 both models same tuning128x2,max32768; alpha1 W30.out_proj=W0-u*(u@W0), all else original.

Pass35 L30attention alpha1 tuning128x2:-1.17pp SE1.61pp,6 rescues9 regressions,cutsunchanged. Removed. Kernel restarted; files intact.
Distributed hypothesis: redundant late reinforcement. Select previously measured sources with min across two probes: attention>=1 (L27,L30), MLP>=0.8 (L19,27,28,29,30). ONLY these7 output matrices changed W=W0-alpha*u*(u@W0), u=attention_loop_direction.pt. Alpha1 now. NEXT pass36 edited exact fwd11 four raw probes,logprobs,hidden31/32. No other edits. Need dose test and independent accuracy validation; no current validated candidate.

Pass36 distributed alpha1 dense: [{"probe": 0, "answer_delta": -0.002314, "early_delta": 0.015895, "late_delta": -0.003597, "loop_before": 19.521, "loop_after": 8.171}, {"probe": 1, "answer_delta": -0.002306, "early_delta": -0.000564, "late_delta": -0.007883, "loop_before": 16.728, "loop_after": 8.088}, {"probe": 2, "answer_delta": -0.012508}, {"probe": 3, "answer_delta": -0.016553}].
NEXT pass37 opposite sign distributed alpha=-1 (W=W0+u*(u@W0)) in same7 matrices; exact four fwd11 raw texts, logprobs,hidden31/32,topk20. Test whether this axis supports monitoring rather than causing loops. No accuracy claim.

Pass37 distributed amplification alpha=-1: [{"probe": 0, "common_tokens": 341, "answer_delta": 0.001376, "early_delta": -0.030263, "late_delta": 0.002102, "loop_before": 18.645, "loop_after": 33.199}, {"probe": 1, "common_tokens": 367, "answer_delta": 0.002681, "early_delta": -0.008654, "late_delta": 0.005954, "loop_before": 16.728, "loop_after": 28.579}, {"probe": 2, "common_tokens": 374, "answer_delta": 0.018445}, {"probe": 3, "common_tokens": 334, "answer_delta": 0.018897}]. Probe0 accidentally5 not6 repeats; prefix-only token-identical comparison used; other probes exact. Productive likelihood improved unlike suppression; possible monitoring/continuity signal rather than harmful loop driver.
NEXT pass38 both models tuning128_ids.json,n2,max32768. ONLY7 distributed output matrices (MLP19,27,28,29,30; attention27,30) W=W0+u*(u@W0). No current validated candidate.

Pass38 distributed alpha=-1 tuning128x2:+0.39pp SE1.18pp,6rescues5regressions,cuts3.91%->2.34%,mean7428.5->7155.3. Not significant. NEXT pass39 distributed alpha=-2 (W=W0+2*u*(u@W0)), exact four probes fromfwd11 plus legitimate correction probes6/7 fromfwd25. Returnlogprobs,hidden31/32. Then stronger-dose paired generation; no validated edit yet.

Pass39 distributed alpha=-2 dense:[{"probe": 0, "common_tokens": 390, "answer_delta": -0.000114, "early_delta": -0.08279, "late_delta": 0.003929, "loop_before": 19.521, "loop_after": 52.276}, {"probe": 1, "common_tokens": 367, "answer_delta": 0.008549, "early_delta": -0.014403, "late_delta": 0.008846, "loop_before": 16.728, "loop_after": 43.016}, {"probe": 2, "common_tokens": 374, "answer_delta": 0.036395}, {"probe": 3, "common_tokens": 334, "answer_delta": 0.041498}]; legitimate corrections:[{"probe": 6, "wrong_prefix_delta": 0.030282, "correction_delta": -0.014493}, {"probe": 7, "wrong_prefix_delta": 0.233768, "correction_delta": -0.000678}].
NEXT pass40 both models same tuning128x2,max32768; seven matrices W=W0+2*u*(u@W0). All other weights original. Primary criterion paired accuracy.

Pass40 distributed alpha=-2 tuning128x2:-0.39pp SE1.04pp,5rescues6regressions,cuts3.91%->1.95%,wrong finished3->7. Stronger dose rejected.
FROZEN FINAL VALIDATION: weaker alpha=-1 candidate (seven output matrices W=W0+u*(u@W0), u=attention_loop_direction.pt, spec frozen_distributed_spec.json). Tuning+0.39pp SE1.18pp is NOT evidence of gain. Eight preselected batches,total2048 unseen practice IDs, each64GSM+192MATH, file final_validation_batches.json. Never used in any prior generation; selection seed20261104. No stopping/tuning within8 batches. Retain only aggregate paired accuracy gain>2SE and assess source harm. Backup candidate_distributed_plus1.
NEXT pass41 both models,batch0,n1,max32768. Passes41..48 batches0..7. Two remaining passes reserved dense specificity audit. No validated candidate yet.

Pass41 frozen distributed+1 validation batch0: {"n": 256, "original": 97.266, "edited": 97.266, "delta_pp": 0.0, "se_pp": 0.783, "rescues": 2, "regressions": 2, "cuts_original": 1.562, "cuts_edited": 1.562}. Continue unchanged. Kernel restarted; saved edit matches frozen spec. NEXT pass42 batch1,n1,max32768,both.

Pass42 frozen validation batch1:delta0pp SE1.11pp,4rescues4regressions,cuts3.52%->2.34%. Cumulative:{"n": 512, "original": 96.094, "edited": 96.094, "delta_pp": 0.0, "se_pp": 0.677, "rescues": 6, "regressions": 6, "cuts_original": 2.539, "cuts_edited": 1.953}. NEXT pass43 batch2,n1,max32768,both; frozen seven-matrix +1 unchanged.

Pass43 frozen validation batch2:-0.39pp SE1.17pp,4rescues5regressions. Cumulative:{"n": 768, "original": 95.443, "edited": 95.312, "delta_pp": -0.13, "se_pp": 0.597, "rescues": 10, "regressions": 11, "cuts_original": 2.604, "cuts_edited": 2.083}. NEXT pass44 batch3,n1,max32768,both; same frozen seven-matrix +1.

Pass44 frozen validation batch3:+0.39pp SE1.04pp,4rescues3regressions. Cumulative:{"n": 1024, "original": 95.312, "edited": 95.312, "delta_pp": 0.0, "se_pp": 0.517, "rescues": 14, "regressions": 14, "cuts_original": 2.832, "cuts_edited": 2.441}. Transport restart; files preserved. NEXT pass45 batch4,n1,max32768,both; frozen seven-matrix +1 remains unchanged.

Pass45 frozen validation batch4:+0.39pp SE1.30pp,6rescues5regressions; source split MATH+3/192,GSM-2/64. Cumulative:{"n": 1280, "original": 95.234, "edited": 95.312, "delta_pp": 0.078, "se_pp": 0.488, "rescues": 20, "regressions": 19, "cuts_original": 2.734, "cuts_edited": 2.344}. NEXT pass46 batch5,n1,max32768,both; frozen seven-matrix+1.

Pass46 frozen validation batch5:+1.17pp SE1.03pp,5rescues2regressions,MATH net+3,GSM0;cuts3.52%->1.95%. Cumulative:{"n": 1536, "original": 95.312, "edited": 95.573, "delta_pp": 0.26, "se_pp": 0.442, "rescues": 25, "regressions": 21, "cuts_original": 2.865, "cuts_edited": 2.279}. NEXT pass47 batch6,n1,max32768,both; unchanged frozen+1.

Pass47 frozen validation batch6:-0.78pp SE1.11pp,3rescues5regressions,cuts1.95%->3.52%. Cumulative:{"n": 1792, "original": 95.48, "edited": 95.592, "delta_pp": 0.112, "se_pp": 0.41, "rescues": 28, "regressions": 26, "cuts_original": 2.734, "cuts_edited": 2.455}. NEXT pass48 batch7,last fixed batch,n1,max32768,both; no retuning. Passes49/50 dense specificity audit only.


Pass48 completed frozen validation, 2048 independent IDs. {"all": {"n": 2048, "original_correct": 1956, "edited_correct": 1953, "original_accuracy_pct": 95.5078, "edited_accuracy_pct": 95.3613, "delta_pp": -0.1465, "se_pp": 0.3937, "ci95_pp": [-0.9182, 0.6253], "rescues": 31, "regressions": 34, "mcnemar_exact_p": 0.80432, "cut_original": 53, "cut_edited": 54, "mean_tokens_original": 7130.6, "mean_tokens_edited": 7155.6}, "gsm8k": {"n": 512, "original_correct": 491, "edited_correct": 487, "original_accuracy_pct": 95.8984, "edited_accuracy_pct": 95.1172, "delta_pp": -0.7812, "se_pp": 0.6764, "ci95_pp": [-2.1069, 0.5444], "rescues": 4, "regressions": 8, "mcnemar_exact_p": 0.3877, "cut_original": 11, "cut_edited": 10, "mean_tokens_original": 4248.1, "mean_tokens_edited": 4114.2}, "math": {"n": 1536, "original_correct": 1465, "edited_correct": 1466, "original_accuracy_pct": 95.3776, "edited_accuracy_pct": 95.4427, "delta_pp": 0.0651, "se_pp": 0.4741, "ci95_pp": [-0.8642, 0.9944], "rescues": 27, "regressions": 26, "mcnemar_exact_p": 1.0, "cut_original": 42, "cut_edited": 44, "mean_tokens_original": 8091.5, "mean_tokens_edited": 8169.4}}
REJECT frozen distributed+1: failed precommitted paired gain >2SE. Keep temporarily ONLY for final original/edited dense specificity audit (passes49/50), then remove all edits. Dense results cannot override held-out accuracy.

Final specificity audit fixed before passes49/50: 16 raw-text probes, four tasks crossed with productive/correction/unfinished/repeated checking. Identical texts original then frozen edited, token logprobs and hidden31/32. Examine body likelihood, legitimate correction likelihood, late-versus-first repeated blocks, and forced </think> likelihood by condition. Synthetic diagnostics only; all candidate edits will be removed because accuracy validation failed.

Passes49/50 complete. All 7 remaining edits REMOVED with drop_edit; edited() empty; each affected tensor verified torch.equal(load(name),load_original(name)). FINAL CHOICE: UNMODIFIED MODEL. No candidate met held-out accuracy criterion. One specificity probe has differing lengths; token alignment audited and any nonidentical whole-text comparison must be excluded.

Final specificity audit (15 identical pairs, probe11 excluded): {"productive": {"n_probes": 4, "body_delta_nat_per_token": 0.021629, "close_token_delta_nat": -0.814933, "body_direction_delta": -2.112657}, "correction": {"n_probes": 4, "body_delta_nat_per_token": 0.035432, "close_token_delta_nat": -0.80983, "body_direction_delta": -3.139441, "incorrect_prefix_delta_nat_per_token": 0.113626, "correction_delta_nat_per_token": 0.010343}, "unfinished": {"n_probes": 4, "body_delta_nat_per_token": 0.041108, "close_token_delta_nat": -1.097248, "body_direction_delta": -3.151061}, "loop": {"n_probes": 3, "body_delta_nat_per_token": 0.024735, "close_token_delta_nat": -0.191729, "body_direction_delta": 1.991295, "first_repeat_delta_nat_per_token": -0.000807, "last_repeat_delta_nat_per_token": 0.010384, "direction_accumulation_original": 14.633666, "direction_accumulation_edited": 25.875552}}
Prior memory candidate independent validation: {"n": 1024, "delta_pp": -0.6836, "se_pp": 0.5436, "rescues": 12, "regressions": 19}
FINAL: 50/50 forwards used. No validated accuracy improvement. No retained weight edits. Original tensors restored and verified; final_report.md records the diagnostic path and negative result.
