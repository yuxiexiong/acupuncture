import hashlib,json,shutil,time,subprocess
from pathlib import Path
root=Path('/workspace/acupuncture/external/wcp01/orchestration-r1')
checks={}
for name,path in {'flow':'flow-r1/receipt.json','adapters':'adapters-r1/receipt.json','disconnect':'disconnect-r1/receipt.json','live_mac':'live-mac-r1/receipt.json','recovery':'local-recovery-r2.json'}.items():
 p=root/path;r=json.loads(p.read_text());checks[name]=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status=r['status'])
assert all(c['status'] in ('passed','completed') for c in checks.values()),checks
r=dict(status='passed',scope='engineering_acceptance_mac_ssh_transport_not_scientific_results',checks=checks,editor_transport='mac_ssh',mac_must_remain_online=True,server_direct_editor='failed_routing_timeout_preserved_in_live-r1',formal_search_started=False,new_gpu_seconds=0,new_model_generations=0,prior_model_acceptance_reused=True,live_check_label_note='Legacy server_astra check name denotes server-initiated request; actual Astra CLI runs on Mac via SSH',time=time.time())
(root/'acceptance.json').write_text(json.dumps(r,indent=2))
space=shutil.disk_usage('/workspace');gpu=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.used,utilization.gpu','--format=csv,noheader'],text=True)
(root/'resources.json').write_text(json.dumps(dict(time=time.time(),disk_free_bytes=space.free,disk_total_bytes=space.total,gpus=gpu,formal_runs_exist={p:(root.parent/'runs'/(p+'-r1')).exists() for p in ('0p8b','4b')}),indent=2))
print(json.dumps(r))
